package chen.anew.com.zhujiang.activity.product;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.widget.ImageView;

import org.greenrobot.greendao.query.Query;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.activity.main.MessageActivity;
import chen.anew.com.zhujiang.activity.web.WebMatchViewFragment;
import chen.anew.com.zhujiang.adpter.FragmentAdapter;
import chen.anew.com.zhujiang.base.BaseFragment;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.greendao.MessageBean;
import chen.anew.com.zhujiang.greendao.MessageBeanDao;
import chen.anew.com.zhujiang.net.RequestURL;

/**
 * Created by thinkpad on 2016/6/30.
 */
public class ProductFragment extends BaseFragment {

    @Bind(R.id.message_product_imgbtn)
    ImageView messageProductImgbtn;
    @Bind(R.id.tabs)
    TabLayout tabs;
    @Bind(R.id.viewPager)
    ViewPager viewPager;

    private List<String> titles;
    private List<Fragment> fragments;
    private MessageHintReceiver receiver;

    //    String environment = "http://eservicewapuat.prlife.com.cn:9001";
    String path = "/rcms/app/appweb/index.html?plat=2#accidentInsurance/safelist";


    public static ProductFragment newInstance() {
        ProductFragment productFragment = new ProductFragment();
        return productFragment;
    }

    @Override
    protected void initViews() {
        mPageName="ProductFragment";
        initToolBar();
        titles = new ArrayList<>();
        fragments = new ArrayList<>();
        titles.add(getString(R.string.financial_products));
        titles.add(getString(R.string.security_selection));
        for (int i = 0; i < titles.size(); i++) {
            tabs.addTab(tabs.newTab().setText(titles.get(i)));
        }
        fragments.add(new FinancialProductsFragment());
        Bundle bundle = new Bundle();
        bundle.putString("url", RequestURL.ESERVICE_9001 + path);
        fragments.add(WebMatchViewFragment.newInstance(bundle));
        FragmentAdapter mFragmentAdapteradapter =
                new FragmentAdapter(getChildFragmentManager(), fragments, titles);
        //给ViewPager设置适配器
        viewPager.setAdapter(mFragmentAdapteradapter);
        //将TabLayout和ViewPager关联起来。
        tabs.setupWithViewPager(viewPager);
        //给TabLayout设置适配器
        tabs.setTabsFromPagerAdapter(mFragmentAdapteradapter);

        //注册广播
        receiver = new MessageHintReceiver();
        IntentFilter filter = new IntentFilter("CHEN.COM.MESSAGE_HINT_ACTION");
        getActivity().registerReceiver(receiver, filter);
    }

    @OnClick(R.id.relative_product_left)
    public void onClick() {
        startActivity(new Intent(getActivity(), MessageActivity.class));
    }

    public class MessageHintReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            int img_red = intent.getIntExtra("img_red", -1);
            if (img_red == 1) {
                messageProductImgbtn.setImageResource(R.mipmap.message_red);
            } else if (img_red == 0) {
                messageProductImgbtn.setImageResource(R.mipmap.new_message);
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (receiver != null) {
            getActivity().unregisterReceiver(receiver);
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.frament_product;
    }

    private void initToolBar() {
        //判断是否存在未读的消息
        MessageBeanDao messageBeanDao = MyApp.daoSession.getMessageBeanDao();
        Query query = messageBeanDao.queryBuilder().where(
                MessageBeanDao.Properties.CustomerId.eq(Common.customer_id), MessageBeanDao.Properties.IsRead.eq("N"))
                .build();
        List<MessageBean> messageList = (List<MessageBean>) query.list();
        if (messageList != null & messageList.size() > 0) {
            messageProductImgbtn.setImageResource(R.mipmap.message_red);
        } else {
            messageProductImgbtn.setImageResource(R.mipmap.new_message);
        }
    }


}
