/*
package chen.anew.com.zhujiang.activity.mine;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jcodecraeer.xrecyclerview.ProgressStyle;
import com.jcodecraeer.xrecyclerview.XRecyclerView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.Bind;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.adpter.PolicyAdpter;
import chen.anew.com.zhujiang.base.BaseFragment;
import chen.anew.com.zhujiang.bean.ContList;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.CommonSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;

*/
/**
 * Created by thinkpad on 2016/7/10.
 *//*

public class MyPolicyFragment extends BaseFragment {

    @Bind(R.id.recyclerview)
    XRecyclerView mRecyclerView;

    @Bind(R.id.no_policy)
    ImageView no_policy;

    private String contStatus;
    private CommonSubscriber commonSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private ArrayList<ContList> contLists;
    private int mcurrentPage = 1;
    private PolicyAdpter policyAdpter;
    //public static boolean nomore = false;
    public static boolean ispolicySuccess=false;

    public static MyPolicyFragment newInstance(Bundle args) {
        MyPolicyFragment orderFragment = new MyPolicyFragment();
        orderFragment.setArguments(args);
        return orderFragment;
    }

    @Override
    protected void initViews() {
        Bundle bundle = getArguments();
        //ContStatus：不写=全部，00=生效中，01=已终止
        contStatus = bundle.getString("contStatus");
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                Log.i("msg", "-contStatus-" + result);
                Gson gson = new Gson();
                if (!TextUtils.isEmpty(result)) {
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        // String resultCode = jsonObject.getString("resultCode");
                        //成功获得活动列表
//                        JSONObject jsonObject = new JSONObject(result)
                        ArrayList<ContList> nowcontLists = gson.fromJson(jsonObject.getString("contList"), new TypeToken<ArrayList<ContList>>() {
                        }.getType());
                        //初始化列表
                        contLists.addAll(nowcontLists);
                        if (mcurrentPage == 1) {
                            if (nowcontLists != null && nowcontLists.size() + 1<5) {
                                mRecyclerView.setPullRefreshEnabled(false);
                            }else{
                                mRecyclerView.reset();
                            }
                            policyAdpter.updateView(contLists);
                            mRecyclerView.refreshComplete();
                        } else {
                            //加载更多
                            if (nowcontLists != null && nowcontLists.size() + 1 < 5) {
                                policyAdpter.updateView(contLists);
                                mRecyclerView.setIsnomore(false);
                            } else {
                                mRecyclerView.loadMoreComplete();
                                policyAdpter.updateView(contLists);
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    if (contLists != null && contLists.size() > 0) {
                        //没有更多了
                        mRecyclerView.setIsnomore(false);
                    } else {
                        //没有数据
                        mRecyclerView.refreshComplete();
                        no_policy.setVisibility(View.VISIBLE);
                    }
                }
            }
        };
        initReview();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ispolicySuccess=false;
    }

    @Override
    public void onResume() {
        super.onResume();
        if(ispolicySuccess){
            ispolicySuccess=false;
            mcurrentPage = 1;
            contLists.clear();
            getOrderList(mcurrentPage);
        }
       */
/* if(nomore){
            nomore=false;

        }*//*

    }

    private void initReview() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(layoutManager);

        mRecyclerView.setRefreshProgressStyle(ProgressStyle.BallPulse);
        mRecyclerView.setLoadingMoreProgressStyle(ProgressStyle.BallRotate);
        mRecyclerView.setArrowImageView(R.mipmap.iconfont_downgrey);
        mRecyclerView.setLoadingListener(new XRecyclerView.LoadingListener() {
            @Override
            public void onRefresh() {
                mcurrentPage = 1;
                contLists.clear();
                getOrderList(mcurrentPage);
            }

            @Override
            public void onLoadMore() {
                mcurrentPage = mcurrentPage + 1;
                getOrderList(mcurrentPage);
            }
        });
        contLists = new ArrayList<>();
        policyAdpter = new PolicyAdpter(contLists, getActivity());
        mRecyclerView.setAdapter(policyAdpter);
        policyAdpter.setOnItemClickListener(new PolicyAdpter.ClickListener() {
            @Override
            public void onItemClick(int position, View v) {
                ContList orderList = contLists.get(position-1);
                Intent intent = new Intent(getActivity(),PolicyItemActivity.class);
                intent.putExtra("contNo", orderList.getContNo());
                intent.putExtra("contStatus", orderList.getContStatus());
                startActivity(intent);
                Log.i("click", "-activity_list-" + orderList.toString());

            }
        });
        mRecyclerView.setRefreshing(true);
    }

    @Override
    protected int getContentViewId() {
        return R.layout.common_recyclerview;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (commonSubscriber != null && commonSubscriber.isUnsubscribed()) {
            commonSubscriber.unsubscribe();
        }
    }

    private void getOrderList(int currentPage) {
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        HashMap<String, Object> map3 = new HashMap<>();
        map2.put("queryAll", "false");
        map2.put("currentPage", "" + currentPage);
        map2.put("pageSize", "5");

        map3.put("customerId", Common.userInfo.getCustomerId());
        map3.put("contStatus", contStatus);
        map3.put("pageParams", map2);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map3);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        commonSubscriber = new CommonSubscriber(subscriberOnNextListener, getActivity());
        OkHttpObservable.getInstance().getData(commonSubscriber, RequestURL.GetPolicyListUrl + RequestURL.CreatRequestUrl(mapjson));

    }


}
*/
