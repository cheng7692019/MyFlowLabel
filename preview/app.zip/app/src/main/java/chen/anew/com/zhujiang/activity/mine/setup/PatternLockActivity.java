package chen.anew.com.zhujiang.activity.mine.setup;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;

import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.utils.PatternUtils;
import chen.anew.com.zhujiang.utils.SharedPreferencesUtils;
import chen.anew.com.zhujiang.widget.MaterialLockView;

/**
 * Created by thinkpad on 2016/7/20.
 */

public class PatternLockActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.pattern)
    MaterialLockView patternLock;
    @Bind(R.id.again_set_btn)
    Button againSetBtn;

    @Bind(R.id.pattern_tag)
    TextView patternTag;
    private Handler handler = new Handler();
    private String first_pattern = "";
    private boolean is_ago_current = false;

    @Override
    protected void initViews() {
        tvTitle.setText(R.string.input_pattern_password);
        initToolBar();
        final String my_pattern_lock = (String) SharedPreferencesUtils.getParam(PatternLockActivity.this, SharedPreferencesUtils.MY_PATTERN_LOCK + Common.customer_id, "");
        if (!TextUtils.isEmpty(my_pattern_lock)) {
            patternTag.setText(R.string.ago_draw);
        } else {
            //没有设置密码锁，弹出登录对话框
            showLoginDialog();
        }
        patternLock.setOnPatternListener(new MaterialLockView.OnPatternListener() {
            @Override
            public void onPatternDetected(final List<MaterialLockView.Cell> pattern, final String SimplePattern) {
                if (TextUtils.isEmpty(my_pattern_lock)) {
                    //没有设置密码锁
                    setLock(pattern, SimplePattern);
                } else {
                    //设置过密码锁 则是修改密码锁
                    if (!is_ago_current) {
                        String shaStr = PatternUtils.patternToSha1String(pattern);
                        if (shaStr.equals(my_pattern_lock)) {
                            patternLock.clearPattern();
                            patternTag.setText(R.string.set_pattern);
                            againSetBtn.setVisibility(View.VISIBLE);
                            is_ago_current = true;
                        } else {
                            patternTag.setText(R.string.ago_set_wrong_draw);
                            patternLock.setDisplayMode(MaterialLockView.DisplayMode.Wrong);
                        }
                    } else {
                        //重新设置
                        setLock(pattern, SimplePattern);
                    }
                }
                super.onPatternDetected(pattern, SimplePattern);
            }
        });
    }

    //显示登录对话框
    private void showLoginDialog() {
        LayoutInflater inflater = this.getLayoutInflater();
        View layout = inflater.inflate(R.layout.login_dialgo,
                (ViewGroup) this.findViewById(R.id.setlogin_linear));
        final EditText passwordEt = (EditText) layout.findViewById(R.id.password);
        String phone = Common.userInfo.getMobile();
        phone = phone.substring(0, 3) + "****" + phone.substring(6, 10);
        final Button cancle_btn = (Button) layout.findViewById(R.id.cancle_btn);
        final Button confirm_btn = (Button) layout.findViewById(R.id.confirm_btn);
        final MaterialDialog materialDialog = new MaterialDialog.Builder(this)
                .title(phone)
                .customView(layout, true)
                .cancelable(false)
                .show();
        cancle_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                materialDialog.dismiss();
                finish();
            }
        });
        confirm_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password = (String) SharedPreferencesUtils.getParam(PatternLockActivity.this, SharedPreferencesUtils.CUSTOMER_PASSWORD, "");
                String inputPsd = passwordEt.getText().toString();
                if (inputPsd.equals(password)) {
                    materialDialog.dismiss();
                } else {
                    //输入错误
                    passwordEt.setText("");
                    Toast.makeText(PatternLockActivity.this, "密码输入错误,请重新输入", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void setLock(final List<MaterialLockView.Cell> pattern, final String SimplePattern) {
        if (TextUtils.isEmpty(first_pattern)) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    patternLock.clearPattern();
                    patternTag.setText(R.string.again_draw);
                    againSetBtn.setVisibility(View.VISIBLE);
                    first_pattern = SimplePattern;
                }
            }, 1000);
        } else {
            if (!SimplePattern.equals(first_pattern)) {
                patternTag.setText(R.string.wrong_draw);
                patternLock.setDisplayMode(MaterialLockView.DisplayMode.Wrong);
            } else {
                patternLock.setDisplayMode(MaterialLockView.DisplayMode.Correct);
                String shaStr = PatternUtils.patternToSha1String(pattern);
                SharedPreferencesUtils.setParam(PatternLockActivity.this, SharedPreferencesUtils.MY_PATTERN_LOCK + Common.userInfo.getCustomerId(), shaStr);
                Toast.makeText(PatternLockActivity.this, "设置成功图案解锁", Toast.LENGTH_SHORT).show();
                //发送广播改变设置密码锁的开关
                //创建Intent对象
                Intent intent2 = new Intent();
                //设置Intent的Action属性
                intent2.setAction("CHEN.COM.PATTERNSETACTIVITY");
                intent2.putExtra("is_open", true);
                //发送广播,改变消息颜色
                sendBroadcast(intent2);
                finish();
            }
        }
    }


    @Override
    protected int getContentViewId() {
        return R.layout.activity_patternlock;
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @OnClick(R.id.again_set_btn)
    public void onClick() {
        first_pattern = "";
        patternTag.setText(R.string.set_pattern);
        againSetBtn.setVisibility(View.GONE);
        patternLock.clearPattern();
//        finish();
    }

}
