package chen.anew.com.zhujiang.bean;

import java.io.Serializable;

/**
 * Created by thinkpad on 2016/7/25.
 */
public class ItemPropertyMap implements Serializable {

    private String skuCode;

    private String itemCode;

    private String price;

    private String propertyValue;

    public void setSkuCode(String skuCode) {
        this.skuCode = skuCode;
    }

    public String getSkuCode() {
        return this.skuCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getItemCode() {
        return this.itemCode;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPrice() {
        return this.price;
    }

    public void setPropertyValue(String propertyValue) {
        this.propertyValue = propertyValue;
    }

    public String getPropertyValue() {
        return this.propertyValue;
    }
}
