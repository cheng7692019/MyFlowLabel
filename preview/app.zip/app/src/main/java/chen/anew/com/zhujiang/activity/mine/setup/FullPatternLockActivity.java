package chen.anew.com.zhujiang.activity.mine.setup;

import android.content.Intent;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.guidelogin.LoginActivity;
import chen.anew.com.zhujiang.activity.main.MainActivity;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.utils.PatternUtils;
import chen.anew.com.zhujiang.utils.SharedPreferencesUtils;
import chen.anew.com.zhujiang.widget.MaterialLockView;
import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by thinkpad on 2016/7/20.
 */
public class FullPatternLockActivity extends BaseAppActivity {

    @Bind(R.id.pattern)
    MaterialLockView patternLock;

    @Bind(R.id.head_img)
    CircleImageView headImg;
    @Bind(R.id.fail_msg)
    TextView failMsg;

    private Handler handler = new Handler();
    private int step_draw=0;

    @Override
    protected void initViews() {
        Glide.with(FullPatternLockActivity.this).load(Common.userInfo.getHeadimgurl())
                .error(R.mipmap.defaulthead)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .centerCrop()
                .into(headImg);

        patternLock.setOnPatternListener(new MaterialLockView.OnPatternListener() {
            @Override
            public void onPatternDetected(final List<MaterialLockView.Cell> pattern, final String SimplePattern) {
                String shaStr = PatternUtils.patternToSha1String(pattern);
                String resultStr = (String) SharedPreferencesUtils.getParam(FullPatternLockActivity.this, SharedPreferencesUtils.MY_PATTERN_LOCK + Common.customer_id, "");
                if (shaStr.equals(resultStr)) {
                    startActivity(new Intent(FullPatternLockActivity.this, MainActivity.class));
                    finish();
                } else {
                    patternLock.setDisplayMode(MaterialLockView.DisplayMode.Wrong);
                    step_draw++;
                    failMsg.setText("第"+step_draw+"次错误绘制解锁图案");
                    if(step_draw==5){
                        showFiveError();
                    }else{
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                patternLock.clearPattern();
                            }
                        }, 1000);
                    }
                }
            }
        });
    }


    //显示5次错误对话框
    private void showFiveError(){
        LayoutInflater inflater = this.getLayoutInflater();
        View layout = inflater.inflate(R.layout.tipstxt_short_dialgo,
                (ViewGroup) this.findViewById(R.id.tiptxt_linear));
        final TextView content_tv = (TextView) layout.findViewById(R.id.content_tv);
        content_tv.setText(R.string.five_error_draw);
        final Button konw_btn = (Button) layout.findViewById(R.id.konw_btn);
        konw_btn.setText(R.string.again_login);
        final MaterialDialog materialDialog=new MaterialDialog.Builder(this)
                .title(R.string.draw_error)
                .customView(layout, true)
                .cancelable(false)
                .show();
        konw_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                materialDialog.dismiss();
                startActivity(new Intent(FullPatternLockActivity.this, LoginActivity.class));
                finish();
            }
        });
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_full_patternlock;
    }

    @OnClick({R.id.setpaypass_btn, R.id.cacle_btn})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.setpaypass_btn:
                startActivity(new Intent(FullPatternLockActivity.this, LoginActivity.class));
                finish();
                break;
            case R.id.cacle_btn:
                startActivity(new Intent(FullPatternLockActivity.this, LoginActivity.class));
                finish();
                break;
        }
    }
}
