package chen.anew.com.zhujiang.activity.main;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.NotificationCompat;

import com.igexin.sdk.PushManager;
import com.luseen.luseenbottomnavigation.BottomNavigation.BottomNavigationView;
import com.luseen.luseenbottomnavigation.BottomNavigation.OnBottomNavigationItemClickListener;
import com.readystatesoftware.systembartint.SystemBarTintManager;
import com.umeng.analytics.MobclickAgent;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.product.ProductFragment;
import chen.anew.com.zhujiang.adpter.FragmentAdapter;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.fragment.ExerciseFragment;
import chen.anew.com.zhujiang.fragment.MineFragment;
import chen.anew.com.zhujiang.fragment.RecommendFragment;
import chen.anew.com.zhujiang.utils.MobclickAgentUtil;
import chen.anew.com.zhujiang.utils.ViewUtils;
import chen.anew.com.zhujiang.viewpage.CustomViewPager;

/**
 * Created by thinkpad on 2016/6/26.
 */

public class MainActivity extends AppCompatActivity {

    @Bind(R.id.bottomNavigation)
    BottomNavigationView bottomNavigationView;
    /*@Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.tool_bar)
    AppBarLayout tool_bar;*/

    @Bind(R.id.view_pager)
    CustomViewPager viewPager;

    private List<Fragment> fragments;
    private List<String> titles;

    private MessageHintReceiver receiver;
    public static boolean is_mine = false;
    private static final int REQUEST_PERMISSION = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        setContentView(R.layout.activity_basic);
        ButterKnife.bind(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ViewUtils.setTranslucentStatus(MainActivity.this,true);
            SystemBarTintManager tintManager = new SystemBarTintManager(this);
            // enable status bar tint
            tintManager.setStatusBarTintEnabled(true);
            // enable navigation bar tint
            tintManager.setNavigationBarTintEnabled(true);
            tintManager.setTintColor(ContextCompat.getColor(this, R.color.white));
        }
        if (Common.userInfo != null) {
            PackageManager pkgManager = getPackageManager();
            // 读写 sd card 权限非常重要, android6.0默认禁止的, 建议初始化之前就弹窗让用户赋予该权限
            boolean sdCardWritePermission =
                    pkgManager.checkPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE, getPackageName()) == PackageManager.PERMISSION_GRANTED;
            // read phone state用于获取 imei 设备信息
            boolean phoneSatePermission =
                    pkgManager.checkPermission(Manifest.permission.READ_PHONE_STATE, getPackageName()) == PackageManager.PERMISSION_GRANTED;
            if (Build.VERSION.SDK_INT >= 23 && !sdCardWritePermission || !phoneSatePermission) {
                requestPermission();
            } else {
                // SDK初始化，第三方程序启动时，都要进行SDK初始化工作
                PushManager.getInstance().initialize(MainActivity.this);
            }
            //个推：绑定别名
            PushManager.getInstance().bindAlias(MainActivity.this, "00" + Common.userInfo.getCustomerId());
        }
        //关闭activity DurationTrack
        MobclickAgentUtil.closeActivityDurationTrack(this);
//        tvTitle.setText(getResources().getString(R.string.recommend_txt));
//        initToolBar();
        fragments = new ArrayList<>();
        fragments.add(RecommendFragment.newInstance());
        fragments.add(ProductFragment.newInstance());
        fragments.add(ExerciseFragment.newInstance());
        fragments.add(MineFragment.newInstance());
        titles = new ArrayList<>();
        int[] image = {R.mipmap.ic_action_toggle_star, R.mipmap.ic_action_device_now_widgets,
                R.mipmap.ic_action_action_redeem, R.mipmap.ic_action_social_person};
        titles.add(getString(R.string.recommend_txt));
        titles.add(getString(R.string.product_txt));
        titles.add(getString(R.string.events_txt));
        titles.add(getString(R.string.mine_txt));
        int[] color = {ContextCompat.getColor(this, R.color.colorAccent), ContextCompat.getColor(this, R.color.colorAccent),
                ContextCompat.getColor(this, R.color.colorAccent), ContextCompat.getColor(this, R.color.colorAccent)};
        if (bottomNavigationView != null) {
            // bottomNavigationView.activateTabletMode();
            bottomNavigationView.isColoredBackground(false);
            bottomNavigationView.selectTab(0);
            bottomNavigationView.setItemActiveColorWithoutColoredBackground(ContextCompat.getColor(this, R.color.white));
            //bottomNavigationView.setFont(Typeface.createFromAsset(getApplicationContext().getAssets(), "fonts/Noh_normal.ttf"));
        }
       /* BottomNavigationItem bottomNavigationItem = new BottomNavigationItem
                (titles.get(0), ContextCompat.getColor(this, R.color.colorAccent), image[0]);
        BottomNavigationItem bottomNavigationItem1 = new BottomNavigationItem
                (titles.get(1), ContextCompat.getColor(this, R.color.colorAccent), image[1]);
        BottomNavigationItem bottomNavigationItem2 = new BottomNavigationItem
                (titles.get(2), ContextCompat.getColor(this, R.color.colorAccent), image[2]);
        BottomNavigationItem bottomNavigationItem3 = new BottomNavigationItem
                (titles.get(3), ContextCompat.getColor(this, R.color.colorAccent), image[3]);
        bottomNavigationView.addTab(bottomNavigationItem);
        bottomNavigationView.addTab(bottomNavigationItem1);
        bottomNavigationView.addTab(bottomNavigationItem2);
        bottomNavigationView.addTab(bottomNavigationItem3);*/
        FragmentAdapter mFragmentAdapteradapter =
                new FragmentAdapter(getSupportFragmentManager(), fragments, titles);
        //给ViewPager设置适配器
        viewPager.setPagingEnabled(false);
        //viewPager.setPageTransformer(true, new DepthPageTransformer());
        // viewPager.setOffscreenPageLimit(4);
        viewPager.setAdapter(mFragmentAdapteradapter);
        bottomNavigationView.setUpWithViewPager(viewPager, color, image);
        bottomNavigationView.setOnBottomNavigationItemClickListener(new OnBottomNavigationItemClickListener() {
            @Override
            public void onNavigationItemClick(int index) {
                //viewPager.setCurrentItem(index, false);
                if (index == 3) {
                    SystemBarTintManager tintManager = new SystemBarTintManager(MainActivity.this);
                    // enable status bar tint
                    tintManager.setStatusBarTintEnabled(true);
                    // enable navigation bar tint
                    tintManager.setNavigationBarTintEnabled(true);
                    tintManager.setTintColor(ContextCompat.getColor(MainActivity.this, R.color.my_person_center));//通知栏所需颜色
                }else{
                    SystemBarTintManager tintManager = new SystemBarTintManager(MainActivity.this);
                    // enable status bar tint
                    tintManager.setStatusBarTintEnabled(true);
                    // enable navigation bar tint
                    tintManager.setNavigationBarTintEnabled(true);
                    tintManager.setTintColor(ContextCompat.getColor(MainActivity.this, R.color.white));
                }
               /* switch (index) {
                    case 0:
                        toolbar.setVisibility(View.VISIBLE);
                        tvTitle.setText(getResources().getString(R.string.recommend_txt));
                        changeFragment(new RecommendFragment());
                        break;
                    case 1:
                        toolbar.setVisibility(View.VISIBLE);
                        tvTitle.setText(getResources().getString(R.string.product_txt));
                        changeFragment(new ProductFragment());
                        break;
                    case 2:
                        toolbar.setVisibility(View.VISIBLE);
                        tvTitle.setText(getResources().getString(R.string.events_txt));
                        changeFragment(new ExerciseFragment());
                        break;
                    case 3:
                        tvTitle.setText(getResources().getString(R.string.mine_txt));
                        toolbar.setVisibility(View.GONE);
                        changeFragment(new MineFragment());
                        break;
                }*/
            }
        });
        //注册广播
        receiver = new MessageHintReceiver();
        IntentFilter filter = new IntentFilter("CHEN.COM.MESSAGE_HINT_ACTION");
        this.registerReceiver(receiver, filter);
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_PHONE_STATE},
                REQUEST_PERMISSION);
    }

    public class MessageHintReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean flag = intent.getBooleanExtra("is_finish", false);
            if (flag) {
                finish();
            }
            int img_red = intent.getIntExtra("img_red", -1);
            String title = intent.getStringExtra("title");
            if (img_red == 1) {
                sendNotification(title);
            }
            /*if (position == 3) {
                tool_bar.setVisibility(View.GONE);
            } else {
                tool_bar.setVisibility(View.VISIBLE);
               if (img_red == 1) {
                    getSupportActionBar().setHomeAsUpIndicator(R.mipmap.message_red);
                } else if (img_red == 0) {
                    getSupportActionBar().setHomeAsUpIndicator(R.mipmap.new_message);
                }
            }*/
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        MobclickAgent.onPause(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        MobclickAgent.onResume(this);
        if (is_mine) {
            bottomNavigationView.selectTab(3);
            is_mine = false;
        }
    }

    private void sendNotification(String title) {
        int notifyId = 100;
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this);
        mBuilder.setContentTitle(title)//设置通知栏标题
                .setContentText("你有一条新的" + title + "消息")
                .setContentIntent(getDefalutIntent(Notification.FLAG_AUTO_CANCEL)) //设置通知栏点击意图
                .setTicker(title)
                .setWhen(System.currentTimeMillis())
                .setPriority(Notification.PRIORITY_DEFAULT) //设置该通知优先级
                //.setAutoCancel(true)//设置这个标志当用户单击面板就可以让通知将自动取消
                .setOngoing(false)//ture，设置他为一个正在进行的通知。他们通常是用来表示一个后台任务,用户积极参与(如播放音乐)或以某种方式正在等待,因此占用设备(如一个文件下载,同步操作,主动网络连接)
                .setDefaults(Notification.DEFAULT_ALL)
                .setSmallIcon(R.mipmap.min_logo);//设置通知小ICON
        mNotificationManager.notify(notifyId, mBuilder.build());
    }

    private PendingIntent getDefalutIntent(int flags) {
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 1, new Intent(), flags);
        return pendingIntent;
    }

    private void changeFragment(Fragment targetFragment) {
        // resideMenu.clearIgnoredViewList();
        /*getSupportFragmentManager().beginTransaction()
                .replace(R.id.main_frame, targetFragment, "fragment")
                .setTransitionStyle(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                .commit();*/
    }

  /*  private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        //判断是否存在未读的消息
        setBar();
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, MessageActivity.class));
            }
        });
    }*/

   /* private void setBar() {
        MessageBeanDao messageBeanDao = MyApp.daoSession.getMessageBeanDao();
        Query query = messageBeanDao.queryBuilder().where(
                MessageBeanDao.Properties.CustomerId.eq(Common.customer_id), MessageBeanDao.Properties.IsRead.eq("N"))
                .build();
        List<MessageBean> messageList = (List<MessageBean>) query.list();
        if (position == 3) {
            tool_bar.setVisibility(View.GONE);
        } else {
            tool_bar.setVisibility(View.VISIBLE);
            if (messageList != null & messageList.size() > 0) {
                getSupportActionBar().setHomeAsUpIndicator(R.mipmap.message_red);
            } else {
                getSupportActionBar().setHomeAsUpIndicator(R.mipmap.new_message);
            }
        }
    }*/

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ButterKnife.unbind(this);
        if (receiver != null) {
            this.unregisterReceiver(receiver);
        }
    }
}
