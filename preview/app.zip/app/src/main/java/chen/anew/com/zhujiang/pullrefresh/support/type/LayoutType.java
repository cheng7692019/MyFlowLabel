package chen.anew.com.zhujiang.pullrefresh.support.type;

/**
 * Created by Ybao on 16/7/26.
 */
public class LayoutType {
    public final static int LAYOUT_NORMAL = 0x00;
    public final static int LAYOUT_DRAWER = 0x01;
    public final static int LAYOUT_SCROLLER = 0x10;
}
