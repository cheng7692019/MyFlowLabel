package chen.anew.com.zhujiang.bean;

import java.io.Serializable;

/**
 * Created by thinkpad on 2016/7/8.
 */
public class EbizUserBindcardDTO implements Serializable {

    private String cardBookCode;

    private String bankName;

    private String accLimit;

    private String customerId;

    private String cardBookType;

    private String bankIcon;

    private String bankCode;

    public void setCardBookCode(String cardBookCode) {
        this.cardBookCode = cardBookCode;
    }

    public String getCardBookCode() {
        return this.cardBookCode;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankName() {
        return this.bankName;
    }

    public void setAccLimit(String accLimit) {
        this.accLimit = accLimit;
    }

    public String getAccLimit() {
        return this.accLimit;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerId() {
        return this.customerId;
    }

    public void setCardBookType(String cardBookType) {
        this.cardBookType = cardBookType;
    }

    public String getCardBookType() {
        return this.cardBookType;
    }

    public void setBankIcon(String bankIcon) {
        this.bankIcon = bankIcon;
    }

    public String getBankIcon() {
        return this.bankIcon;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBankCode() {
        return this.bankCode;
    }

}
