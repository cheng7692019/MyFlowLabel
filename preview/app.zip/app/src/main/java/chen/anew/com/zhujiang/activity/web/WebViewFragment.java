package chen.anew.com.zhujiang.activity.web;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;

import butterknife.Bind;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.product.SecurityDetailsActivity;
import chen.anew.com.zhujiang.base.BaseFragment;
import chen.anew.com.zhujiang.utils.MyLogUtil;

/**
 * Created by thinkpad on 2016/7/5.
 */
public class WebViewFragment extends BaseFragment {
    @Bind(R.id.webView)
    YsTopWebView webView;
    private String url;
    private SecurityDetailsActivity activity;

    public static WebViewFragment newInstance(Bundle args) {
        WebViewFragment webview = new WebViewFragment();
        webview.setArguments(args);
        return webview;
    }

    @Override
    protected void initViews() {
        mPageName="WebViewFragment";
        Bundle bundle = getArguments();
        url=bundle.getString("url");
        MyLogUtil.i("url","--url-"+url);
        WebSettings setting = webView.getSettings();
        setting.setJavaScriptEnabled(true);//支持js
        setting.setDomStorageEnabled(true);
        setting.setDefaultTextEncodingName("utf-8");//设置字符编码
        setting.setAllowFileAccess(true);
        // webView.requestFocusFromTouch();// 设置支持获取手势焦点
//        setting.setBuiltInZoomControls(false);
        setting.setSupportZoom(true);
        webView.setWebViewClient(new WebViewClient());
        if(url.contains("itemCode")){
            activity=(SecurityDetailsActivity)getActivity();
            webView.addJavascriptInterface(activity.jso, "JavaScriptObject");
        }else{
            if(url.contains("plat")){
                MyLogUtil.i("url","-plat-"+url);
                webView.addJavascriptInterface(new JavaScriptObject(getActivity()), "JavaScriptObject");
            }
        }
        webView.loadUrl(url);
    }


    @Override
    protected int getContentViewId() {
        return R.layout.fragment_webview;
    }
}
