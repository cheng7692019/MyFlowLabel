package chen.anew.com.zhujiang.widget;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;

import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.mine.setup.SetPayPasswordActivity;

/**
 * Created by thinkpad on 2016/6/26.
 */
public class Loaddialog {

    private static class SingletonHolder {
        // private static String jsonParam;
        private static final Loaddialog loaddialog = new Loaddialog();
    }

    //获取单例
    public static Loaddialog getInstance() {
        return SingletonHolder.loaddialog;
    }

    private static Dialog mDialog;

    public static void initLoding(Context context) {
        mDialog = new Dialog(context, R.style.recordbutton_alert_dialog);
        View contentView = LayoutInflater.from(context).inflate(R.layout.dialog_mooc_alert_dialog, null);
        BGAMoocStyleRefreshView moocImage = (BGAMoocStyleRefreshView) contentView.findViewById(R.id.zeffect_recordbutton_dialog_imageview);
        moocImage.setOriginalImage(R.mipmap.refresh_star);
        moocImage.setUltimateColor(R.color.colorPrimary);
        moocImage.startRefreshing();
        mDialog.setContentView(contentView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        mDialog.setCancelable(false);
        mDialog.show();
    }

    public static void dissLoading() {
        if(mDialog!=null){
            mDialog.dismiss();
        }
    }

    public static void showTipTxtKnow(String title,String content,String btnTxt,Activity activity){
        LayoutInflater inflater = activity.getLayoutInflater();
        View layout = inflater.inflate(R.layout.tipstxt_dialgo,
                (ViewGroup) activity.findViewById(R.id.tiptxt_linear));
        final TextView content_tv = (TextView) layout.findViewById(R.id.content_tv);
        content_tv.setMovementMethod(ScrollingMovementMethod.getInstance());
        content_tv.setText(content);
        final Button konw_btn = (Button) layout.findViewById(R.id.konw_btn);
        if(!TextUtils.isEmpty(btnTxt)){
            konw_btn.setText(btnTxt);
        }
        final MaterialDialog materialDialog=new MaterialDialog.Builder(activity)
                .title(title)
                .customView(layout, true)
                .show();
        konw_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //设置
                materialDialog.dismiss();
            }
        });
    }


    public static void showTipKnow(String title, String html, String btnTxt,boolean isHtml, Activity activity){
        LayoutInflater inflater = activity.getLayoutInflater();
        View layout = inflater.inflate(R.layout.tipshtml_dialgo,
                (ViewGroup) activity.findViewById(R.id.tip_linear));
        final TextView content_tv = (TextView) layout.findViewById(R.id.content_tv);
        content_tv.setMovementMethod(ScrollingMovementMethod.getInstance());
        if(isHtml){
            content_tv.setText(Html.fromHtml(html));
        }else{
            content_tv.setText(html);
        }
        final Button konw_btn = (Button) layout.findViewById(R.id.konw_btn);
        if(!TextUtils.isEmpty(btnTxt)){
            konw_btn.setText(btnTxt);
        }
        final MaterialDialog materialDialog=new MaterialDialog.Builder(activity)
                .title(title)
                .customView(layout, true)
                .show();
        konw_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //设置
                materialDialog.dismiss();

            }
        });
    }

    public static void showSetPayPassword(final Activity activity){
        LayoutInflater inflater = activity.getLayoutInflater();
        View layout = inflater.inflate(R.layout.set_dialgo,
                (ViewGroup) activity.findViewById(R.id.setdia_linear));
        final Button cacle_btn = (Button) layout.findViewById(R.id.cacle_btn);
        final Button setpaypass_btn = (Button) layout.findViewById(R.id.setpaypass_btn);
        final MaterialDialog materialDialog=new MaterialDialog.Builder(activity)
                .title(R.string.safe_title)
                .customView(layout, true)
                .show();
        cacle_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                materialDialog.dismiss();
            }
        });
        setpaypass_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //设置
                materialDialog.dismiss();
                activity.startActivity(new Intent(activity,SetPayPasswordActivity.class));
            }
        });
    }

}
