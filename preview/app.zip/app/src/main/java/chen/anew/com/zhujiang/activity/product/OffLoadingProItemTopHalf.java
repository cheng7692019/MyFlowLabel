package chen.anew.com.zhujiang.activity.product;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import butterknife.Bind;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseFragment;
import chen.anew.com.zhujiang.greendao.ProductList;

/**
 * Created by thinkpad on 2016/7/5.
 */
public class OffLoadingProItemTopHalf extends BaseFragment {


    @Bind(R.id.productname_tv)
    TextView productnameTv;
    @Bind(R.id.filing_number_tv)
    TextView filingNumberTv;
    @Bind(R.id.history_interestrate_tv)
    TextView historyInterestrateTv;
    @Bind(R.id.mix_interestrate_tv)
    TextView mixInterestrateTv;
    @Bind(R.id.surrender_year_tv)
    TextView surrenderYearTv;
    @Bind(R.id.status_iv)
    ImageView statusIv;

    @Bind(R.id.buy_btn)
    Button buyBtn;


    private ProductList productList;

    public static OffLoadingProItemTopHalf newInstance(Bundle args) {
        OffLoadingProItemTopHalf offLoadingProItemTopHalf = new OffLoadingProItemTopHalf();
        offLoadingProItemTopHalf.setArguments(args);
        return offLoadingProItemTopHalf;
    }

    @Override
    protected void initViews() {
        mPageName="OffLoadingProItemTopHalf";
        productList = getActivity().getIntent().getParcelableExtra("product_list");
        initView();
    }

    private void initView() {
        String status = productList.getStatus();
        if ("05".equals(status)) {
            statusIv.setImageResource(R.mipmap.unshelve);
            buyBtn.setText("已下架");
        } else if ("06".equals(status)) {
            statusIv.setImageResource(R.mipmap.sold_out);
            buyBtn.setText("已售罄");
        }
        filingNumberTv.setText(productList.getFiling_number());
        productnameTv.setText(productList.getProductName());
        historyInterestrateTv.setText(productList.getHistoryRate());
        mixInterestrateTv.setText(productList.getAssureRate());
        surrenderYearTv.setText(productList.getCostFeePeriod());
    }

    @Override
    protected int getContentViewId() {
        return R.layout.fragment_offloadingproductitem_tophalf;
    }


}
