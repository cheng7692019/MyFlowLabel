package chen.anew.com.zhujiang.activity.mine.setup;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.widget.SwitchCompat;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.utils.SharedPreferencesUtils;

/**
 * Created by thinkpad on 2016/7/20.
 */
public class PatternSetActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.switch_select)
    SwitchCompat switchSelect;


    private MessageReceiver receiver;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.psdlock));
        initToolBar();
        boolean is_opne= (boolean) SharedPreferencesUtils.getParam(PatternSetActivity.this, SharedPreferencesUtils.IS_OPEN_LOCK + Common.userInfo.getCustomerId(), false);
        switchSelect.setChecked(is_opne);
        switchSelect.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                String my_pattern_lock = (String) SharedPreferencesUtils.getParam(PatternSetActivity.this, SharedPreferencesUtils.MY_PATTERN_LOCK + Common.customer_id, "");
                if (TextUtils.isEmpty(my_pattern_lock)) {
                    Toast.makeText(PatternSetActivity.this, "请先设置解锁图案", Toast.LENGTH_SHORT).show();
                    buttonView.setChecked(false);
                } else {
                    //设置关闭开启
                    if (isChecked) {
                        SharedPreferencesUtils.setParam(PatternSetActivity.this, SharedPreferencesUtils.IS_OPEN_LOCK + Common.userInfo.getCustomerId(), true);
                    } else {
                        SharedPreferencesUtils.setParam(PatternSetActivity.this, SharedPreferencesUtils.IS_OPEN_LOCK + Common.userInfo.getCustomerId(), false);
                    }
                }
            }
        });
        //注册广播
        receiver = new MessageReceiver();
        IntentFilter filter = new IntentFilter("CHEN.COM.PATTERNSETACTIVITY");
        this.registerReceiver(receiver, filter);
    }

    public class MessageReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean flag=intent.getBooleanExtra("is_open",false);
            if(flag){
                switchSelect.setChecked(true);
                SharedPreferencesUtils.setParam(PatternSetActivity.this, SharedPreferencesUtils.IS_OPEN_LOCK + Common.userInfo.getCustomerId(), true);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (receiver != null) {
            this.unregisterReceiver(receiver);
        }
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_patternset;
    }

    @OnClick({R.id.forgotten_relative})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.forgotten_relative:
                startActivity(new Intent(PatternSetActivity.this, PatternLockActivity.class));
                break;
        }
    }

}
