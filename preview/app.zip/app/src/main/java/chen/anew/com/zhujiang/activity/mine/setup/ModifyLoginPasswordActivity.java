package chen.anew.com.zhujiang.activity.mine.setup;

import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;

/**
 * Created by thinkpad on 2016/7/19.
 */
public class ModifyLoginPasswordActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.oldpassword_et)
    EditText oldpasswordEt;
    @Bind(R.id.newpassword_et)
    EditText newpasswordEt;
    @Bind(R.id.confirmnewpassword_et)
    EditText confirmnewpasswordEt;

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.modify_loginpassword));
        initToolBar();
//        OperationResult
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg", "-responseBody-" + result);
                try {
                    JSONObject jsonObject=new JSONObject(result);
                    String operationResult=jsonObject.getString("operationResult");
                    String resultMessage=jsonObject.getString("resultMessage");
                    if ("1".equals(operationResult)) {
                        Toast.makeText(ModifyLoginPasswordActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                        finish();
                    } else if ("0".equals(operationResult)) {
                        Toast.makeText(ModifyLoginPasswordActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_modifypassword;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
    }


    @OnClick(R.id.fab_ok)
    public void onClick() {
        String oldpassword = oldpasswordEt.getText().toString();
        String newpassword = newpasswordEt.getText().toString();
        String confirmnewpassword = confirmnewpasswordEt.getText().toString();
        if (oldpassword.length() < 6) {
            Toast.makeText(ModifyLoginPasswordActivity.this, "旧密码的长度不得少于6位", Toast.LENGTH_SHORT).show();
        } else if (newpassword.length() < 6) {
            Toast.makeText(ModifyLoginPasswordActivity.this, "新密码的长度不得少于6位", Toast.LENGTH_SHORT).show();
        } else if (confirmnewpassword.length() < 6) {
            Toast.makeText(ModifyLoginPasswordActivity.this, "确认密码的长度不得少于6位", Toast.LENGTH_SHORT).show();
        } else if (!newpassword.equals(confirmnewpassword)) {
            Toast.makeText(ModifyLoginPasswordActivity.this, "新设置的密码不一致", Toast.LENGTH_SHORT).show();
        }else{
            //提交数据
            Gson gson = new Gson();
            HashMap<String, Object> map = new HashMap<>();
            HashMap<String, String> map2 = new HashMap<>();
            map2.put("customerId", Common.userInfo.getCustomerId());
            map2.put("formerPassword", oldpassword);
            map2.put("newPassword", confirmnewpassword);

            map.put("orderType", "32");
            map.put("platType", "3");
            map.put("requestObject", map2);
            String mapjson = gson.toJson(map);
            //Log.i("msg","-mapjson-"+mapjson);
            //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
            dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, ModifyLoginPasswordActivity.this);
            OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.changePasswordUrl + RequestURL.CreatRequestUrl(mapjson));
        }
    }
}
