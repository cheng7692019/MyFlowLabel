package chen.anew.com.zhujiang.bean;

import java.io.Serializable;

/**
 * Created by thinkpad on 2016/7/11.
 */
public class ContList implements Serializable {

    private String orderTypeLabel;

    private String insuredName;

    private String contValue;

    private String isElecCont;

    private String productType;

    private String appntName;

    private String customerId;

    private String vlidDate;

    private String costFeePeriod;

    private String canRevisit;

    private String contNo;

    private String mainRiskName;

    private String getStartDateString;

    private String activityCode;

    private String isSurrenderRseceive;

    private String contTypeLabel;

    private String orderType;

    private String productCode;

    private String dayTotalAmnt;

    private String contStatusLabel;

    private String orderStatus;

    private String contStatus;

    private String orderNo;

    private String getEndDateString;

    private String productFlag;

    private String prem;

    private String contType;

    public void setOrderTypeLabel(String orderTypeLabel) {
        this.orderTypeLabel = orderTypeLabel;
    }

    public String getOrderTypeLabel() {
        return this.orderTypeLabel;
    }

    public void setInsuredName(String insuredName) {
        this.insuredName = insuredName;
    }

    public String getInsuredName() {
        return this.insuredName;
    }

    public void setContValue(String contValue) {
        this.contValue = contValue;
    }

    public String getContValue() {
        return this.contValue;
    }

    public void setIsElecCont(String isElecCont) {
        this.isElecCont = isElecCont;
    }

    public String getIsElecCont() {
        return this.isElecCont;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductType() {
        return this.productType;
    }

    public void setAppntName(String appntName) {
        this.appntName = appntName;
    }

    public String getAppntName() {
        return this.appntName;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerId() {
        return this.customerId;
    }

    public void setVlidDate(String vlidDate) {
        this.vlidDate = vlidDate;
    }

    public String getVlidDate() {
        return this.vlidDate;
    }

    public void setCostFeePeriod(String costFeePeriod) {
        this.costFeePeriod = costFeePeriod;
    }

    public String getCostFeePeriod() {
        return this.costFeePeriod;
    }

    public void setCanRevisit(String canRevisit) {
        this.canRevisit = canRevisit;
    }

    public String getCanRevisit() {
        return this.canRevisit;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getContNo() {
        return this.contNo;
    }

    public void setMainRiskName(String mainRiskName) {
        this.mainRiskName = mainRiskName;
    }

    public String getMainRiskName() {
        return this.mainRiskName;
    }

    public void setGetStartDateString(String getStartDateString) {
        this.getStartDateString = getStartDateString;
    }

    public String getGetStartDateString() {
        return this.getStartDateString;
    }

    public void setActivityCode(String activityCode) {
        this.activityCode = activityCode;
    }

    public String getActivityCode() {
        return this.activityCode;
    }

    public void setIsSurrenderRseceive(String isSurrenderRseceive) {
        this.isSurrenderRseceive = isSurrenderRseceive;
    }

    public String getIsSurrenderRseceive() {
        return this.isSurrenderRseceive;
    }

    public void setContTypeLabel(String contTypeLabel) {
        this.contTypeLabel = contTypeLabel;
    }

    public String getContTypeLabel() {
        return this.contTypeLabel;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getOrderType() {
        return this.orderType;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductCode() {
        return this.productCode;
    }

    public void setDayTotalAmnt(String dayTotalAmnt) {
        this.dayTotalAmnt = dayTotalAmnt;
    }

    public String getDayTotalAmnt() {
        return this.dayTotalAmnt;
    }

    public void setContStatusLabel(String contStatusLabel) {
        this.contStatusLabel = contStatusLabel;
    }

    public String getContStatusLabel() {
        return this.contStatusLabel;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getOrderStatus() {
        return this.orderStatus;
    }

    public void setContStatus(String contStatus) {
        this.contStatus = contStatus;
    }

    public String getContStatus() {
        return this.contStatus;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getOrderNo() {
        return this.orderNo;
    }

    public void setGetEndDateString(String getEndDateString) {
        this.getEndDateString = getEndDateString;
    }

    public String getGetEndDateString() {
        return this.getEndDateString;
    }

    public void setProductFlag(String productFlag) {
        this.productFlag = productFlag;
    }

    public String getProductFlag() {
        return this.productFlag;
    }

    public void setPrem(String prem) {
        this.prem = prem;
    }

    public String getPrem() {
        return this.prem;
    }

    public void setContType(String contType) {
        this.contType = contType;
    }

    public String getContType() {
        return this.contType;
    }

}
