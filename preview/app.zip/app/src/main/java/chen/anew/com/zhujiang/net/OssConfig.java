package chen.anew.com.zhujiang.net;

import android.os.Environment;

import com.alibaba.sdk.android.oss.OSS;
import com.alibaba.sdk.android.oss.common.auth.OSSCredentialProvider;
import com.alibaba.sdk.android.oss.common.auth.OSSPlainTextAKSKCredentialProvider;

/**
 * Created by thinkpad on 2016/7/15.
 */
public class OssConfig {

    /**
     * 拍照
     */
    public static int CAMERA_RESULT = 100;
    /**
     * 相册选择
     */
    public static int RESULT_LOAD_IMAGE = 200;
    /**
     * 裁剪成功
     */
    public static int IMAGE_COMPLETE = 12;
    public static String saveDir = Environment.getExternalStorageDirectory()
            .getPath() + "/temp_image";
    public static OSS oss;

    // 运行sample前需要配置以下字段为有效的值
    public static final String endpoint = "http://oss-cn-hangzhou.aliyuncs.com";
    public static final String accessKeyId = "ZZnr1VEp7pCuzRV6";
    public static final String accessKeySecret = "ayYz6EZ87sA7d0yRKF52Qi6ETT0y8Y";
    public static String driver = "";
    public static final String bucket = "guanwang-prod";
    public static OSSCredentialProvider credentialProvider;

    static {
        credentialProvider = new OSSPlainTextAKSKCredentialProvider(accessKeyId, accessKeySecret);
    }

    ;
}
