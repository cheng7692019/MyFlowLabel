package chen.anew.com.zhujiang.activity.mine.setup;

import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.widget.PasswordInputView;

/**
 * Created by thinkpad on 2016/7/19.
 */

public class ModifyPayPasswordActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.passwordInputView)
    PasswordInputView passwordInputView;
    @Bind(R.id.pay_msg)
    TextView payMsg;

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private int step = 1;
    private String oldpassword, prevsteppassword;
    //上个页面传来的值
    private String mobile,sessionId,verificationCode;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.modify_paypassword));
        initToolBar();
        mobile=getIntent().getStringExtra("mobile");
        sessionId=getIntent().getStringExtra("sessionId");
        verificationCode=getIntent().getStringExtra("verificationCode");
        if(!TextUtils.isEmpty(sessionId)&&!TextUtils.isEmpty(verificationCode)){
            stepTwo();
        }
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg", "-result-" + result);
                switch (step) {
                    case 1:
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            String resultCode = jsonObject.getString("resultCode");
                            String resultMessage = jsonObject.getString("resultMessage");
                            if ("1".equals(resultCode)) {
                                //验证成功下一步
                                stepTwo();
                                Toast.makeText(ModifyPayPasswordActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(ModifyPayPasswordActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 3:
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            String resultCode = jsonObject.getString("resultCode");
                            String resultMessage = jsonObject.getString("resultMessage");
                            if ("1".equals(resultCode)) {
                                //验证成功下一步
                                Toast.makeText(ModifyPayPasswordActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(ModifyPayPasswordActivity.this, "设置失败->"+resultMessage, Toast.LENGTH_SHORT).show();
                            }
                            finish();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        break;
                }

            }
        };
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
    }


    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_modify_paypassword;
    }


    @OnClick(R.id.fab_ok)
    public void onClick() {
        String password = passwordInputView.getText().toString();
        if (password.length() < 6) {
            Toast.makeText(ModifyPayPasswordActivity.this, "支付密码不能少于6位", Toast.LENGTH_SHORT).show();
        } else {
            switch (step) {
                case 1:
                    valPayPasswrod(password);
                    break;
                case 2:
                    prevsteppassword = passwordInputView.getText().toString();
                    payMsg.setText(getString(R.string.set_next_paypassword));
                    passwordInputView.setText("");
                    step = 3;
                    break;
                case 3:
                    if (!password.equals(prevsteppassword)) {
                        Toast.makeText(ModifyPayPasswordActivity.this, "两次输入的密码不一致", Toast.LENGTH_SHORT).show();
                    } else {
                        modifyPayPasswrod(password);
                    }
                    break;
            }

        }
    }

    private void stepTwo(){
        payMsg.setText(getString(R.string.set_paypassword));
        oldpassword = passwordInputView.getText().toString();
        passwordInputView.setText("");
        step = 2;
    }

    private void valPayPasswrod(String password) {
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("payPassword", password);
        map2.put("customerId", Common.userInfo.getCustomerId());

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, ModifyPayPasswordActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.ValidateAccountSecurityUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    private void modifyPayPasswrod(String password) {
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        if(!TextUtils.isEmpty(sessionId)&&!TextUtils.isEmpty(verificationCode)){
            map2.put("mobile", mobile);
            map2.put("newPayPassword",password);
            map2.put("sessionId",sessionId);
            map2.put("customerId", Common.userInfo.getCustomerId());
            map2.put("type","1");
            map2.put("operateType","2");
            map2.put("operateCode",mobile);
            map2.put("verificationCode",verificationCode);
        }else{
            map2.put("payPassword", oldpassword);
            map2.put("newPayPassword",password);
            map2.put("customerId", Common.userInfo.getCustomerId());
            map2.put("type","2");
        }
        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);
        String mapjson = gson.toJson(map);
        MyLogUtil.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, ModifyPayPasswordActivity.this);
        if(!TextUtils.isEmpty(sessionId)&&!TextUtils.isEmpty(verificationCode)){
            OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.ResetAccountSecurityForgetUrl + RequestURL.CreatRequestUrl(mapjson));
        }else{
            OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.ResetAccountSecurityAlterUrl + RequestURL.CreatRequestUrl(mapjson));
        }
    }

}
