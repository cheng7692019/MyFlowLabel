package chen.anew.com.zhujiang.activity.mine.persondata;

import android.content.Intent;
import android.support.v4.util.ArrayMap;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.bigkoo.pickerview.OptionsPickerView;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.bean.OccupationVo;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.utils.TxtReader;
import chen.anew.com.zhujiang.utils.VerifyUtil;

/**
 * Created by thinkpad on 2016/7/18.
 */

public class ModifyProfessionActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.right_tv_title)
    TextView rightTvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.select_profession_btn)
    Button selectProfessionBtn;
    private String occupationCode, occupationType, occupationName, newoccupationCode;
    private OptionsPickerView pvOptions;

    private ArrayList<OccupationVo> occupationList;
    private ArrayList<String> optionsItems;

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.occupation));
        rightTvTitle.setText(getResources().getString(R.string.complete));
        initToolBar();
        initLocalData();
        //选项选择器
        occupationCode = Common.userInfo.getOccupationCode();
        if (!TextUtils.isEmpty(occupationCode)) {
            OccupationVo occupationVo = VerifyUtil.getOccupationByoccupationCode(occupationList, occupationCode);
            if (occupationVo != null) {
                occupationCode = occupationVo.getOccupationCode();
                occupationType = occupationVo.getOccupationType();
                occupationName = occupationVo.getOccupationName();
                selectProfessionBtn.setText(occupationName);
            }
        }
        pvOptions = new OptionsPickerView(ModifyProfessionActivity.this);
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg", "-responseBody-" + result);
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String updateResult = jsonObject.getString("updateResult");
                    String resultMessage = jsonObject.getString("resultMessage");
                    if ("1".equals(updateResult)) {
                        Toast.makeText(ModifyProfessionActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                        Common.userInfo.setOccupationCode(newoccupationCode);
                        //创建Intent对象
                        Intent intent = new Intent();
                        //设置Intent的Action属性
                        intent.setAction("CHEN.COM.UPDATEPERSONDATA");
                        intent.putExtra("occupationCode",newoccupationCode);
                        //发送广播,改变地区显示
                        sendBroadcast(intent);
                        MyApp.daoSession.getUserInfoDao().update(Common.userInfo);
                        finish();
                    } else if ("0".equals(updateResult)) {
                        Toast.makeText(ModifyProfessionActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(dialogSubscriber!=null&&dialogSubscriber.isUnsubscribed()){
            dialogSubscriber.unsubscribe();
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_modifyprofession;
    }


    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void initLocalData() {
        // 将本地res中raw文件夹中的txt转化为输入流
        occupationList = new ArrayList<>();
        optionsItems = new ArrayList<>();
        InputStream inputStream2 = getResources().openRawResource(
                R.raw.new_occupation);
        TxtReader.getOccupationList(inputStream2,
                occupationList);
    }

    @OnClick({R.id.right_tv_title, R.id.select_profession_btn})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.right_tv_title:
                if (TextUtils.isEmpty(newoccupationCode)) {
                    finish();
                   // Toast.makeText(ModifyProfessionActivity.this, "请选择职业", Toast.LENGTH_SHORT).show();
              /*  } else if (!TextUtils.isEmpty(occupationCode) && TextUtils.isEmpty(newoccupationCode)) {
                    finish();
                    Toast.makeText(ModifyProfessionActivity.this, "没做任何改动", Toast.LENGTH_SHORT).show();*/
                } else {
                    //提交地区到服务器
                    Gson gson = new Gson();
                    ArrayMap<String, Object> map = new ArrayMap<>();
                    ArrayMap<String, String> map2 = new ArrayMap<>();
                    map2.put("customerId", Common.userInfo.getCustomerId());
                    map2.put("occupationCode", newoccupationCode);

                    map.put("orderType", "32");
                    map.put("platType", "3");
                    map.put("requestObject", map2);
                    String mapjson = gson.toJson(map);
                    MyLogUtil.i("msg","-mapjson-"+mapjson);
                    //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
                    dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, ModifyProfessionActivity.this);
                    OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.editAccountInfoUrl + RequestURL.CreatRequestUrl(mapjson));
                }
                break;
            case R.id.select_profession_btn:
                //岗位选择   初始化
                optionsItems.clear();
                for (int i = 0; i < occupationList.size(); i++) {
                    OccupationVo occupationVo = occupationList.get(i);
                    optionsItems.add(occupationVo.getOccupationName());
                }
                //三级联动效果
                pvOptions.setPicker(optionsItems);
                pvOptions.setCyclic(false);
                //设置默认选中的三级项目
                //监听确定选择按钮
                pvOptions.setSelectOptions(1, 0);
                pvOptions.setCancelable(true);
                pvOptions.show();
                pvOptions.setOnoptionsSelectListener(new OptionsPickerView.OnOptionsSelectListener() {
                    @Override
                    public void onOptionsSelect(int options1, int option2, int options3) {
                        //返回的分别是三个级别的选中位置
                        occupationName = optionsItems.get(options1);
                        OccupationVo occupationVo = VerifyUtil.getOccupationByoccupationName(occupationList, occupationName);
                        newoccupationCode = occupationVo.getOccupationCode();
                        occupationType = occupationVo.getOccupationType();
                        selectProfessionBtn.setText(occupationName);
                    }
                });
                break;
        }
    }
}
