package chen.anew.com.zhujiang.base;

import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;

/**
 * Created by thinkpad on 2016/6/29.
 */
public class MyAnimation {

    private static class SingletonHolder {
        // private static String jsonParam;
        private static final MyAnimation animation = new MyAnimation();
    }
    //获取单例
    public static MyAnimation getInstance() {
        return SingletonHolder.animation;
    }

    public TranslateAnimation getShowAnimation() {
        TranslateAnimation mShowAction = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF,
                -1.0f, Animation.RELATIVE_TO_SELF, 0.0f);
        mShowAction.setDuration(500);
        return mShowAction;
    }

    public TranslateAnimation getHiddenAnimation() {
        TranslateAnimation mHiddenAction = new TranslateAnimation(Animation.RELATIVE_TO_SELF,
                0.0f, Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF,
                -1.0f);
        mHiddenAction.setDuration(500);
        return mHiddenAction;
    }


}
