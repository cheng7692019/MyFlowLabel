package chen.anew.com.zhujiang.activity.guidelogin;

import android.content.Intent;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.bigkoo.pickerview.TimePickerView;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.activity.main.MainActivity;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.utils.VerifyUtil;

/**
 * Created by thinkpad on 2016/6/29.
 */
public class BasicInformationActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.realname_et)
    EditText realnameEt;
    @Bind(R.id.email_et)
    EditText emailEt;
    @Bind(R.id.identification_et)
    EditText identificationEt;
    @Bind(R.id.ischangqi_rb)
    RadioButton ischangqi_rb;

    @Bind(R.id.sex_val)
    TextView sexVal;
    @Bind(R.id.startime_btn)
    Button startimeBtn;
    @Bind(R.id.endtime_btn)
    Button endtimeBtn;
    @Bind(R.id.phone_tv)
    TextView phoneTv;

    //时间选择器
    private TimePickerView pvTime;
    private String validType, starTime, endTime, identification;
    private Date starDate;
    private int age;

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    private HashMap<String, String> map2;

//    right_tv_title

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.perfect_information));
        phoneTv.setText(Common.userInfo.getMobile());
        initToolBar();
        //监听身份证，设置性别
        identificationEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String identification = identificationEt.getText().toString();
                if (identification.length() == 18 | identification.length() == 15) {
                    String sexname = VerifyUtil.getSex(identification);
                    sexVal.setText(sexname);
                    age = VerifyUtil.getAge(identification);
                    if (age > 45) {
                        ischangqi_rb.setChecked(true);
                    } else {
                        ischangqi_rb.setChecked(false);
                    }
                }
            }
        });
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg", "-result-" + result);
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String updateResult = jsonObject.getString("updateResult");
                    if ("1".equals(updateResult)) {
                        Toast.makeText(BasicInformationActivity.this, "设置成功", Toast.LENGTH_SHORT).show();
                        //修改用户信息
                        Common.userInfo.setRealName(map2.get("realName"));
                        Common.userInfo.setSex(map2.get("sex"));
                        Common.userInfo.setEmail(map2.get("email"));
                        Common.userInfo.setIdType("0");
                        Common.userInfo.setIdNo(map2.get("idNo"));

                        Common.userInfo.setValidType(validType);
                        if (!TextUtils.isEmpty(starTime)) {
                            Common.userInfo.setValidStartDate(starTime);
                        }
                        if (!TextUtils.isEmpty(endTime)) {
                            Common.userInfo.setValidEndDate(endTime);
                        }
                        MyApp.daoSession.getUserInfoDao().update(Common.userInfo);
                        startActivity(new Intent(BasicInformationActivity.this, MainActivity.class));
                        finish();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_baseinfo;
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }


    @OnClick({R.id.right_tv_title, R.id.ischangqi_rb, R.id.startime_btn, R.id.endtime_btn})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ischangqi_rb:
                identification = identificationEt.getText().toString();
                if (TextUtils.isEmpty(identification)) {
                    Toast.makeText(BasicInformationActivity.this, "请先填写身份证消息", Toast.LENGTH_SHORT).show();
                } else {
                    if (age > 45) {
                        ischangqi_rb.setChecked(true);
                    } else {
                        ischangqi_rb.setChecked(false);
                    }
                    Toast.makeText(BasicInformationActivity.this, "根据身份证已自动判断", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.right_tv_title:
                //提交资料
                ValPersonInfo();
                break;
            // case R.id.select_sex_relayout:
            //选择性别
               /* new MaterialDialog.Builder(BasicInformationActivity.this)
                        .title(R.string.select_sex)
                        .items(R.array.select_sex)
                        .itemsCallbackSingleChoice(0, new MaterialDialog.ListCallbackSingleChoice() {
                            @Override
                            public boolean onSelection(MaterialDialog dialog, View view, int which, CharSequence text) {
                                Toast.makeText(BasicInformationActivity.this, which + "-onSelection-" + text, Toast.LENGTH_SHORT).show();
                                return true;
                            }
                        })
                        .positiveText("选择")
                        .show();*/
            //   break;
            case R.id.startime_btn:
                identification = identificationEt.getText().toString();
                if (TextUtils.isEmpty(identification)) {
                    Toast.makeText(BasicInformationActivity.this, "请先填写身份证消息", Toast.LENGTH_SHORT).show();
                } else {
                    if (ischangqi_rb.isChecked()) {
                        Toast.makeText(BasicInformationActivity.this, "长期不用选证件有限期", Toast.LENGTH_SHORT).show();
                    } else {
                        pvTime = new TimePickerView(BasicInformationActivity.this, TimePickerView.Type.YEAR_MONTH_DAY);
                        pvTime.setCancelable(true);
                        pvTime.show();
                        pvTime.setOnTimeSelectListener(new TimePickerView.OnTimeSelectListener() {
                            @Override
                            public void onTimeSelect(Date date) {
                                starDate = date;
                                starTime = getTime(starDate);
                                startimeBtn.setText(starTime);
                                //Toast.makeText(BasicInformationActivity.this, "-time-" + starTime, Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }
                break;
            case R.id.endtime_btn:
                identification = identificationEt.getText().toString();
                if (TextUtils.isEmpty(identification)) {
                    Toast.makeText(BasicInformationActivity.this, "请先填写身份证消息", Toast.LENGTH_SHORT).show();
                } else {
                    if (ischangqi_rb.isChecked()) {
                        Toast.makeText(BasicInformationActivity.this, "长期不用选证件有限期", Toast.LENGTH_SHORT).show();
                    } else {
                        if (TextUtils.isEmpty(starTime)) {
                            Toast.makeText(BasicInformationActivity.this, "请先选开始时间", Toast.LENGTH_SHORT).show();
                        } else {
                            pvTime = new TimePickerView(BasicInformationActivity.this, TimePickerView.Type.YEAR_MONTH_DAY);
                            pvTime.setCancelable(true);
                            pvTime.show();
                            pvTime.setOnTimeSelectListener(new TimePickerView.OnTimeSelectListener() {
                                @Override
                                public void onTimeSelect(Date date) {
                                    Date currentDate = new Date();
                                    if (date.compareTo(starDate) < 0) {
                                        Toast.makeText(BasicInformationActivity.this, "结束时间不得小于开始时间", Toast.LENGTH_SHORT).show();
                                    } else if (date.compareTo(currentDate) < 0) {
                                        Toast.makeText(BasicInformationActivity.this, "结束时间不得小于当前时间", Toast.LENGTH_SHORT).show();
                                    } else {
                                        endTime = getTime(date);
                                        endtimeBtn.setText(endTime);
                                        //Toast.makeText(BasicInformationActivity.this, "-time-" + endTime, Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                        }
                    }
                }
                break;
        }
    }

    private static String getTime(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        return format.format(date);
    }

    private void ValPersonInfo() {
        //提交个人资料
        String realname = realnameEt.getText().toString();
        String email = emailEt.getText().toString();
        String identification = identificationEt.getText().toString();
        boolean flag = ischangqi_rb.isChecked();
        // 中文表达式
        Pattern chinesePattern = Pattern
                .compile("^[\\u4E00-\\u9FA5\\uF900-\\uFA2D]+$");
        // 身份证正则表达式
        Pattern idPattern = Pattern.compile("^(\\d{14}|\\d{17})(\\d|[xX])$");
        //邮箱正则表达式
        Pattern emailPattern = Pattern.compile("^\\s*\\w+(?:\\.{0,1}[\\w-]+)*@[a-zA-Z0-9]+(?:[-.][a-zA-Z0-9]+)*\\.[a-zA-Z]+\\s*$");
        // 匹配器
        Matcher matcher = chinesePattern.matcher(realname);
        Matcher emailMatcher = emailPattern.matcher(email);
        Matcher identificationmatcher = idPattern.matcher(identification);
        if (!matcher.matches()) {
            Toast.makeText(BasicInformationActivity.this, "请输入中文姓名", Toast.LENGTH_SHORT).show();
        } else if (!emailMatcher.matches()) {
            Toast.makeText(BasicInformationActivity.this, "邮箱格式不对", Toast.LENGTH_SHORT).show();
        } else if (!identificationmatcher.matches()) {
            Toast.makeText(BasicInformationActivity.this, "身份证号码格式不对", Toast.LENGTH_SHORT).show();
        } else if (!flag && (TextUtils.isEmpty(starTime) | TextUtils.isEmpty(endTime))) {
            //长期
            Toast.makeText(BasicInformationActivity.this, "证件有限期不得为空", Toast.LENGTH_SHORT).show();
        } else {
            //提交数据
            Gson gson = new Gson();
            HashMap<String, Object> map = new HashMap<>();
            map2 = new HashMap<>();
            map2.put("customerId", Common.userInfo.getCustomerId());
            map2.put("realName", realname);
            String sexname = VerifyUtil.getSex(identification);
            if (sexname.equals("男")) {
                map2.put("sex", "0");
            } else if (sexname.equals("女")) {
                map2.put("sex", "1");
            }
            map2.put("email", email);
            map2.put("idNo", identification);
            map2.put("idType", "0");
            if (flag) {
                validType = "2";
                map2.put("validType", "2");//2是长期
            } else {
                validType = "1";
                map2.put("validType", "1");//1是指定时间
                map2.put("validStartDate", starTime);
                map2.put("validEndDate", endTime);
            }
            map.put("orderType", "32");
            map.put("platType", "3");
            map.put("requestObject", map2);
            String mapjson = gson.toJson(map);
            //Log.i("msg","-mapjson-"+mapjson);
            //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
            dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, BasicInformationActivity.this);
            OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.editAccountInfoUrl + RequestURL.CreatRequestUrl(mapjson));
        }
    }
}
