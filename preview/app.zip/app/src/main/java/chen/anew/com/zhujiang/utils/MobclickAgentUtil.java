package chen.anew.com.zhujiang.utils;

import android.content.Context;

import com.umeng.analytics.MobclickAgent;

/**
 * Created by thinkpad on 2016/9/6.
 */
public class MobclickAgentUtil {

    public static void closeActivityDurationTrack(Context context) {
        MobclickAgent.setDebugMode(true);
        // SDK在统计Fragment时，需要关闭Activity自带的页面统计，
        // 然后在每个页面中重新集成页面统计的代码(包括调用了 onResume 和 onPause 的Activity)。
        MobclickAgent.openActivityDurationTrack(false);
        MobclickAgent.setScenarioType(context, MobclickAgent.EScenarioType.E_UM_NORMAL);
    }
}
