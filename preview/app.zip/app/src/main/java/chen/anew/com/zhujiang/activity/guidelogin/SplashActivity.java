package chen.anew.com.zhujiang.activity.guidelogin;

import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.igexin.sdk.PushManager;
import com.readystatesoftware.systembartint.SystemBarTintManager;

import org.greenrobot.greendao.query.Query;

import java.util.List;

import butterknife.Bind;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.activity.main.MainActivity;
import chen.anew.com.zhujiang.activity.mine.setup.FullPatternLockActivity;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.greendao.UserInfo;
import chen.anew.com.zhujiang.greendao.UserInfoDao;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.utils.SharedPreferencesUtils;
import chen.anew.com.zhujiang.utils.ViewUtils;

/**
 * Created by thinkpad on 2016/6/27.
 */
public class SplashActivity extends BaseAppActivity {

    @Bind(R.id.gif_iv)
    ImageView gifIv;
    private UserInfoDao userDao;
    @Override
    protected int getStatusBarColor() {
        return -1;
    }

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    @Override
    protected void initViews() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ViewUtils.setTranslucentStatus(SplashActivity.this,true);
            SystemBarTintManager tintManager = new SystemBarTintManager(this);
            // enable status bar tint
            tintManager.setStatusBarTintEnabled(true);
            // enable navigation bar tint
            tintManager.setNavigationBarTintEnabled(true);
            tintManager.setTintColor(ContextCompat.getColor(this, R.color.transparent));
        }
        // SDK初始化，第三方程序启动时，都要进行SDK初始化工作
        PushManager.getInstance().initialize(this.getApplicationContext());
        Glide.with(SplashActivity.this).load(R.drawable.splash)
                .asGif()
                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                .into(gifIv);
        /*subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                Gson gson = new Gson();
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String loginResult = jsonObject.getString("loginResult");
                    if ("0".equals(loginResult)) {
                        Toast.makeText(SplashActivity.this, "" + jsonObject.getString("resultMessage"), Toast.LENGTH_SHORT).show();
                    } else if ("1".equals(loginResult)) {
                        startActivity(new Intent(SplashActivity.this, MainActivity.class));
                        //每次登录覆盖之前的账户信息
                        UserInfo userInfo = gson.fromJson(jsonObject.getString("userInfo").toString(), UserInfo.class);
                        Common.userInfo = userInfo;
                        Common.customer_id = userInfo.getCustomerId();
                        userDao.insertOrReplace(userInfo);
                        finish();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };*/

        handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    String customer_id = (String) SharedPreferencesUtils.getParam(SplashActivity.this, SharedPreferencesUtils.CUSTOMER_ID, "");
                                    MyLogUtil.i("msg", "-customer_id-" + customer_id);
                                    Common.customer_id = customer_id;
                                    //登录状态
                                    if (!TextUtils.isEmpty(customer_id)) {
                                        userDao = MyApp.daoSession.getUserInfoDao();
                                        Query query = userDao.queryBuilder().where(
                                                UserInfoDao.Properties.CustomerId.eq(Common.customer_id))
                                                .build();
                                        List userList = query.list();
                                        Common.userInfo = (UserInfo) userList.get(0);
                                        boolean is_open_lock = (boolean) SharedPreferencesUtils.getParam(SplashActivity.this, SharedPreferencesUtils.IS_OPEN_LOCK + customer_id, false);
                                        if (is_open_lock) {
                                            startActivity(new Intent(SplashActivity.this, FullPatternLockActivity.class));
                                            finish();
                                        } else {
                                            //自动登录
                                            startActivity(new Intent(SplashActivity.this, MainActivity.class));
                                            finish();
                                            // handler.obtainMessage(Common.REFRESH_DATA_FINISH).sendToTarget();
                                        }
                                    } else {
                                        //无登录状态
                                        startActivity(new Intent(SplashActivity.this, MainActivity.class));
                                        finish();
                                    }
                                }/* else {
                    //程序在前台
                    if (!TextUtils.isEmpty(customer_id)) {
                        //自动登录
                        handler.obtainMessage(Common.REFRESH_DATA_FINISH).sendToTarget();
                    } else {
                        startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                        finish();
                    }
                }*/
                                // }
                            }
                , 3000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
    }

    private Handler handler = new Handler() {
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case Common.REFRESH_DATA_FINISH:
                    //UserInfo userInfo = (UserInfo) SharedPreferencesUtils.getUserInfo(SplashActivity.this, SharedPreferencesUtils.CUSTOMER_USER + Common.customer_id);
                    /*userDao = MyApp.daoSession.getUserInfoDao();
                    Query query = userDao.queryBuilder().where(
                            UserInfoDao.Properties.CustomerId.eq(Common.customer_id))
                            .build();
                    List userList = query.list();
                    UserInfo userInfo = (UserInfo) userList.get(0);
                    String customer_password = (String) SharedPreferencesUtils.getParam(SplashActivity.this, SharedPreferencesUtils.CUSTOMER_PASSWORD, "");
                    loginRemote(userInfo.getMobile(), customer_password);*/
                    break;
            }
        }
    };

    /*private void loginRemote(String phone, String pass) {
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("user", phone);
        map2.put("password", pass);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, SplashActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.LoginUrl + RequestURL.CreatRequestUrl(mapjson));
    }*/


    @Override
    protected int getContentViewId() {
        return R.layout.activity_splash;
    }

}
