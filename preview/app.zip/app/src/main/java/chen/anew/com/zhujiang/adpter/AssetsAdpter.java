package chen.anew.com.zhujiang.adpter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.HashMap;

import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.bean.MyAssets;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.CommonSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;

/**
 * Created by thinkpad on 2016/6/30.
 */
public class AssetsAdpter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public ArrayList<MyAssets> datas = null;
    public Context context;
    private CommonSubscriber commonSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    public AssetsAdpter(ArrayList<MyAssets> datas, Context context) {
        this.context = context;
        this.datas = datas;
    }

  /*  private static ClickListener clickListener;

    public interface ClickListener {
        void onItemClick(int position, View v);
    }

    public void setOnItemClickListener(ClickListener clickListener) {
        this.clickListener = clickListener;
    }*/


    public void updateView(ArrayList<MyAssets> datas) {
        this.datas = datas;
        this.notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_myassets, viewGroup, false);
        return new ViewHolder(view);
    }


    //将数据与界面进行绑定的操作
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {
        final MyAssets contList = datas.get(position);
        final ViewHolder viewHolder = (ViewHolder) holder;
        viewHolder.product_name.setText(contList.getMainRiskName());
        viewHolder.yesterdayincome_tv.setText(contList.getDayTotalAmnt());
        viewHolder.insured_number_tv.setText("保单号：  "+contList.getContNo());
        viewHolder.countaccountvalue_tv.setText(contList.getInsuaccbala());
        //异步更新保单价值
        /*subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                Log.i("msg", "contValue" + result);
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String resultCode = jsonObject.getString("resultCode");
                    if ("1".equals(resultCode)) {
                        viewHolder.countaccountvalue_tv.setText(jsonObject.getString("contValue"));
                    } else {
                        viewHolder.countaccountvalue_tv.setText("0.00");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        getContValue(contList.getContNo());*/
    }

    @Override
    public void onViewRecycled(RecyclerView.ViewHolder holder) {
        super.onViewRecycled(holder);
        if (commonSubscriber != null && commonSubscriber.isUnsubscribed()) {
            commonSubscriber.unsubscribe();
        }
    }

    //获取数据的数量
    @Override
    public int getItemCount() {
        return datas.size();
    }


    //自定义的ViewHolder，持有每个Item的的所有界面元素
    static  class ViewHolder extends RecyclerView.ViewHolder {
        public TextView product_name, countaccountvalue_tv, yesterdayincome_tv,insured_number_tv;

        public ViewHolder(View view) {
            super(view);
//            view.setOnClickListener(this);
            product_name = (TextView) view.findViewById(R.id.product_name);
            countaccountvalue_tv = (TextView) view.findViewById(R.id.countaccountvalue_tv);
            yesterdayincome_tv = (TextView) view.findViewById(R.id.yesterdayincome_tv);
            insured_number_tv= (TextView) view.findViewById(R.id.insured_number_tv);

        }

//        @Override
//        public void onClick(View view) {
//            clickListener.onItemClick(getAdapterPosition(), view);
//        }

    }

    private void getContValue(String contNoPass) {
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("contNo", contNoPass);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        commonSubscriber = new CommonSubscriber<>(subscriberOnNextListener, context);
        OkHttpObservable.getInstance().getData(commonSubscriber, RequestURL.GetContValueByContNoUrl + RequestURL.CreatRequestUrl(mapjson));
    }


}

