package chen.anew.com.zhujiang.bean;

import java.io.Serializable;

/**
 * Created by thinkpad on 2016/7/25.
 */
public class DescriptionList implements Serializable {

    private String descName;

    private String desc;

    public void setDescName(String descName) {
        this.descName = descName;
    }

    public String getDescName() {
        return this.descName;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return this.desc;
    }

}
