package chen.anew.com.zhujiang.net;

public class WebViewURL {

	//产品详情页面
	public static String ProduceDetailURL = RequestURL.ESERVICE_7003 + "/appweb/DetailHtml/chxq_3Tab_main.html";
	public static String ImportantNotice = RequestURL.ESERVICE_7003 + "/appweb/DetailHtml/chxq_3Tab_notice.html";
	public static String InfoDisclosure = RequestURL.ESERVICE_7003 + "/appweb/DetailHtml/chxq_3Tab_info.html";

}
