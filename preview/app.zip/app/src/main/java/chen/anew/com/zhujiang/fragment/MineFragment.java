package chen.anew.com.zhujiang.fragment;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;

import org.greenrobot.greendao.query.Query;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.activity.guidelogin.LoginActivity;
import chen.anew.com.zhujiang.activity.main.MessageActivity;
import chen.anew.com.zhujiang.activity.mine.MyAssetsActivity;
import chen.anew.com.zhujiang.activity.mine.MyPolicyActivity;
import chen.anew.com.zhujiang.activity.mine.OrderActivity;
import chen.anew.com.zhujiang.activity.mine.about.AboutWeActivity;
import chen.anew.com.zhujiang.activity.mine.persondata.MyPersonalData;
import chen.anew.com.zhujiang.activity.mine.setup.SetActivity;
import chen.anew.com.zhujiang.base.BaseFragment;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.greendao.MessageBean;
import chen.anew.com.zhujiang.greendao.MessageBeanDao;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.CommonSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.widget.MyGridView;
import de.hdodenhof.circleimageview.CircleImageView;


/**
 * Created by thinkpad on 2016/7/1.
 */

public class MineFragment extends BaseFragment {

    @Bind(R.id.mine_logo_iv)
    CircleImageView mineLogoIv;
    @Bind(R.id.mine_gridView)
    MyGridView mineGridView;
    @Bind(R.id.mine_name_tv)
    TextView mineNameTv;
    @Bind(R.id.mine_yesterdayincome_tv)
    TextView mineYesterdayincomeTv;
    @Bind(R.id.textView2)
    TextView textView2;
    @Bind(R.id.mine_now_totalsum_tv)
    TextView mineNowTotalsumTv;
    @Bind(R.id.mine_accumulative_totalincome_tv)
    TextView mineAccumulativeTotalincomeTv;
    @Bind(R.id.mainscrollview)
    ScrollView mainscrollview;

    @Bind(R.id.toolbar)
    Toolbar toolbar;

    private SimpleAdapter adapter;
    private List<Map<String, Object>> data_list;
    private int[] icon = {R.mipmap.mine_warranty_normorl,
            R.mipmap.mine_order_normorl, R.mipmap.mine_logo_normorl,
            R.mipmap.mine_setting_normal,
            R.mipmap.mine_servicehotline_normal,
            R.mipmap.mine_about_normal};
    private String[] iconName = {"保单", "订单", "个人资料", "设置", "客服热线", "关于我们"};

    private CommonSubscriber commonSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    public static String accountAsset = "", dayTotalAmnt = "", totalIncome = "";

    MessageHintReceiver receiver;
    private MessageBeanDao messageBeanDao;

    public static MineFragment newInstance() {
        MineFragment mineFragment = new MineFragment();
        return mineFragment;
    }

    @Override
    protected void initViews() {
        mPageName="MineFragment";
        //设背景为透明
        mineGridView.setSelector(new ColorDrawable(Color.TRANSPARENT));
        // 新建List
        data_list = new ArrayList<>();
        // 获取数据
        getData();
        initToolBar();
        // 新建适配器
        String[] from = {"image", "text"};
        int[] to = {R.id.image, R.id.text};
        adapter = new SimpleAdapter(getActivity(), data_list,
                R.layout.gridiew_item, from, to);
        mineGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (Common.userInfo != null) {
                    switch (position) {
                        case 0:
                            startActivity(new Intent(getActivity(), MyPolicyActivity.class));
                            break;
                        case 1:
                            startActivity(new Intent(getActivity(), OrderActivity.class));
                            break;
                        case 2:
                            startActivity(new Intent(getActivity(), MyPersonalData.class));
                            break;
                        case 3:
                            startActivity(new Intent(getActivity(), SetActivity.class));
                            break;
                        case 4:
                            //显示客服对话框
                            showCall();
                            break;
                        case 5:
                            startActivity(new Intent(getActivity(), AboutWeActivity.class));
                            break;
                    }
                } else {
                    Toast.makeText(getActivity(), "请先登录", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getActivity(), LoginActivity.class));
                }
            }
        });
        // 配置适配器
        mineGridView.setAdapter(adapter);
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                try {
                    if (!TextUtils.isEmpty(result)) {
                        JSONObject jsonObject = new JSONObject(result);
                        JSONObject json = new JSONObject(jsonObject.getString("assetResponseObject"));
                        accountAsset = json.getString("accountAsset");
                        dayTotalAmnt = json.getString("dayTotalAmnt");
                        totalIncome = json.getString("totalIncome");
                        mineYesterdayincomeTv.setText(dayTotalAmnt);
                        mineNowTotalsumTv.setText(accountAsset);
                        mineAccumulativeTotalincomeTv.setText(totalIncome);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        if (Common.userInfo != null) {
            initMyAssets();
        }
        //初始化，并且注册广播信息
        receiver = new MessageHintReceiver();
        IntentFilter filter = new IntentFilter("CHEN.COM.UPDATEPERSONDATA_MINE");
        getActivity().registerReceiver(receiver, filter);
        initData();
    }

    private void initToolBar() {
        ((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle(" ");
        //判断是否存在未读的消息
        if (!TextUtils.isEmpty(Common.customer_id)) {
            messageBeanDao = MyApp.daoSession.getMessageBeanDao();
            Query query = messageBeanDao.queryBuilder().where(
                    MessageBeanDao.Properties.CustomerId.eq(Common.customer_id), MessageBeanDao.Properties.IsRead.eq("N"))
                    .build();
            List<MessageBean> messageList = (List<MessageBean>) query.list();
            if (messageList != null & messageList.size() > 0) {
                ((AppCompatActivity) getActivity()).getSupportActionBar().setHomeAsUpIndicator(R.mipmap.message_red_white);
            }else{
                ((AppCompatActivity) getActivity()).getSupportActionBar().setHomeAsUpIndicator(R.mipmap.message_white);
            }
        }
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), MessageActivity.class));
            }
        });
    }

    public class MessageHintReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            int img_red = intent.getIntExtra("img_red", -1);
            if (img_red == 1) {
                ((AppCompatActivity) getActivity()).getSupportActionBar().setHomeAsUpIndicator(R.mipmap.message_red_white);
            } else if (img_red == 0) {
                ((AppCompatActivity) getActivity()).getSupportActionBar().setHomeAsUpIndicator(R.mipmap.message_white);
            }
            String headimgUrl = intent.getStringExtra("headimgUrl");
            if (!TextUtils.isEmpty(headimgUrl)) {
                Glide.with(getActivity()).load(headimgUrl)
                        .error(R.mipmap.defaulthead)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .centerCrop()
                        .into(mineLogoIv);
            }
            String realName = intent.getStringExtra("realname");
            if (!TextUtils.isEmpty(headimgUrl)) {
                mineNameTv.setText(realName);
            }
            boolean refush_assets = intent.getBooleanExtra("refush_assets", false);
            if(refush_assets){
                initMyAssets();
            }
        }
    }

    private void initData() {
        if (Common.userInfo != null) {
            Glide.with(getActivity()).load(Common.userInfo.getHeadimgurl())
                    .error(R.mipmap.defaulthead)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .centerCrop()
                    .into(mineLogoIv);
            mineNameTv.setText(Common.userInfo.getRealName());
        }
    }

   /* @Override
    public void onResume() {
        super.onResume();
        initData();
    }*/

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (commonSubscriber != null && commonSubscriber.isUnsubscribed()) {
            commonSubscriber.unsubscribe();
        }
        if(receiver!=null){
            getActivity().unregisterReceiver(receiver);
        }
    }

    public List<Map<String, Object>> getData() {
        // cion和iconName的长度是相同的，这里任选其一都可以
        for (int i = 0; i < icon.length; i++) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("image", icon[i]);
            map.put("text", iconName[i]);
            data_list.add(map);
        }
        return data_list;
    }

    @Override
    protected int getContentViewId() {
        return R.layout.fragment_mine;
    }


    private void showCall() {
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View layout = inflater.inflate(R.layout.set_dialgo,
                (ViewGroup) getActivity().findViewById(R.id.setdia_linear));
        final Button cacle_btn = (Button) layout.findViewById(R.id.cacle_btn);
        final Button setpaypass_btn = (Button) layout.findViewById(R.id.setpaypass_btn);
        final TextView content_tv = (TextView) layout.findViewById(R.id.content_tv);
        String phone = "400-886-5987";
        SpannableString spanClause = new SpannableString(phone);
        content_tv.setText(R.string.called_customer);
        spanClause.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorAccent)), 0, phone.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        content_tv.append(spanClause);
        cacle_btn.setText(R.string.call);
        setpaypass_btn.setText(R.string.cancle);
        final MaterialDialog materialDialog = new MaterialDialog.Builder(getActivity())
                .title(R.string.call_hotline)
                .customView(layout, true)
                .show();
        cacle_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                materialDialog.dismiss();
                if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                    Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:4008865987"));
                    startActivity(intent);
                }
            }
        });
        setpaypass_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //设置
                materialDialog.dismiss();
            }
        });
    }


    @OnClick({R.id.mine_logo_iv, R.id.mine_yesterdayincome_rl, R.id.mine_accumulatedassets_ll})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.mine_logo_iv:
                if (Common.userInfo != null) {
                    startActivity(new Intent(getActivity(), MyPersonalData.class));
                } else {
                    Toast.makeText(getActivity(), "请先登录", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getActivity(), LoginActivity.class));
                }
                break;
            case R.id.mine_yesterdayincome_rl:
                break;
            case R.id.mine_accumulatedassets_ll:
                startActivity(new Intent(getActivity(), MyAssetsActivity.class));
                break;
        }
    }

    private void initMyAssets() {

        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();

        map2.put("customerId", Common.userInfo.getCustomerId());
        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        commonSubscriber = new CommonSubscriber(subscriberOnNextListener, getActivity());
        OkHttpObservable.getInstance().getData(commonSubscriber, RequestURL.GetAssetInfoUrl + RequestURL.CreatRequestUrl(mapjson));

    }
}
