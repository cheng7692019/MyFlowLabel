package chen.anew.com.zhujiang.utils;

import android.content.Context;
import android.text.TextUtils;
import android.widget.Toast;

import com.tencent.mm.sdk.openapi.IWXAPI;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import chen.anew.com.zhujiang.bean.CityVo;
import chen.anew.com.zhujiang.bean.OccupationVo;
import chen.anew.com.zhujiang.bean.ProvinceVo;

/**
 * Created by thinkpad on 2016/6/28.
 */
public class VerifyUtil {

    //手机号格式验证
    public static boolean VerificationPhone(String phone) {
        Pattern pattern = Pattern
                .compile("^((13[0-9])|(15[^4,\\D])|(170)|(18[0-9]))\\d{8}$");
        Matcher matcher = pattern.matcher(phone);
        if (matcher.matches()) {
            return true;
        } else {
            return false;
        }
    }

    //字符串去掉空格
    public static String clearStr(String str){
        return str.replaceAll("\\s*", "");
    }

    //中文
    public static boolean isChinse(String str) {
        Pattern pattern = Pattern
                .compile("^[\\u4E00-\\u9FA5\\uF900-\\uFA2D]+$");
        Matcher matcher = pattern.matcher(str);
        if (matcher.matches()) {
            return true;
        } else {
            return false;
        }
    }

    //邮箱
    public static boolean checkEmail(String str) {
        Pattern pattern = Pattern
                .compile("^\\s*\\w+(?:\\.{0,1}[\\w-]+)*@[a-zA-Z0-9]+(?:[-.][a-zA-Z0-9]+)*\\.[a-zA-Z]+\\s*$");
        Matcher matcher = pattern.matcher(str);
        if (matcher.matches()) {
            return true;
        } else {
            return false;
        }
    }

    // 身份证正则表达式
    public static boolean checkIdNo(String str) {
        Pattern pattern = Pattern
                .compile("^(\\d{14}|\\d{17})(\\d|[xX])$");
        Matcher matcher = pattern.matcher(str);
        if (matcher.matches()) {
            return true;
        } else {
            return false;
        }
    }
    //根据身份证号码判断性别
    public static String getSex(String value) {
        value = value.trim();
        if (value == null || (value.length() != 15 && value.length() != 18)) {
            return "";
        }
        if (value.length() == 18) {
            String lastValue = value.substring(16, 17);
            int sex = Integer.parseInt(lastValue) % 2;
            return sex == 0 ? "女" : "男";
        } else if (value.length() == 15) {
            String lastValue = value.substring(13, 14);
            int sex = Integer.parseInt(lastValue) % 2;
            return sex == 0 ? "女" : "男";
        }else{
            return "";
        }
    }

    //根据身份证号码获得年龄
    public static int getAge(String identification) {
        int age=0;
        GregorianCalendar currentDay;
        GregorianCalendar beforeDay;
        // 生日日期
        Date birthday = null;
        // 生日日期字符
        String birthdayStr;
        // 生日那年
        int birthYear;
        // 今年
        int currentYear;
        if (identification.length() == 18) {
            birthdayStr = identification.substring(6, 14);
            try {
                birthday = new SimpleDateFormat("yyyyMMdd")
                        .parse(birthdayStr);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            beforeDay = new GregorianCalendar();
            beforeDay.setTime(birthday);
            birthYear = beforeDay.get(Calendar.YEAR);
            currentDay = new GregorianCalendar();
            currentDay.setTime(new Date());
            currentYear = currentDay.get(Calendar.YEAR);
            age = currentYear - birthYear;
        }else if (identification.length() == 15) {
            birthdayStr = "19" + identification.substring(6, 12);
            try {
                birthday = new SimpleDateFormat("yyyyMMdd")
                        .parse(birthdayStr);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            beforeDay = new GregorianCalendar();
            beforeDay.setTime(birthday);
            birthYear = beforeDay.get(Calendar.YEAR);

            currentDay = new GregorianCalendar();
            currentDay.setTime(new Date());
            currentYear = currentDay.get(Calendar.YEAR);
            age = currentYear - birthYear;
        }
        return age;
    }

    public static String getBir(String IdNo){
        String result="";
        if (IdNo.length()==18){
            result=IdNo.substring(6,14);
        }
        if (IdNo.length()==15){
            result= "19"+IdNo.substring(6,12);
        }
        result=result.substring(0,4)+"-"+result.substring(4,6)+"-"+result.substring(6,8);
        return result;
    }

    //是否是数字
    public static boolean checkNumber(String value) {
        String regex = "^(-?[1-9]\\d*\\.?\\d*)|(-?0\\.\\d*[1-9])|(-?[0])|(-?[0]\\.\\d*)$";
        return value.matches(regex);
    }

    //保留2位小数
    public static double roundTo2(double value){
        return Math.round( value * 100 ) / 100.0;
    }

    //获取中文长度
    public static int getWordCount(String s)
    {
        int length = 0;
        for(int i = 0; i < s.length(); i++)
        {
            int ascii = Character.codePointAt(s, i);
            if(ascii >= 0 && ascii <=255)
                length++;
            else
                length += 2;

        }
        return length;

    }

    /**
     * 得到二个日期间的间隔天数
     */
    public static Long getTwoDay(String sj1, String sj2) {
        SimpleDateFormat myFormatter = new SimpleDateFormat("yyyy-MM-dd");
        long day = 0;
        try {
            java.util.Date date = myFormatter.parse(sj1);
            java.util.Date mydate = myFormatter.parse(sj2);
            day = (date.getTime() - mydate.getTime()) / (24 * 60 * 60 * 1000);
        } catch (Exception e) {
            return 0l;
        }
        return day;
    }

    /**
     * 根据省份id获取城市列表
     */
    public static ArrayList<String> getCityListByProviceCode(ArrayList<CityVo>cityList,String provincePostCode){
        //
        ArrayList<String>cityName=new ArrayList<>();
        for (CityVo cv : cityList) {
            if (cv.getProvincePostCode().equals(provincePostCode)) {
                cityName.add(cv.getCityName());
            }
        }
        return cityName;
    }

    /**
     * 根据省份名称获取省份id
     */
    public static String getProviceCodeByProviceName(ArrayList<ProvinceVo>provinceVoArrayList, String provinceName){
        String proviceCode="";
        for (ProvinceVo provinceVo : provinceVoArrayList) {
            if (provinceVo.getProvinceName().equals(provinceName)) {
                proviceCode=provinceVo.getProvincePostCode();
            }
        }
        return proviceCode;
    }

    /**
     * 根据城市名称获取城市id
     */
    public static String getcityCodeBycityName(ArrayList<CityVo>cityVoArrayList, String cityName){
        String cityCode="";
        for (CityVo cityVo : cityVoArrayList) {
            if (cityVo.getCityName().equals(cityName)) {
                cityCode=cityVo.getCityPostCode();
            }
        }
        return cityCode;
    }


    /**
     * 根据行业id获取岗位列表
     */
    public static ArrayList<String> getOccupationListByIndustryCode(ArrayList<OccupationVo> occupationList, String industryCode){
        ArrayList<String>occupationName=new ArrayList<>();
        for (OccupationVo occupationVo : occupationList) {
            if (occupationVo.getOccupationType().equals(industryCode)) {
                occupationName.add(occupationVo.getOccupationName());
            }
        }
        return occupationName;
    }

    /**
     * 根据行业code获取行业
     */
    public static OccupationVo getOccupationByoccupationCode(ArrayList<OccupationVo>occupationVoArrayList, String occupationCode){
        OccupationVo new_occupationVo=null;
        for (OccupationVo occupationVo : occupationVoArrayList) {
            if (occupationCode.equals(occupationVo.getOccupationCode())) {
                new_occupationVo=occupationVo;
            }
        }
        return new_occupationVo;
    }

    /**
     * 根据岗位名称获取岗位id
     */
    public static OccupationVo getOccupationByoccupationName(ArrayList<OccupationVo>occupationVoArrayList, String occupationName){
        OccupationVo new_occupationVo=null;
        for (OccupationVo occupationVo : occupationVoArrayList) {
            if (occupationName.equals(occupationVo.getOccupationName())) {
                new_occupationVo=occupationVo;
            }
        }
        return new_occupationVo;
    }

    //判断手机是否安装微信
    public static boolean isWXAppInstalledAndSupported(Context context,
                                                        IWXAPI api) {
       boolean sIsWXAppInstalledAndSupported = api.isWXAppInstalled()
                && api.isWXAppSupportAPI();
        if (!sIsWXAppInstalledAndSupported) {
            Toast.makeText(context, "微信客户端未安装，请确认",Toast.LENGTH_SHORT).show();
        }
        return sIsWXAppInstalledAndSupported;
    }

    //用星号代替手机号码中间字符
    public static String encryptPhone(String phone) {
        String encryptionPhone = phone;
        if (!TextUtils.isEmpty(phone) && phone.length() > 7) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < phone.length(); i++) {
                char c = phone.charAt(i);
                if (i >= 3 && i <= 7) {
                    sb.append('*');
                } else {
                    sb.append(c);
                }
            }
            encryptionPhone = sb.toString();
        }
        return encryptionPhone;
    }

    //用星号代替身份证号码中间字符
    public static String encryptIdNo(String IdNo) {
        String encryptionIdNo = IdNo;
        if (!TextUtils.isEmpty(IdNo) && IdNo.length() > 14) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < IdNo.length(); i++) {
                char c = IdNo.charAt(i);
                if (i >= 3 && i <= 14) {
                    sb.append('*');
                } else {
                    sb.append(c);
                }
            }
            encryptionIdNo = sb.toString();
        }
        return encryptionIdNo;
    }

}
