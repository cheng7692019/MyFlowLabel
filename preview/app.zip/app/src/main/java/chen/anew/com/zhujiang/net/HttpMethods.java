package chen.anew.com.zhujiang.net;

import android.text.TextUtils;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import chen.anew.com.zhujiang.bean.ResponseBody;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by liukun on 16/3/9.
 */
public class HttpMethods {

    public static String BASE_URL = "https://api.douban.com/v2/movie/";

    private static final int DEFAULT_TIMEOUT = 5;

//    private Retrofit retrofit;
    private MovieService movieService;

    //构造方法私有
   /* private HttpMethods() {
        //手动创建一个OkHttpClient并设置超时时间
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.connectTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS);

        retrofit = new Retrofit.Builder()
                .client(builder.build())
//                .client(getTokenClient())
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
               // .baseUrl(MovieService.GANK_URL)
                .build();

        movieService = retrofit.create(MovieService.class);
    }*/

    //构造方法私有
    private HttpMethods() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.connectTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS);

      /*  retrofit = new Retrofit.Builder()
                .client(builder.build())
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .baseUrl(RequestURL.Host)
                .build();
        movieService = retrofit.create(MovieService.class);*/
    }

    public static OkHttpClient getTokenClient(final String jsonParam) {
        OkHttpClient httpClient = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .addInterceptor(new Interceptor() {
                    @Override
                    public Response intercept(Chain chain) throws IOException {
                        Request request=null;
                        if(!TextUtils.isEmpty(jsonParam)){
                            RequestBody formBody = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), jsonParam);
                             request = chain.request()
                                    .newBuilder()
//                                    .addHeader("platType", "3")
//                                    .addHeader("orderType", "32")
                                    .post(formBody)
                                    .build();
                        }else{
                            request = chain.request()
                                    .newBuilder()
                                    .addHeader("platType", "3")
                                    .addHeader("orderType", "32")
                                    .build();
                        }
                        return chain.proceed(request);
                    }
                })
                .build();
        return httpClient;
    }

    //在访问HttpMethods时创建单例
    private static class SingletonHolder {
       // private static String jsonParam;
        private static final HttpMethods TOKEN_INSTANCE = new HttpMethods();
    }

    //获取单例
    public static HttpMethods getInstance() {
        //SingletonHolder.jsonParam=jsonParam;
        return SingletonHolder.TOKEN_INSTANCE;
    }

    //在访问HttpMethods时创建单例
  /*  private static class SingletonHolder {
        private static final HttpMethods INSTANCE = new HttpMethods();
    }

    //获取单例
    public static HttpMethods getInstance() {
        return SingletonHolder.INSTANCE;
    }*/

    /**
     * 用于获取豆瓣电影Top250的数据
     */
   /* public void getTopMovie(Subscriber<List<Subject>> subscriber, int start, int count) {

//        movieService.getTopMovie(start, count)
//                .map(new HttpResultFunc<List<Subject>>())
//                .subscribeOn(Schedulers.io())
//                .unsubscribeOn(Schedulers.io())
//                .observeOn(AndroidSchedulers.mainThread())
//                .subscribe(subscriber);

        Observable observable = movieService.getTopMovie(start, count)
                .map(new HttpResultFunc<List<Subject>>());
        toSubscribe(observable, subscriber);
    }*/
   /* public void getZhuijiang(Subscriber<ResponseBody> subscriber) {
        *//*Observable observable = movieService.getToken();
        toSubscribe(observable, subscriber);*//*
    }*/

    public void getLogin(Subscriber<ResponseBody> subscriber, HashMap<String,String>map) {
       /* Observable observable = movieService.getLogin(map);
//                .map(new HttpResultFunc<JSONObject>());
        toSubscribe(observable, subscriber);*/
    }
    /*public void getLogin(Subscriber<ResponseBody> subscriber) {
        Observable observable = movieService.getLogin();
//                .map(new HttpResultFunc<JSONObject>());
        toSubscribe(observable, subscriber);
    }*/

    private <T> void toSubscribe(Observable<T> o, Subscriber<T> s) {
        o.subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(s);
    }

    /**
     * 用来统一处理Http的resultCode,并将HttpResult的Data部分剥离出来返回给subscriber
     *
     * @param <T> Subscriber真正需要的数据类型，也就是Data部分的数据类型
     */
  /*  private class HttpResultFunc<T> implements Func1<ResponseBody<T>, T> {
        @Override
        public T call(ResponseBody<T> responseBody) {
           if ("0".equals(responseBody.getResultCode())) {
                throw new ApiException(responseBody.getErrorMessage());
            }
            return responseBody.getResponseObject();
        }
    }*/


    /**
     * 用来统一处理Http的resultCode,并将HttpResult的Data部分剥离出来返回给subscriber
     *
     * @param <T> Subscriber真正需要的数据类型，也就是Data部分的数据类型
     */
   /* private class HttpResultFunc<T> implements Func1<HttpResult<T>, T> {

        @Override
        public T call(HttpResult<T> httpResult) {
            if (httpResult.getCount() == 0) {
                throw new ApiException(100);
            }
            return httpResult.getSubjects();
        }
    }*/

}
