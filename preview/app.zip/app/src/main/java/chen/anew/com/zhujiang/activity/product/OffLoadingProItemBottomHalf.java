package chen.anew.com.zhujiang.activity.product;

import android.os.Bundle;
import android.widget.Button;

import butterknife.Bind;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseFragment;

/**
 * Created by thinkpad on 2016/7/5.
 */
public class OffLoadingProItemBottomHalf extends BaseFragment {

    @Bind(R.id.offloading_btn)
    Button offloadingBtn;

    public static OffLoadingProItemBottomHalf newInstance( Bundle bundle) {
        OffLoadingProItemBottomHalf offLoadingProItemBottomHalf = new OffLoadingProItemBottomHalf();
        offLoadingProItemBottomHalf.setArguments(bundle);
        return offLoadingProItemBottomHalf;
    }

    @Override
    protected void initViews() {
        Bundle bundle = getArguments();
        String status=bundle.getString("status");
        if("05".equals(status)){
            offloadingBtn.setText("已下架");
        }else if("06".equals(status)){
            offloadingBtn.setText("已售罄");
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.fragment_offloading_bottomhalf;
    }

}
