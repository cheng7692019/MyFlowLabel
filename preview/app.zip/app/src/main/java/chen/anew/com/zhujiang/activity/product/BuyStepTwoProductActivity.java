package chen.anew.com.zhujiang.activity.product;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.anton46.stepsview.StepsView;
import com.google.gson.Gson;
import com.umeng.analytics.MobclickAgent;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.PDFViewPagerActivity;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.bean.SerializableMap;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.greendao.ProductList;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.CommonSubscriber;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.widget.Loaddialog;

/**
 * Created by thinkpad on 2016/7/5.
 */
public class BuyStepTwoProductActivity extends BaseAppActivity {
    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.right_tv_title)
    TextView rightTvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.stepsView)
    StepsView stepsView;
    @Bind(R.id.policyholder_relative)
    RelativeLayout policyholderRelative;
    @Bind(R.id.username_tv)
    TextView usernameTv;
    @Bind(R.id.sex_tv)
    TextView sexTv;
    @Bind(R.id.documentype_tv)
    TextView documentypeTv;
    @Bind(R.id.identificationcode_tv)
    TextView identificationcodeTv;
    @Bind(R.id.identificationexpiry_tv)
    TextView identificationexpiryTv;
    @Bind(R.id.phonecode_tv)
    TextView phonecodeTv;
    @Bind(R.id.emailcode_tv)
    TextView emailcodeTv;
    @Bind(R.id.provicecity_tv)
    TextView provicecityTv;
    @Bind(R.id.areadetailaddress_tv)
    TextView areadetailaddressTv;
    @Bind(R.id.post_tv)
    TextView postTv;
    @Bind(R.id.annualincome_tv)
    TextView annualincomeTv;
    @Bind(R.id.productname_tv)
    TextView productnameTv;
    @Bind(R.id.effectivedate_tv)
    TextView effectivedateTv;
    @Bind(R.id.guaranteeperiod_tv)
    TextView guaranteeperiodTv;
    @Bind(R.id.premium_tv)
    TextView premiumTv;
    @Bind(R.id.clickable_text_tv)
    TextView clickableTextTv;

    @Bind(R.id.confirm_radiobtn)
    RadioButton confirmRadiobtn;
    @Bind(R.id.policyholdergone_linear)
    LinearLayout policyholdergoneLinear;
    @Bind(R.id.rotate_img)
    ImageView rotateImg;

    private final String[] labels = {"", "", ""};
    private ProductList productList;
    private Map<String, String> map;

    private String INSURANCE_CLAUSE = "《保险条款》";
    private String PRODUCT_SPECIFICATION = "《产品说明书》";
    private String INSURE_PROMPT_BOOK = "《投保提示书》";
    private String IMPORTANT_INFORM_AND_STATEMENT = "《重要告知与声明》";
    private String HEALTH_AND_STATEMENT = "《健康告知》";

    private CommonSubscriber commonSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private DialogSubscriber dialogSubscriber;
    private String clauseUrl, specificationUrl, promptbookUrl, productImpart, productInform;
    private boolean flag = false;

    private MessageReceiver receiver;

    //保障详情页
    String itemCode, productName, productCode, totalmoney, days, startDate, endDate,insurePeriod;

    @Override
    protected void initViews() {
        rightTvTitle.setText(getResources().getString(R.string.next_step));
        tvTitle.setText(getResources().getString(R.string.confirm_insured_information));
        final Bundle bundle = getIntent().getExtras();
        productList = getIntent().getParcelableExtra("product_list");
        itemCode= bundle.getString("itemCode");
        final SerializableMap serializableMap = (SerializableMap) bundle.getSerializable("map");
        map = serializableMap.getMap();
        if(TextUtils.isEmpty(itemCode)){
            productName=productList.getProductName();
            productCode=productList.getProductCode();
            insurePeriod=productList.getInsurePeriod();
            guaranteeperiodTv.setText(insurePeriod);
        }else{
            productName = bundle.getString("productName");
            productCode = bundle.getString("productCode");
            insurePeriod = bundle.getString("days");
            totalmoney = bundle.getString("totalmoney");
            startDate = bundle.getString("startDate");
            endDate = bundle.getString("endDate");
            map.put("total",totalmoney);
            guaranteeperiodTv.setText(startDate+"  至  "+endDate);
        }
        initToolBar();
        stepsView.setLabels(labels)
                .setBarColorIndicator(getResources().getColor(R.color.chang_white))
                .setProgressColorIndicator(getResources().getColor(R.color.colorAccent))
                .setLabelColorIndicator(getResources().getColor(R.color.white))
                .setCompletedPosition(1)
                .drawView();
        initData();

        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                //Loaddialog.getInstance().dissLoading();
                if (flag) {
                    MyLogUtil.i("msg", "-proposalContNo-" + result);
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        String checkResult = jsonObject.getString("checkResult");
                        if ("1".equals(checkResult)) {
                            String orderNo = jsonObject.getString("orderNo");
                            //String proposalContNo = jsonObject.getString("proposalContNo");

                            Intent intent = new Intent(BuyStepTwoProductActivity.this,
                                    BuyStepThreePayProductActivity.class);
//                            intent.putExtra("orderNo", orderNo);
//                            intent.putExtra("productName", productName);
                           //    intent.putExtra("proposalContNo", proposalContNo);
                          /*  intent.putExtra("total", map.get("total"));
                            intent.putExtra("mobile", map.get("mobile"));
                            intent.putExtra("idNo", map.get("idNo"));
                            intent.putExtra("name", map.get("name"));*/
                            Bundle bundle=new Bundle();
                            SerializableMap serializableMap = new SerializableMap(map);
                            bundle.putSerializable("map",serializableMap);
                            bundle.putString("orderNo",orderNo);
                            bundle.putString("productName",productName);
                            intent.putExtras(bundle);
                            //友盟统计购买
                            HashMap<String, String> you_map = new HashMap<>();
                            you_map.put("order_no", orderNo);
                            you_map.put("mobile", map.get("mobile"));
                            you_map.put("quantity", map.get("total"));
                            MobclickAgent.onEvent(BuyStepTwoProductActivity.this, "purchase_03", you_map);

                            startActivity(intent);
                        } else if ("0".equals(checkResult)) {
                            Toast.makeText(BuyStepTwoProductActivity.this, jsonObject.getString("resultMessage"), Toast.LENGTH_SHORT).show();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    flag = false;
                } else {
                    MyLogUtil.i("msg", "-pdf-" + result);
                    Gson gson = new Gson();
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        JSONObject productInfo = new JSONObject(jsonObject.getString("productInfo"));
                        productImpart = productInfo.getString("productImpart");
                        productInform = productInfo.getString("productInform");
                        //pdf链接文字集
                        String acceptDesc = productInfo.getString("acceptDesc");
                    /*
                   * 使用"<a "分隔字符
			      */
                        String[] ATag = acceptDesc.split("<a ");
                        //《保险条款》详细链接
                        String clauseDetail = ATag[1];
                        //《产品说明书》详细链接
                        String specificationDetail = ATag[2];
                        //《投保提示书》详细链接
                        String promptbookDetail = ATag[3];
            /*
             * 使用" "分隔字符
			 */
                        String[] clauseArray = clauseDetail.split(" ");
                        String[] specificationArray = specificationDetail.split(" ");
                        String[] promptbookArray = promptbookDetail.split(" ");

                        //《保险条款》
                        clauseUrl = clauseArray[0];
                        clauseUrl = clauseUrl.substring(clauseUrl.indexOf("=") + 2, clauseUrl.lastIndexOf("f") + 1);
                        //《产品说明书》
                        specificationUrl = specificationArray[0];
                        specificationUrl = specificationUrl.substring(specificationUrl.indexOf("=") + 2, specificationUrl.lastIndexOf("f") + 1);
                        //《投保提示书》
                        promptbookUrl = promptbookArray[0];
                        promptbookUrl = promptbookUrl.substring(promptbookUrl.indexOf("=") + 2, promptbookUrl.lastIndexOf("f") + 1);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        loadProductPdfURL();
        initClickSpan();
        //注册广播
        receiver = new MessageReceiver();
        IntentFilter filter = new IntentFilter("CHEN.COM.BUYSTEPTWOPRODUCTACTIVITY");
        this.registerReceiver(receiver, filter);
    }

    public class MessageReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean flag=intent.getBooleanExtra("is_finish",false);
            if(flag){
                if(!isFinishing()){
                    finish();
                }
            }
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_steptwo_buyproduct;
    }

    private void initData() {
        usernameTv.setText(map.get("name"));
        sexTv.setText(map.get("sexname"));
        documentypeTv.setText("身份证");
        identificationcodeTv.setText(map.get("idNo"));
        if ("1".equals(map.get("validType"))) {
            identificationexpiryTv.setText(map.get("validStartDate") + "至" + map.get("validEndDate"));
        } else if ("2".equals(map.get("validType"))) {
            identificationexpiryTv.setText("长期");
        }
        phonecodeTv.setText(map.get("mobile"));
        emailcodeTv.setText(map.get("email"));
        provicecityTv.setText(map.get("addressProvince") + map.get("addressCity"));
        areadetailaddressTv.setText(map.get("addressDetail"));
        postTv.setText(map.get("occupationName"));
        annualincomeTv.setText(map.get("salary"));

        productnameTv.setText(productName);
        effectivedateTv.setText("承保当天起生效");
        premiumTv.setText(map.get("total"));
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void initClickSpan() {
        SpannableString spanClause = new SpannableString(INSURANCE_CLAUSE);
        SpannableString spanSpecification = new SpannableString(PRODUCT_SPECIFICATION);
        SpannableString spanPromptBook = new SpannableString(INSURE_PROMPT_BOOK);
        SpannableString spanInform = new SpannableString(IMPORTANT_INFORM_AND_STATEMENT);
        SpannableString spanStatement = new SpannableString(HEALTH_AND_STATEMENT);

        ClickableSpan clickClause = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(BuyStepTwoProductActivity.this, PDFViewPagerActivity.class);
                intent.putExtra("pdfurl", clauseUrl);
                intent.putExtra("title", INSURANCE_CLAUSE);
                startActivity(intent);
            }
        };

        ClickableSpan clickSpecification = new ClickableSpan() {

            @Override
            public void onClick(View widget) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(BuyStepTwoProductActivity.this, PDFViewPagerActivity.class);
                intent.putExtra("pdfurl", specificationUrl);
                intent.putExtra("title", PRODUCT_SPECIFICATION);
                startActivity(intent);
            }
        };

        ClickableSpan clickPromptBook = new ClickableSpan() {

            @Override
            public void onClick(View widget) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(BuyStepTwoProductActivity.this, PDFViewPagerActivity.class);
                intent.putExtra("pdfurl", promptbookUrl);
                intent.putExtra("title", INSURE_PROMPT_BOOK);
                startActivity(intent);
            }
        };

        ClickableSpan clickInform = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                // TODO Auto-generated method stub
                Loaddialog.showTipKnow("重要告知与声明", productImpart, "", true,BuyStepTwoProductActivity.this);
            }
        };

        ClickableSpan clickStatement = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                Loaddialog.showTipKnow("健康告知", productInform, "",true, BuyStepTwoProductActivity.this);
            }
        };

        spanClause.setSpan(clickClause, 0, INSURANCE_CLAUSE.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        //不是设点击颜色时需要设前景色
        spanClause.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorAccent)), 0, INSURANCE_CLAUSE.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        spanClause.setSpan(new NoUnderlineSpan(), 0, INSURANCE_CLAUSE.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        spanSpecification.setSpan(clickSpecification, 0, PRODUCT_SPECIFICATION.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        spanSpecification.setSpan(new NoUnderlineSpan(), 0, PRODUCT_SPECIFICATION.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        spanPromptBook.setSpan(clickPromptBook, 0, INSURE_PROMPT_BOOK.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        spanPromptBook.setSpan(new NoUnderlineSpan(), 0, INSURE_PROMPT_BOOK.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        spanInform.setSpan(clickInform, 0, IMPORTANT_INFORM_AND_STATEMENT.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        spanInform.setSpan(new NoUnderlineSpan(), 0, IMPORTANT_INFORM_AND_STATEMENT.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        spanStatement.setSpan(clickStatement, 0, HEALTH_AND_STATEMENT.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        spanStatement.setSpan(new NoUnderlineSpan(), 0, HEALTH_AND_STATEMENT.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);

        clickableTextTv.setText("本人已阅读了产品的");
        clickableTextTv.append(spanClause);
        clickableTextTv.append(spanSpecification);
        clickableTextTv.append("和");
        clickableTextTv.append(spanPromptBook);
        clickableTextTv.append(",了解本产品的特点及");
        clickableTextTv.append(spanInform);
        clickableTextTv.append("，并确认没有");
        clickableTextTv.append(spanStatement);
        clickableTextTv.append("中所述的问题");
        //这个setMovementMethod也很重要，没有就点击不到(设置超链接为可点击状态)
        clickableTextTv.setMovementMethod(LinkMovementMethod.getInstance());
    }

    /**
     * 无下划线的Span
     * Author: msdx (645079761@qq.com)
     * Time: 14-9-4 上午10:43
     */
    public class NoUnderlineSpan extends UnderlineSpan {

        @Override
        public void updateDrawState(TextPaint ds) {
            //设置链接颜色
            ds.setColor(getResources().getColor(R.color.colorAccent));
            //设置是否有下划线
            ds.setUnderlineText(false);
        }
    }

    @OnClick({R.id.right_tv_title, R.id.policyholder_relative})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.right_tv_title:
                flag = true;
                if(confirmRadiobtn.isChecked()){
                    createOrder();
                }else{
                    Toast.makeText(this, "请阅读并同意投保须知", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.policyholder_relative:
                int intVisibilit=policyholdergoneLinear.getVisibility();
                if(intVisibilit==0){
                    Animation animation= AnimationUtils.loadAnimation(this, R.anim.rotate_in);
                    animation.setFillAfter(true);
                    rotateImg.startAnimation(animation);
                    policyholdergoneLinear.setVisibility(View.GONE);
                }else{
                    Animation animation= AnimationUtils.loadAnimation(this, R.anim.rotate_out);
                    animation.setFillAfter(true);
                    rotateImg.startAnimation(animation);
                    policyholdergoneLinear.setVisibility(View.VISIBLE);
                }
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
        if(commonSubscriber!=null&&commonSubscriber.isUnsubscribed()){
            commonSubscriber.unsubscribe();
        }
        if (receiver != null) {
            this.unregisterReceiver(receiver);
        }
    }

    private void createOrder(){
        Gson gson = new Gson();
        //第一组
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, Object> map4 = new HashMap<>();

        HashMap<String, Object> map24 = new HashMap<>();
        HashMap<String, Object> map25 = new HashMap<>();

        HashMap<String, String> map1 = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        HashMap<String, String> map3 = new HashMap<>();

        map1.put("itemCode", "prem");
        map1.put("itemValue", this.map.get("total"));

        map2.put("itemCode", "productCode");
        map2.put("itemValue", productCode);

        map3.put("itemCode", "mainRiskCode");
        map3.put("itemValue", "");
        List<HashMap<String, String>> listMap = new ArrayList<>();
        listMap.add(map1);
        listMap.add(map2);
        listMap.add(map3);
        //第二组
        HashMap<String, String> map5 = new HashMap<>();
        HashMap<String, String> map6 = new HashMap<>();
        HashMap<String, String> map7 = new HashMap<>();
        HashMap<String, String> map8 = new HashMap<>();
        HashMap<String, String> map9 = new HashMap<>();
        HashMap<String, String> map10 = new HashMap<>();
        HashMap<String, String> map11 = new HashMap<>();
        HashMap<String, String> map12 = new HashMap<>();
        HashMap<String, String> map13 = new HashMap<>();
        HashMap<String, String> map14 = new HashMap<>();
        HashMap<String, String> map15 = new HashMap<>();
        HashMap<String, String> map16 = new HashMap<>();
        HashMap<String, String> map17 = new HashMap<>();
        HashMap<String, String> map18 = new HashMap<>();
        HashMap<String, String> map19 = new HashMap<>();

        HashMap<String, String> map20 = new HashMap<>();
        HashMap<String, String> map21 = new HashMap<>();
        HashMap<String, String> map22 = new HashMap<>();
        HashMap<String, String> map23 = new HashMap<>();

        HashMap<String, String> map26 = new HashMap<>();
        HashMap<String, String> map27 = new HashMap<>();

        map5.put("itemCode", "name");
        map5.put("itemValue", this.map.get("name"));
        map6.put("itemCode", "idType");
        map6.put("itemValue", "0");
        map7.put("itemCode", "idNo");
        map7.put("itemValue", this.map.get("idNo"));
        map8.put("itemCode", "sex");
        if ("男".equals(this.map.get("sexname"))) {
            map8.put("itemValue", "0");
        } else if ("女".equals(this.map.get("sexname"))) {
            map8.put("itemValue", "1");
        }
        map9.put("itemCode", "birthday");
        map9.put("itemValue", this.map.get("birthday"));

        map10.put("itemCode", "addressProvince");
        map10.put("itemValue", this.map.get("addressProvinceCode"));

        map11.put("itemCode", "addressCity");
        map11.put("itemValue", this.map.get("addressCityCode"));

        map12.put("itemCode", "addressDetail");
        map12.put("itemValue", this.map.get("addressDetail"));

        map13.put("itemCode", "zip");
        map13.put("itemValue", this.map.get("zip"));

        map14.put("itemCode", "mobile");
        map14.put("itemValue", this.map.get("mobile"));

        map15.put("itemCode", "email");
        map15.put("itemValue", this.map.get("email"));

        map16.put("itemCode", "validStartDate");
        map16.put("itemValue", this.map.get("validStartDate"));

        map17.put("itemCode", "validEndDate");
        map17.put("itemValue", this.map.get("validEndDate"));

        map18.put("itemCode", "validType");
        map18.put("itemValue", this.map.get("validType"));

        map19.put("itemCode", "holderArea");
        map19.put("itemValue", "440000");

        map20.put("itemCode", "occupationCode");
        map20.put("itemValue", this.map.get("occupationCode"));

        map21.put("itemCode", "occupationName");
        map21.put("itemValue", this.map.get("occupationName"));

        map22.put("itemCode", "occupationType");
        map22.put("itemValue", this.map.get("occupationType"));

        map23.put("itemCode", "salary");
        map23.put("itemValue", this.map.get("salary"));

        if(!TextUtils.isEmpty(startDate)){
            map26.put("itemCode", "startDate");
            map26.put("itemValue", startDate);
        }
        if(!TextUtils.isEmpty(endDate)){
            map27.put("itemCode", "endDate");
            map27.put("itemValue", endDate);
        }

        List<HashMap<String, String>> listMap2 = new ArrayList<>();
        listMap2.add(map5);
        listMap2.add(map6);
        listMap2.add(map7);
        listMap2.add(map8);
        listMap2.add(map9);
        listMap2.add(map10);
        listMap2.add(map11);
        listMap2.add(map12);
        listMap2.add(map13);
        listMap2.add(map14);
        listMap2.add(map16);
        listMap2.add(map15);
        listMap2.add(map17);
        listMap2.add(map18);
        listMap2.add(map19);
        listMap2.add(map20);
        listMap2.add(map21);
        listMap2.add(map22);
        listMap2.add(map23);
        if(!TextUtils.isEmpty(startDate)){
            listMap2.add(map26);
        }
        if(!TextUtils.isEmpty(endDate)){
            listMap2.add(map27);
        }
        map24.put("columnCode", "moneyInputColumn");
        map24.put("inputItemList", listMap);

        map25.put("columnCode", "appntColumn");
        map25.put("inputItemList", listMap2);

        List<HashMap<String, Object>> totalList = new ArrayList<>();
        totalList.add(map24);
        totalList.add(map25);
        map4.put("customerId", Common.userInfo.getCustomerId());
        map4.put("orderType", "32");
        map4.put("needInvoice", "0");
        map4.put("columnItemList", totalList);

        map.put("orderType", "32");
        map.put("platType", "3");
        map.put("requestObject", map4);

        String mapjson = gson.toJson(map);
        MyLogUtil.i("msg", "-mapjson-" + mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, BuyStepTwoProductActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.UnderwriteCheckUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    private void loadProductPdfURL() {
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("productCode", productCode);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        MyLogUtil.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        commonSubscriber = new CommonSubscriber(subscriberOnNextListener, BuyStepTwoProductActivity.this);
        OkHttpObservable.getInstance().getData(commonSubscriber, RequestURL.GetInputInfoUrl + RequestURL.CreatRequestUrl(mapjson));
    }
}
