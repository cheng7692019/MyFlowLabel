package chen.anew.com.zhujiang.activity.product;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.ufreedom.uikit.FloatingText;
import com.umeng.analytics.MobclickAgent;

import java.util.HashMap;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.guidelogin.LoginActivity;
import chen.anew.com.zhujiang.base.BaseFragment;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.greendao.ProductList;
import me.tankery.lib.circularseekbar.CircularSeekBar;

/**
 * Created by thinkpad on 2016/7/4.
 */
public class ProductItemTopHalf extends BaseFragment {

    @Bind(R.id.productname_tv)
    TextView productnameTv;
    @Bind(R.id.filing_number_tv)
    TextView filingNumberTv;
    @Bind(R.id.decrease_img)
    ImageView decreaseImg;
    @Bind(R.id.seek_bar)
    CircularSeekBar seekBar;
    @Bind(R.id.add_img)
    ImageView addImg;
    @Bind(R.id.history_interestrate_tv)
    TextView historyInterestrateTv;
    @Bind(R.id.mix_interestrate_tv)
    TextView mixInterestrateTv;
    @Bind(R.id.surrender_year_tv)
    TextView surrenderYearTv;
    @Bind(R.id.buy_btn)
    Button buyBtn;

    @Bind(R.id.amount_tv)
    TextView amountTv;

    private ProductList productList;
    private int my_progress = 1;
    private int price;

    private FloatingText floatingText;

    public static ProductItemTopHalf newInstance(Bundle args) {
        ProductItemTopHalf productTopHalfFragment = new ProductItemTopHalf();
        productTopHalfFragment.setArguments(args);
        return productTopHalfFragment;
    }

    @Override
    protected void initViews() {
        mPageName = "ProductItemTopHalf";
        Bundle bundle = getArguments();
        productList = getActivity().getIntent().getParcelableExtra("product_list");
        int product_money = bundle.getInt("product_money");
        //2000
        seekBar.setMax(Integer.valueOf(productList.getMaxMult()));
        price = Integer.parseInt(productList.getPrice());
        if (product_money != 0) {
            my_progress = Math.round(product_money / price);
            seekBar.setProgress(my_progress);
            amountTv.setText("" + product_money);
        }
        initView();
        seekBar.setOnSeekBarChangeListener(new CircularSeekBar.OnCircularSeekBarChangeListener() {
            @Override
            public void onProgressChanged(CircularSeekBar circularSeekBar, float progress, boolean fromUser) {
                //进度改变
                //int precenter=2000;
                amountTv.setText("" + price * Math.round(progress));
                my_progress = Math.round(progress);
            }

            @Override
            public void onStopTrackingTouch(CircularSeekBar seekBar) {

            }

            @Override
            public void onStartTrackingTouch(CircularSeekBar seekBar) {

            }
        });
    }

    private void initView() {
        filingNumberTv.setText(productList.getFiling_number());
        productnameTv.setText(productList.getProductName());
        historyInterestrateTv.setText(productList.getHistoryRate());
        mixInterestrateTv.setText(productList.getAssureRate());
        surrenderYearTv.setText(productList.getCostFeePeriod());
    }

    @Override
    protected int getContentViewId() {
        return R.layout.fragment_productitem_tophalf;
    }

    @OnClick({R.id.decrease_img, R.id.add_img, R.id.buy_btn})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.decrease_img:
                //
                if (my_progress < 1) {
                    SpannableString spanText = new SpannableString("亲,已经为零不能再减了");
                    spanText.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getContext(), R.color.colorAccent)), 0, spanText.length(),
                            Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
                    Snackbar snackbar = Snackbar.make(view, spanText, Snackbar.LENGTH_SHORT);
                    snackbar.getView().setBackgroundColor(ContextCompat.getColor(getContext(), R.color.white));
                    snackbar.show();
                    return;
                }
                my_progress -= 1;
                seekBar.setProgress(my_progress);
                amountTv.setText("" + price * my_progress);
                //减号的时候
                floatingText = new FloatingText.FloatingTextBuilder(getActivity())
                        .textColor(getResources().getColor(R.color.light_gold)) // floating  text color
                        .textSize(80)   // floating  text size
                        .textContent("-1000") // floating  text content
                        .offsetX(100) // the x offset  relate to the attached view
                        .offsetY(100) // the y offset  relate to the attached view
                        // .floatingAnimatorEffect(FloatingAnimator) // floating animation
                        // .floatingPathEffect(FloatingPathEffect) // floating path
                        .build();
                floatingText.attach2Window();
                floatingText.startFloating(decreaseImg);
                break;
            case R.id.add_img:
                my_progress += 1;
                seekBar.setProgress(my_progress);
                amountTv.setText("" + price * my_progress);
                //加号的时候
                floatingText = new FloatingText.FloatingTextBuilder(getActivity())
                        .textColor(getResources().getColor(R.color.light_gold)) // floating  text color
                        .textSize(80)   // floating  text size
                        .textContent("+1000") // floating  text content
                        .offsetX(-100) // the x offset  relate to the attached view
                        .offsetY(-100) // the y offset  relate to the attached view
                        // .floatingAnimatorEffect(FloatingAnimator) // floating animation
                        // .floatingPathEffect(FloatingPathEffect) // floating path
                        .build();
                floatingText.attach2Window();
                floatingText.startFloating(addImg);
                break;
            case R.id.buy_btn:
                //没有登录请登录
                if (Common.userInfo != null) {
                    //没有登录请登录
                    String sum = amountTv.getText().toString();
                    if (!TextUtils.isEmpty(sum) && Integer.parseInt(sum) > 0) {
                        Intent intent = new Intent(getActivity(), BuyStepOneProductActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putParcelable("product_list", productList);
                        bundle.putString("total", sum);
                        intent.putExtras(bundle);
                        //友盟统计购买
                        HashMap<String, String> you_map = new HashMap<>();
                        you_map.put("product_type", productList.getProductCode());
                        you_map.put("mobile", Common.userInfo.getMobile());
                        you_map.put("quantity", sum);
                        MobclickAgent.onEvent(getContext(), "purchase_01", you_map);

                        startActivity(intent);
                    } else {
                        SpannableString spanText = new SpannableString("亲,请选择购买的金额");
                        spanText.setSpan(new ForegroundColorSpan(ContextCompat.getColor(getContext(), R.color.colorAccent)), 0, spanText.length(),
                                Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
                        Snackbar snackbar = Snackbar.make(view, spanText, Snackbar.LENGTH_SHORT);
                        snackbar.getView().setBackgroundColor(ContextCompat.getColor(getContext(), R.color.white));
                        snackbar.show();
                    }
                } else {
                    startActivity(new Intent(getActivity(), LoginActivity.class));
                }
                break;
        }
    }
}
