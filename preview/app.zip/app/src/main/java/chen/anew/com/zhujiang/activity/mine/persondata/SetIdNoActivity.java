package chen.anew.com.zhujiang.activity.mine.persondata;

import android.content.Intent;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.bigkoo.pickerview.TimePickerView;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.utils.VerifyUtil;

/**
 * Created by thinkpad on 2016/7/15.
 */
public class SetIdNoActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.right_tv_title)
    TextView rightTvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.identification_et)
    EditText identificationEt;
    @Bind(R.id.startime_btn)
    Button startimeBtn;
    @Bind(R.id.endtime_btn)
    Button endtimeBtn;
    @Bind(R.id.ischangqi_rb)
    RadioButton ischangqiRb;


    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private int age;
    private String IdNo;
    //时间选择器
    private TimePickerView pvTime;
    private String validType,starTime, endTime,sexname;
    private Date starDate;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.document_type));
        rightTvTitle.setText(getResources().getString(R.string.complete));
        initToolBar();
        //监听身份证，设置性别
        identificationEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String identification = identificationEt.getText().toString();
                if (identification.length() == 18 | identification.length() == 15) {
                    age = VerifyUtil.getAge(identification);
                    sexname = VerifyUtil.getSex(identification);
                    if (age > 45) {
                        ischangqiRb.setChecked(true);
                    } else {
                        ischangqiRb.setChecked(false);
                    }
                }
            }
        });

        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg", "-responseBody-" + result);
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String updateResult = jsonObject.getString("updateResult");
                    String resultMessage = jsonObject.getString("resultMessage");
                    if ("1".equals(updateResult)) {
                        Toast.makeText(SetIdNoActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                        Common.userInfo.setIdNo(IdNo);
                        Common.userInfo.setIdType("0");
                        if (sexname.equals("男")) {
                            Common.userInfo.setSex("0");
                        } else if (sexname.equals("女")) {
                            Common.userInfo.setSex("1");
                        }
                        Common.userInfo.setValidType(validType);
                        if(!TextUtils.isEmpty(starTime)){
                            Common.userInfo.setValidStartDate(starTime);
                        }
                        if(!TextUtils.isEmpty(endTime)){
                            Common.userInfo.setValidEndDate(endTime);
                        }
                        //创建Intent对象
                        Intent intent = new Intent();
                        //设置Intent的Action属性
                        intent.setAction("CHEN.COM.UPDATEPERSONDATA");
                        intent.putExtra("idNo",IdNo);
                        //发送广播,改变身份证显示
                        sendBroadcast(intent);

                        MyApp.daoSession.getUserInfoDao().update(Common.userInfo);
                        SetIdNoActivity.this.finish();
                    } else if ("0".equals(updateResult)) {
                        Toast.makeText(SetIdNoActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_setidno;
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @OnClick(R.id.right_tv_title)
    public void onClick() {
        IdNo = identificationEt.getText().toString();
//        starTime
        if (TextUtils.isEmpty(starTime)|TextUtils.isEmpty(endTime)) {
            Toast.makeText(SetIdNoActivity.this, "身份证有效期不能为空", Toast.LENGTH_SHORT).show();
        }else if (TextUtils.isEmpty(IdNo)) {
            Toast.makeText(SetIdNoActivity.this, "身份证号码不能为空", Toast.LENGTH_SHORT).show();
        } else if (!VerifyUtil.checkIdNo(IdNo)) {
            Toast.makeText(SetIdNoActivity.this, "身份证号码格式不对", Toast.LENGTH_SHORT).show();
        } else {
            Gson gson = new Gson();
            HashMap<String, Object> map = new HashMap<>();
            HashMap<String, String> map2 = new HashMap<>();
            map2.put("customerId", Common.userInfo.getCustomerId());
            map2.put("idNo", IdNo);
            map2.put("idType", "0");
            if ("男".equals(sexname)) {
                map2.put("sex", "0");
            } else if ("女".equals(sexname)) {
                map2.put("sex", "1");
            }
            if(ischangqiRb.isChecked()){
                validType="2";
                map2.put("validType", "2");//2是长期
            }else{
                validType="1";
                map2.put("validType", "1");//1是指定时间
                map2.put("validStartDate", starTime);
                map2.put("validEndDate", endTime);
            }
            map.put("orderType", "32");
            map.put("platType", "3");
            map.put("requestObject", map2);
            String mapjson = gson.toJson(map);
            //Log.i("msg","-mapjson-"+mapjson);
            //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
            dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, SetIdNoActivity.this);
            OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.editAccountInfoUrl + RequestURL.CreatRequestUrl(mapjson));
        }
    }

    @OnClick({R.id.startime_btn, R.id.endtime_btn, R.id.ischangqi_rb})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.startime_btn:
                IdNo = identificationEt.getText().toString();
                if (TextUtils.isEmpty(IdNo)) {
                    Toast.makeText(SetIdNoActivity.this, "请先填写个人信息", Toast.LENGTH_SHORT).show();
                } else {
                    if (ischangqiRb.isChecked()) {
                        Toast.makeText(SetIdNoActivity.this, "长期不用选证件有限期", Toast.LENGTH_SHORT).show();
                    } else {
                        pvTime = new TimePickerView(SetIdNoActivity.this, TimePickerView.Type.YEAR_MONTH_DAY);
                        pvTime.setCancelable(true);
                        pvTime.show();
                        pvTime.setOnTimeSelectListener(new TimePickerView.OnTimeSelectListener() {
                            @Override
                            public void onTimeSelect(Date date) {
                                starDate = date;
                                starTime = getTime(starDate);
                                startimeBtn.setText(starTime);
                                //Toast.makeText(BasicInformationActivity.this, "-time-" + starTime, Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }
                break;
            case R.id.endtime_btn:
                IdNo = identificationEt.getText().toString();
                if (TextUtils.isEmpty(IdNo)) {
                    Toast.makeText(SetIdNoActivity.this, "请先填写个人信息", Toast.LENGTH_SHORT).show();
                } else {
                    if (ischangqiRb.isChecked()) {
                        Toast.makeText(SetIdNoActivity.this, "长期不用选证件有限期", Toast.LENGTH_SHORT).show();
                    } else {
                        if (TextUtils.isEmpty(starTime)) {
                            Toast.makeText(SetIdNoActivity.this, "请先选开始时间", Toast.LENGTH_SHORT).show();
                        } else {
                            pvTime = new TimePickerView(SetIdNoActivity.this, TimePickerView.Type.YEAR_MONTH_DAY);
                            pvTime.setCancelable(true);
                            pvTime.show();
                            pvTime.setOnTimeSelectListener(new TimePickerView.OnTimeSelectListener() {
                                @Override
                                public void onTimeSelect(Date date) {
                                    Date currentDate=new Date();
                                    if (date.compareTo(starDate) < 0) {
                                        Toast.makeText(SetIdNoActivity.this, "结束时间不得小于开始时间", Toast.LENGTH_SHORT).show();
                                    } else if (date.compareTo(currentDate) < 0) {
                                        Toast.makeText(SetIdNoActivity.this, "结束时间不得小于当前时间", Toast.LENGTH_SHORT).show();
                                    } else {
                                        endTime = getTime(date);
                                        endtimeBtn.setText(endTime);
                                        //Toast.makeText(BasicInformationActivity.this, "-time-" + endTime, Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                        }
                    }
                }
                break;
            case R.id.ischangqi_rb:
                IdNo = identificationEt.getText().toString();
                if(TextUtils.isEmpty(IdNo)){
                    Toast.makeText(SetIdNoActivity.this, "请先填写身份证信息", Toast.LENGTH_SHORT).show();
                }else{
                    //长期radio
                    if (age > 45) {
                        ischangqiRb.setChecked(true);
                    } else {
                        ischangqiRb.setChecked(false);
                    }
                    Toast.makeText(SetIdNoActivity.this, "根据身份证已自动判断", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    private static String getTime(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        return format.format(date);
    }
}
