package chen.anew.com.zhujiang.activity.mine.setup;

import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.widget.PasswordInputView;

/**
 * Created by thinkpad on 2016/6/30.
 */
public class SetPayNextPasswordActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.right_tv_title)
    TextView rightTvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.passwordInputView)
    PasswordInputView passwordInputView;
    private String password;

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.confirm_paypassword));
        rightTvTitle.setText(getResources().getString(R.string.complete));
        initToolBar();
        password = getIntent().getStringExtra("paypassword");
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg","-result-"+result);
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String resultCode=jsonObject.getString("resultCode");
                    String resultMessage=jsonObject.getString("resultMessage");
                    if("1".equals(resultCode)){
                        Toast.makeText(SetPayNextPasswordActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                        finish();
                    }else{
                        Toast.makeText(SetPayNextPasswordActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
    }


    @Override
    protected int getContentViewId() {
        return R.layout.activity_againpaypassword;
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    @OnClick(R.id.right_tv_title)
    public void onClick() {
        String againpassword = passwordInputView.getText().toString();
        if (TextUtils.isEmpty(againpassword)) {
            Toast.makeText(SetPayNextPasswordActivity.this, "确认密码不能为空", Toast.LENGTH_SHORT).show();
        } else if (!againpassword.equals(password)) {
            Toast.makeText(SetPayNextPasswordActivity.this, "两次密码填写不一样", Toast.LENGTH_SHORT).show();
        } else {
            Gson gson = new Gson();
            HashMap<String, Object> map = new HashMap<>();
            HashMap<String, String> map2 = new HashMap<>();
            map2.put("payPassword", againpassword);
            map2.put("customerId", Common.userInfo.getCustomerId());

            map.put("orderType", 32);
            map.put("platType", 3);
            map.put("requestObject", map2);

            String mapjson = gson.toJson(map);
            //Log.i("msg","-mapjson-"+mapjson);
            //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
            dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, SetPayNextPasswordActivity.this);
            OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.SaveAccountSecurityUrl + RequestURL.CreatRequestUrl(mapjson));
        }
    }
}
