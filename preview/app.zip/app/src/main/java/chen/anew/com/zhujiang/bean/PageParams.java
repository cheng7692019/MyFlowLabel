package chen.anew.com.zhujiang.bean;

import java.io.Serializable;

/**
 * Created by thinkpad on 2016/6/30.
 */
public class PageParams implements Serializable {

    private int records;

    private int pageTotal;

    private int currentPage;

    public void setRecords(int records) {
        this.records = records;
    }

    public int getRecords() {
        return this.records;
    }

    public void setPageTotal(int pageTotal) {
        this.pageTotal = pageTotal;
    }

    public int getPageTotal() {
        return this.pageTotal;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    public int getCurrentPage() {
        return this.currentPage;
    }

}
