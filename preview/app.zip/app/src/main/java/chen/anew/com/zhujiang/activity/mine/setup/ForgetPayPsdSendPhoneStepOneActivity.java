package chen.anew.com.zhujiang.activity.mine.setup;

import android.content.Intent;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.utils.VerifyUtil;

/**
 * Created by thinkpad on 2016/7/19.
 */
public class ForgetPayPsdSendPhoneStepOneActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.one_phone)
    EditText onePhone;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.forget_paypassword));
        initToolBar();
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_forgetpsdsendphone_stepone;
    }

    @OnClick(R.id.fab_ok)
    public void onClick() {
        String phone=onePhone.getText().toString();
        if(!VerifyUtil.VerificationPhone(phone)){
            Toast.makeText(ForgetPayPsdSendPhoneStepOneActivity.this, "手机号码格式不对", Toast.LENGTH_SHORT).show();
        }else if(!phone.equals(Common.userInfo.getMobile())){
            Toast.makeText(ForgetPayPsdSendPhoneStepOneActivity.this, "请输入注册时的手机号码", Toast.LENGTH_SHORT).show();
        }else{
            //跳传到请求验证码
            Intent intent=new Intent(ForgetPayPsdSendPhoneStepOneActivity.this,ForgetPayPsdSendPhoneStepTwoActivity.class);
            intent.putExtra("phone",phone);
            startActivity(intent);
            finish();
        }
    }

}
