package chen.anew.com.zhujiang.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nineoldandroids.view.ViewHelper;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.pullrefresh.layout.BaseHeaderView;
import chen.anew.com.zhujiang.pullrefresh.support.type.LayoutType;
import chen.anew.com.zhujiang.utils.AnimUtil;

/**
 * Created by Ybao on 2015/11/3 0003.
 */

public class NormalHeaderView extends BaseHeaderView {

    TextView textView;
    BGAMinMoocStyleRefreshView zeffect_recordbutton_dialog_imageview;
    RelativeLayout head_relative;
    /*View tagImg;
    View progress;
    View stateImg;*/

    public NormalHeaderView(Context context) {
        this(context, null);
    }

    public NormalHeaderView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public NormalHeaderView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        LayoutInflater.from(getContext()).inflate(R.layout.view_header_normal, this, true);
        textView = (TextView) findViewById(R.id.text);
        head_relative= (RelativeLayout) findViewById(R.id.head_relative);
        //tagImg = findViewById(R.id.tag);
        // progress = findViewById(R.id.progress);
        zeffect_recordbutton_dialog_imageview = (BGAMinMoocStyleRefreshView) findViewById(R.id.zeffect_recordbutton_dialog_imageview);
        // stateImg = findViewById(R.id.state);
    }

    @Override
    protected void onStateChange(int state) {
        if (textView == null || zeffect_recordbutton_dialog_imageview == null/*|| tagImg == null || progress == null || stateImg == null*/) {
            return;
        }
//        stateImg.setVisibility(View.INVISIBLE);
//        progress.setVisibility(View.INVISIBLE);
        //zeffect_recordbutton_dialog_imageview.setVisibility(View.INVISIBLE);
        textView.setVisibility(View.VISIBLE);
        head_relative.setVisibility(View.VISIBLE);
        zeffect_recordbutton_dialog_imageview.setOriginalImage(R.mipmap.refresh_star_48);
        zeffect_recordbutton_dialog_imageview.setUltimateColor(R.color.colorAccent);
        zeffect_recordbutton_dialog_imageview.startRefreshing();
//        tagImg.setVisibility(View.VISIBLE);
        ViewHelper.setAlpha(textView, 1);
//        ViewHelper.setAlpha(tagImg, 1);
//        ViewHelper.setTranslationY(stateImg, 0);
        //ViewHelper.setTranslationY(zeffect_recordbutton_dialog_imageview, 0);
        switch (state) {
            case NONE:
                break;
            case PULLING:
                textView.setText("下拉刷新");
//                AnimUtil.startRotation(tagImg, 0);
                break;
            case LOOSENT_O_REFRESH:
                textView.setText("松开刷新");
//                AnimUtil.startRotation(tagImg, 180);
                break;
            case REFRESHING:
                textView.setText("正在刷新");
                AnimUtil.startShow(zeffect_recordbutton_dialog_imageview, 0.5f, 400, 200);
                //AnimUtil.startHide(textView);
                // AnimUtil.startHide(tagImg);
                break;
            case REFRESH_CLONE:
                //AnimUtil.startFromY(stateImg, -2 * stateImg.getHeight());
                // AnimUtil.startToY(progress, 2 * progress.getHeight());
                // progress.setVisibility(View.VISIBLE);
                zeffect_recordbutton_dialog_imageview.stopRefreshing();
                head_relative.setVisibility(View.GONE);
                // tagImg.setVisibility(View.INVISIBLE);
                //textView.setText("刷新完成");
                break;
        }
    }

    @Override
    public float getSpanHeight() {
        return getHeight();
    }


    @Override
    public int getLayoutType() {
        return LayoutType.LAYOUT_NORMAL;
    }
}
