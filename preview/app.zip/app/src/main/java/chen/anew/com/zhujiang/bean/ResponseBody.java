package chen.anew.com.zhujiang.bean;

import java.io.Serializable;

public class ResponseBody implements Serializable{
    private String resultCode;
    private String errorMessage;
    private Object responseObject;

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public Object getResponseObject() {
        return responseObject;
    }

    public void setResponseObject(Object responseObject) {
        this.responseObject = responseObject;
    }

    @Override
    public String toString() {
        return "ResponseBody{" +
                "resultCode='" + resultCode + '\'' +
                ", errorMessage='" + errorMessage + '\'' +
                ", responseObject=" + responseObject +
                '}';
    }
}
