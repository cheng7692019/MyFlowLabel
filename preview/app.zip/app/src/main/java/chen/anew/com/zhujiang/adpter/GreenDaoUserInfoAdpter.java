package chen.anew.com.zhujiang.adpter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.greendao.UserInfo;

/**
 * Created by thinkpad on 2016/7/8.
 */
public class GreenDaoUserInfoAdpter extends BaseAdapter {

    private LayoutInflater inflater;
    private List<UserInfo> imgs;
    private Context context;

    public GreenDaoUserInfoAdpter(Context context, List<UserInfo> imgs) {
        this.inflater = LayoutInflater.from(context);
        this.context = context;
        this.imgs = imgs;
    }

    /**
     * 当ListView数据发生变化时,调用此方法来更新ListView
     *
     * @param imgs
     */
    public void updateListView(List<UserInfo> imgs) {
        this.imgs = imgs;
        notifyDataSetChanged();
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.list_spinner_item,
                    parent, false);
            viewHolder = new ViewHolder();
            viewHolder.mobile_tv = (TextView) convertView
                    .findViewById(R.id.mobile_tv);
            viewHolder.mine_logo_iv = (ImageView) convertView
                    .findViewById(R.id.mine_logo_iv);
            viewHolder.iv_delete = (ImageView) convertView
                    .findViewById(R.id.iv_delete);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        final UserInfo userInfo = imgs.get(position);
        if (userInfo != null) {
            viewHolder.mobile_tv.setText(userInfo.getMobile());
            Glide.with(context).load(userInfo.getHeadimgurl())
                    .error(R.mipmap.defaulthead)
                    .centerCrop()
                    .into(viewHolder.mine_logo_iv);
            viewHolder.iv_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    imgs.remove(position);
                    MyApp.daoSession.getUserInfoDao().delete(userInfo);
                    notifyDataSetChanged();
                }
            });

        }
        return convertView;
    }

    static class ViewHolder {
        TextView mobile_tv;
        ImageView mine_logo_iv,iv_delete;
    }

    @Override
    public long getItemId(int arg0) {
        return arg0;
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return imgs.size();
    }

    @Override
    public Object getItem(int arg0) {
        // TODO Auto-generated method stub
        return imgs.get(arg0);
    }
}

