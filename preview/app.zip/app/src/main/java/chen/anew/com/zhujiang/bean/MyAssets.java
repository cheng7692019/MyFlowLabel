package chen.anew.com.zhujiang.bean;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by thinkpad on 2016/8/8.
 */

public class MyAssets implements Parcelable {

    private String orderType;

    private String productType;

    private String orderStatus;

    private String customerId;

    private String orderNo;

    private String contType;

    private String contNo;

    private String contStatus;

    private String cvalidate;

    private String dayTotalAmnt;

    private String appntName;

    private String mainRiskName;

    private String linkNo;

    private String insuaccbala;

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getOrderType() {
        return this.orderType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductType() {
        return this.productType;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getOrderStatus() {
        return this.orderStatus;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerId() {
        return this.customerId;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getOrderNo() {
        return this.orderNo;
    }

    public void setContType(String contType) {
        this.contType = contType;
    }

    public String getContType() {
        return this.contType;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getContNo() {
        return this.contNo;
    }

    public void setContStatus(String contStatus) {
        this.contStatus = contStatus;
    }

    public String getContStatus() {
        return this.contStatus;
    }

    public void setCvalidate(String cvalidate) {
        this.cvalidate = cvalidate;
    }

    public String getCvalidate() {
        return this.cvalidate;
    }

    public void setDayTotalAmnt(String dayTotalAmnt) {
        this.dayTotalAmnt = dayTotalAmnt;
    }

    public String getDayTotalAmnt() {
        return this.dayTotalAmnt;
    }

    public void setAppntName(String appntName) {
        this.appntName = appntName;
    }

    public String getAppntName() {
        return this.appntName;
    }

    public void setMainRiskName(String mainRiskName) {
        this.mainRiskName = mainRiskName;
    }

    public String getMainRiskName() {
        return this.mainRiskName;
    }

    public void setLinkNo(String linkNo) {
        this.linkNo = linkNo;
    }

    public String getLinkNo() {
        return this.linkNo;
    }

    public void setInsuaccbala(String insuaccbala) {
        this.insuaccbala = insuaccbala;
    }

    public String getInsuaccbala() {
        return this.insuaccbala;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(orderType);
        dest.writeString(productType);
        dest.writeString(orderStatus);
        dest.writeString(customerId);
        dest.writeString(orderNo);
        dest.writeString(contNo);
        dest.writeString(contStatus);
        dest.writeString(cvalidate);
        dest.writeString(dayTotalAmnt);
        dest.writeString(appntName);
        dest.writeString(mainRiskName);
        dest.writeString(linkNo);
        dest.writeString(insuaccbala);
    }
    // 用来创建自定义的Parcelable的对象
    public static final Parcelable.Creator<MyAssets> CREATOR
            = new Parcelable.Creator<MyAssets>() {
        public MyAssets createFromParcel(Parcel in) {
            return new MyAssets(in);
        }

        public MyAssets[] newArray(int size) {
            return new MyAssets[size];
        }
    };

    // 读数据进行恢复
    private MyAssets(Parcel in) {
        orderType = in.readString();
        productType = in.readString();
        orderStatus = in.readString();
        customerId = in.readString();
        orderNo = in.readString();
        contType = in.readString();
        contNo = in.readString();
        contStatus = in.readString();
        cvalidate = in.readString();
        dayTotalAmnt = in.readString();
        appntName = in.readString();
        mainRiskName = in.readString();
        linkNo = in.readString();
        insuaccbala = in.readString();
    }

}
