package chen.anew.com.zhujiang.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.webkit.WebView;

import chen.anew.com.zhujiang.activity.web.WebMatchViewFragment;
import chen.anew.com.zhujiang.pullrefresh.layout.BaseHeaderView;
import chen.anew.com.zhujiang.utils.MyLogUtil;

/**
 * Created by thinkpad on 2016/8/19.
 */
public class MyWebView extends WebView {

    private BaseHeaderView headerView;
    private int downY;

    public void setHeaderView(BaseHeaderView headerView) {
        this.headerView = headerView;
    }

    public MyWebView(Context context) {
        super(context);
    }

    public MyWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                //WebMatchViewFragment.flag = true;
                //downY = (int) event.getY();
                break;
            case MotionEvent.ACTION_MOVE:
                /*switch (headerView.getType()){
                    case BaseHeaderView.NONE:
                        break;
                    case BaseHeaderView.PULLING:
                        break;
                    case BaseHeaderView.LOOSENT_O_REFRESH:
                        break;
                    case BaseHeaderView.REFRESHING:
                        break;
                    case BaseHeaderView.REFRESH_CLONE:
                        break;
                }*/
                int deltaY=(int) (event.getY()-downY);
                MyLogUtil.i("webview","-dy-"+deltaY);
                /*if (headerView.getType() == BaseHeaderView.REFRESH_CLONE) {
                    WebMatchViewFragment.flag = true;
                    break;
                }else{
                    WebMatchViewFragment.flag = false;
                }*/
                if(deltaY>0){
                    WebMatchViewFragment.flag = false;
                }else{
                    WebMatchViewFragment.flag = true;
                }
                /*if (headerView.getType() == BaseHeaderView.REFRESHING) {
                    WebMatchViewFragment.flag = true;
                    break;
                }else */
//                int deltaY=(int) (event.getY()-downY);
                break;
            case MotionEvent.ACTION_UP:
                break;
        }
        return false;
    }
}
