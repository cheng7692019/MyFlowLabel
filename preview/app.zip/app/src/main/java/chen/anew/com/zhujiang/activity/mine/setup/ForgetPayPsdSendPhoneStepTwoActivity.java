package chen.anew.com.zhujiang.activity.mine.setup;

import android.content.Intent;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;

/**
 * Created by thinkpad on 2016/7/19.
 */

public class ForgetPayPsdSendPhoneStepTwoActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.two_code_et)
    EditText twoCodeEt;
    @Bind(R.id.two_send_btn)
    TextView twoSendBtn;

    private DialogSubscriber dialogSubscriber;
    private Subscriber subscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private String code, phone, sessionId;


    @Override
    protected void initViews() {
        phone=getIntent().getStringExtra("phone");
        tvTitle.setText(getResources().getString(R.string.forget_paypassword));
        initToolBar();
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    code = jsonObject.getString("verificationCode");
                    //Toast.makeText(ForgetPayPsdSendPhoneStepTwoActivity.this, "验证码：" + code, Toast.LENGTH_SHORT).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        };
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(dialogSubscriber!=null&&dialogSubscriber.isUnsubscribed()){
            dialogSubscriber.unsubscribe();
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_forgetpsdsendphone_steptwo;
    }

    @OnClick({R.id.two_send_btn, R.id.fab_ok})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.two_send_btn:
                initTime();
                getRemoteSendCode();
                break;
            case R.id.fab_ok:
                String valCode=twoCodeEt.getText().toString();
                if(!valCode.equals(code)){
                    Toast.makeText(ForgetPayPsdSendPhoneStepTwoActivity.this, "验证码不正确", Toast.LENGTH_SHORT).show();
                }else{
                    Intent intent=new Intent(ForgetPayPsdSendPhoneStepTwoActivity.this,ModifyPayPasswordActivity.class);
                    intent.putExtra("mobile",phone);
                    intent.putExtra("sessionId",sessionId);
                    intent.putExtra("verificationCode",code);
                    startActivity(intent);
                    finish();
                }
                break;
        }
    }

    private void initTime() {
        final int countTime = 60;
        twoSendBtn.setText("重新发送(" + countTime + ")");
        twoSendBtn.setClickable(false);
        subscriber = new Subscriber<Integer>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
            }

            @Override
            public void onNext(Integer integer) {
                if (integer == 0) {
                    //isTime = false;
                    twoSendBtn.setText("重新发送");
                    twoSendBtn.setClickable(true);
                } else {
                    twoSendBtn.setText("重新发送(" + integer + ")");
                }
            }
        };
        Observable.interval(0, 1, TimeUnit.SECONDS)
                .subscribeOn(AndroidSchedulers.mainThread())
                .observeOn(AndroidSchedulers.mainThread())
                .map(new Func1<Long, Integer>() {
                    @Override
                    public Integer call(Long increaseTime) {
                        return countTime - increaseTime.intValue();
                    }
                })
                .take(countTime + 1)
                .subscribe(subscriber);
    }

    private void getRemoteSendCode() {
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("operateType", "2");
        sessionId = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        map2.put("sessionId", sessionId);
        map2.put("customerMobile", phone);
        map2.put("operateCode", phone);

        map.put("orderType", "32");
        map.put("platType", "3");
        map.put("requestObject", map2);
        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, ForgetPayPsdSendPhoneStepTwoActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.GetPolicyQueryCodeUrl + RequestURL.CreatRequestUrl(mapjson));
    }

}
