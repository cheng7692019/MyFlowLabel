package chen.anew.com.zhujiang.activity.mine.persondata;

import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.bigkoo.pickerview.OptionsPickerView;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.bean.ProvinceVo;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.utils.VerifyUtil;

/**
 * Created by thinkpad on 2016/7/18.
 */
public class ModifyAddressActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.right_tv_title)
    TextView rightTvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.select_procity_btn)
    Button selectProcityBtn;
    @Bind(R.id.areadetail_address_et)
    EditText areadetailAddressEt;
    @Bind(R.id.post_code_et)
    EditText postCodeEt;

    private String provinceId, cityId, addressProvince, addressCity, email, address;
    private OptionsPickerView pvOptions;
    private ArrayList<String> options1Items;
    private ArrayList<ArrayList<String>> options2Items;

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    @Override
    protected void initViews() {
        addressProvince = getIntent().getStringExtra("addressProvince");
        addressCity = getIntent().getStringExtra("addressCity");
        provinceId = getIntent().getStringExtra("provinceId");
        cityId = getIntent().getStringExtra("cityId");
        if (!TextUtils.isEmpty(provinceId) && !TextUtils.isEmpty(cityId)) {
            selectProcityBtn.setText(addressProvince + addressCity);
            email = Common.userInfo.getZip();
            address = Common.userInfo.getAddress();
            areadetailAddressEt.setText(address);
            postCodeEt.setText(email);
        }
        tvTitle.setText(getResources().getString(R.string.address_txt));
        initToolBar();
        //选项选择器
        pvOptions = new OptionsPickerView(ModifyAddressActivity.this);
        options1Items = new ArrayList<>();
        options2Items = new ArrayList<>();

        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg", "-responseBody-" + result);
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String updateResult = jsonObject.getString("updateResult");
                    String resultMessage = jsonObject.getString("resultMessage");
                    if ("1".equals(updateResult)) {
                        Toast.makeText(ModifyAddressActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                        Common.userInfo.setProvince(provinceId);
                        Common.userInfo.setCity(cityId);
                        Common.userInfo.setAddress(address);
                        Common.userInfo.setZip(email);
                        MyApp.daoSession.getUserInfoDao().update(Common.userInfo);
                        finish();
                    } else if ("0".equals(updateResult)) {
                        Toast.makeText(ModifyAddressActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };

    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_modifyaddress;
    }


    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @OnClick({R.id.right_tv_title, R.id.select_procity_btn})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.right_tv_title:
                email = postCodeEt.getText().toString();
                address = areadetailAddressEt.getText().toString();
                if (TextUtils.isEmpty(provinceId) | TextUtils.isEmpty(cityId)) {
                    Toast.makeText(ModifyAddressActivity.this, "请选择所属地区", Toast.LENGTH_SHORT).show();
                } else if (VerifyUtil.getWordCount(address) < 6) {
                    Toast.makeText(ModifyAddressActivity.this, "详细地址不得少于6个汉字", Toast.LENGTH_SHORT).show();
                } else if (email.length() < 6) {
                    Toast.makeText(ModifyAddressActivity.this, "邮政编码格式不对", Toast.LENGTH_SHORT).show();
                } else {
                    //提交地区到服务器
                    Gson gson = new Gson();
                    HashMap<String, Object> map = new HashMap<>();
                    HashMap<String, String> map2 = new HashMap<>();
                    map2.put("customerId", Common.userInfo.getCustomerId());
                    map2.put("province", provinceId);
                    map2.put("city", cityId);
                    map2.put("address", address);
                    map2.put("zip", email);

                    map.put("orderType", "32");
                    map.put("platType", "3");
                    map.put("requestObject", map2);
                    String mapjson = gson.toJson(map);
                    //Log.i("msg","-mapjson-"+mapjson);
                    //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
                    dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, ModifyAddressActivity.this);
                    OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.editAccountInfoUrl + RequestURL.CreatRequestUrl(mapjson));
                }
                break;
            case R.id.select_procity_btn:
                //省份城市选择
                for (int i = 0; i < MyAddressActivity.provinceList.size(); i++) {
                    ProvinceVo provinceVo = MyAddressActivity.provinceList.get(i);
                    options1Items.add(provinceVo.getProvinceName());
                    options2Items.add(VerifyUtil.getCityListByProviceCode(MyAddressActivity.cityList, provinceVo.getProvincePostCode()));
                }
                //三级联动效果
                pvOptions.setPicker(options1Items, options2Items, true);
                pvOptions.setCyclic(false, false, false);
                //设置默认选中的三级项目
                //监听确定选择按钮
                pvOptions.setSelectOptions(1, 1);
                pvOptions.setCancelable(true);
                pvOptions.show();
                pvOptions.setOnoptionsSelectListener(new OptionsPickerView.OnOptionsSelectListener() {
                    @Override
                    public void onOptionsSelect(int options1, int option2, int options3) {
                        //返回的分别是三个级别的选中位置
                        String tx = options1Items.get(options1)
                                + options2Items.get(options1).get(option2);
                        provinceId = VerifyUtil.getProviceCodeByProviceName(MyAddressActivity.provinceList, options1Items.get(options1));
                        cityId = VerifyUtil.getcityCodeBycityName(MyAddressActivity.cityList, options2Items.get(options1).get(option2));
                        addressProvince = options1Items.get(options1);
                        addressCity = options2Items.get(options1).get(option2);
                        selectProcityBtn.setText(tx);
                    }
                });
                break;
        }
    }
}
