package chen.anew.com.zhujiang.activity.mine;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.umeng.analytics.MobclickAgent;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.product.BuyStepThreePayProductActivity;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.utils.VerifyUtil;

/**
 * Created by thinkpad on 2016/7/11.
 */
public class OrderItemActivity extends BaseAppActivity {
    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.buyproductname_tv)
    TextView buyproductnameTv;

    @Bind(R.id.ordernum_tv)
    TextView ordernumTv;
    @Bind(R.id.username_tv)
    TextView usernameTv;
    @Bind(R.id.documentype_tv)
    TextView documentypeTv;
    @Bind(R.id.identificationnumber_tv)
    TextView identificationnumberTv;
    @Bind(R.id.phonecode_tv)
    TextView phonecodeTv;
    @Bind(R.id.emailcode_tv)
    TextView emailcodeTv;
    @Bind(R.id.provicecity_tv)
    TextView provicecityTv;
    @Bind(R.id.areadetailaddress_tv)
    TextView areadetailaddressTv;
    @Bind(R.id.postcode_tv)
    TextView postcodeTv;
    @Bind(R.id.effectivedate_tv)
    TextView effectivedateTv;
    @Bind(R.id.premium_tv)
    TextView premiumTv;
    @Bind(R.id.immediatepayment_btn)
    Button immediatepaymentBtn;
    @Bind(R.id.bottom_buycardview)
    CardView bottomBuycardview;

    @Bind(R.id.policyholdergone_linear)
    LinearLayout policyholdergoneLinear;
    @Bind(R.id.rotateone_img)
    ImageView rotateoneImg;

    @Bind(R.id.policyitemgone_linear)
    LinearLayout policyitemgoneLinear;
    @Bind(R.id.rotatetwo_img)
    ImageView rotatetwoImg;

    private String orderNo, orderStatus, riskName, name, iDType, iDNo, insuredMobile, email, provinceLable, cityLable, address, homeZipCode, cValiDate, prem;
    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    private MessageReceiver receiver;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.order_item));
        initToolBar();
        orderNo = getIntent().getStringExtra("orderNo");
        orderStatus = getIntent().getStringExtra("orderStatus");
        if ("02".equals(orderStatus)) {
            bottomBuycardview.setVisibility(View.VISIBLE);
        }else{
            bottomBuycardview.setVisibility(View.GONE);
        }
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                //Loaddialog.getInstance().dissLoading();
                MyLogUtil.i("msg", "-result-" + result);
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    JSONObject contInfojo = (JSONObject) jsonObject.get("contInfo");
                    //Log.i("json","-insureds-"+contInfojo.getJSONArray("insureds").toString());
                    JSONArray insuredsArray=new JSONArray(contInfojo.getJSONArray("insureds").toString());
                    JSONObject insuredsjo = (JSONObject) insuredsArray.get(0);
                    JSONArray risksArray=new JSONArray(insuredsjo.getJSONArray("risks").toString());
                    JSONObject risksjo = (JSONObject) risksArray.get(0);
                    riskName = risksjo.getString("riskName");
                    //设险种名称
                    buyproductnameTv.setText(riskName);
                    //String orderNo = contInfojo.get("orderNo").toString();
                    //设置订单号
                    ordernumTv.setText(orderNo);
                    name = insuredsjo.get("name").toString();
                    //设置姓名
                    usernameTv.setText(name);
                    iDType = insuredsjo.get("iDType").toString();
                    String iDTyepStr;
                    if (iDType.equals("0")) {
                        iDTyepStr = "身份证";
                    } else {
                        iDTyepStr = "其他证件";
                    }
                    //设置证件类型
                    documentypeTv.setText(iDTyepStr);
                    iDNo = insuredsjo.get("iDNo").toString();
                    //设置证件号
                    identificationnumberTv.setText(VerifyUtil.encryptIdNo(iDNo));
                    insuredMobile = insuredsjo.get("insuredMobile").toString();
                    //设置手机号
                    phonecodeTv.setText(VerifyUtil.encryptPhone(insuredMobile));
                    JSONObject appntInfo = (JSONObject) contInfojo.get("appntInfo");
                    email = appntInfo.get("email").toString();
                    //设置邮箱
                    emailcodeTv.setText(email);
                    //得到省
                    provinceLable = appntInfo.get("provinceLable").toString();
                    //得到市
                    cityLable = appntInfo.get("cityLable").toString();
                    provicecityTv.setText(provinceLable + cityLable);
                    address = appntInfo.getString("address").toString();
                    //设置详细地址
                    areadetailaddressTv.setText(address);
                    homeZipCode = appntInfo.getString("homeZipCode").toString();
                    //设置邮政编码
                    postcodeTv.setText(homeZipCode);
                    cValiDate = contInfojo.getString("cValiDate").toString();
                    //设置生效日期
                    effectivedateTv.setText(cValiDate);
                    prem = contInfojo.getString("prem").toString();
                    //设置保费
                    premiumTv.setText(prem + ".00");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        getOrderItem();
        //注册广播
        receiver = new MessageReceiver();
        IntentFilter filter = new IntentFilter("CHEN.COM.ORDERITEMACTIVITY");
        this.registerReceiver(receiver, filter);
    }

    public class MessageReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean flag=intent.getBooleanExtra("is_finish",false);
            if(flag){
                if(!isFinishing()){
                    finish();
                }
            }
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
        if(receiver!=null){
            unregisterReceiver(receiver);
        }
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }


    private void getOrderItem() {
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("orderNo", orderNo);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);
        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, OrderItemActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.GetOrderInfoUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_orderitem;
    }


    @OnClick({R.id.policyholder_relative, R.id.immediatepayment_btn,R.id.policyitem_relative})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.policyholder_relative:
                int intVisibilit=policyholdergoneLinear.getVisibility();
                if(intVisibilit==0){
                    Animation animation= AnimationUtils.loadAnimation(this, R.anim.rotate_in);
                    animation.setFillAfter(true);
                    rotateoneImg.startAnimation(animation);
                    policyholdergoneLinear.setVisibility(View.GONE);
                }else{
                    Animation animation= AnimationUtils.loadAnimation(this, R.anim.rotate_out);
                    animation.setFillAfter(true);
                    rotateoneImg.startAnimation(animation);
                    policyholdergoneLinear.setVisibility(View.VISIBLE);
                }
                break;
            case R.id.policyitem_relative:
                int inttwoVisibilit=policyitemgoneLinear.getVisibility();
                if(inttwoVisibilit==0){
                    Animation animation= AnimationUtils.loadAnimation(this, R.anim.rotate_in);
                    animation.setFillAfter(true);
                    rotatetwoImg.startAnimation(animation);
                    policyitemgoneLinear.setVisibility(View.GONE);
                }else{
                    Animation animation= AnimationUtils.loadAnimation(this, R.anim.rotate_out);
                    animation.setFillAfter(true);
                    rotatetwoImg.startAnimation(animation);
                    policyitemgoneLinear.setVisibility(View.VISIBLE);
                }
                break;
            case R.id.immediatepayment_btn:
                Intent intent = new Intent(OrderItemActivity.this,
                        BuyStepThreePayProductActivity.class);
                Bundle bundle=new Bundle();
                bundle.putString("orderNo", orderNo);
                bundle.putString("productName", riskName);

                bundle.putString("total", prem);
                bundle.putString("mobile", insuredMobile);
                bundle.putString("idNo", iDNo);
                bundle.putString("name", name);
                bundle.putBoolean("order_pay", true);

                //友盟统计立即购买
                HashMap<String, String> you_map = new HashMap<>();
                you_map.put("order_no", orderNo);
                you_map.put("mobile", insuredMobile);
                you_map.put("quantity", prem);
                MobclickAgent.onEvent(this, "promptpayment", you_map);
                intent.putExtras(bundle);
                startActivity(intent);
                break;
        }
    }
}
