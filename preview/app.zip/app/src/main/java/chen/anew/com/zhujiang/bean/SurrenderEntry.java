package chen.anew.com.zhujiang.bean;

import java.io.Serializable;

/**
 * Created by thinkpad on 2016/7/13.
 */
public class SurrenderEntry implements Serializable {

    private String partWithdrawMin;

    private String partWithdrawUnit;

    private String poliyValue;

    private String isHesitation;

    private String productCode;

    private String contValue;

    private String isMustCancel;

    private String accountNo;

    private String productType;

    private String isPolValid;

    private String orderNo;

    private String availableMoney;

    private String customerMobile;

    private String name;

    private String accountType;

    private String contNo;

    private String partWithdrawMax;

    private String productName;

    private String isPartWithdraw;

    public void setPartWithdrawMin(String partWithdrawMin) {
        this.partWithdrawMin = partWithdrawMin;
    }

    public String getPartWithdrawMin() {
        return this.partWithdrawMin;
    }

    public void setPartWithdrawUnit(String partWithdrawUnit) {
        this.partWithdrawUnit = partWithdrawUnit;
    }

    public String getPartWithdrawUnit() {
        return this.partWithdrawUnit;
    }

    public void setPoliyValue(String poliyValue) {
        this.poliyValue = poliyValue;
    }

    public String getPoliyValue() {
        return this.poliyValue;
    }

    public void setIsHesitation(String isHesitation) {
        this.isHesitation = isHesitation;
    }

    public String getIsHesitation() {
        return this.isHesitation;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductCode() {
        return this.productCode;
    }

    public void setContValue(String contValue) {
        this.contValue = contValue;
    }

    public String getContValue() {
        return this.contValue;
    }

    public void setIsMustCancel(String isMustCancel) {
        this.isMustCancel = isMustCancel;
    }

    public String getIsMustCancel() {
        return this.isMustCancel;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getAccountNo() {
        return this.accountNo;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductType() {
        return this.productType;
    }

    public void setIsPolValid(String isPolValid) {
        this.isPolValid = isPolValid;
    }

    public String getIsPolValid() {
        return this.isPolValid;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getOrderNo() {
        return this.orderNo;
    }

    public void setAvailableMoney(String availableMoney) {
        this.availableMoney = availableMoney;
    }

    public String getAvailableMoney() {
        return this.availableMoney;
    }

    public void setCustomerMobile(String customerMobile) {
        this.customerMobile = customerMobile;
    }

    public String getCustomerMobile() {
        return this.customerMobile;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getAccountType() {
        return this.accountType;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getContNo() {
        return this.contNo;
    }

    public void setPartWithdrawMax(String partWithdrawMax) {
        this.partWithdrawMax = partWithdrawMax;
    }

    public String getPartWithdrawMax() {
        return this.partWithdrawMax;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductName() {
        return this.productName;
    }

    public void setIsPartWithdraw(String isPartWithdraw) {
        this.isPartWithdraw = isPartWithdraw;
    }

    public String getIsPartWithdraw() {
        return this.isPartWithdraw;
    }

}
