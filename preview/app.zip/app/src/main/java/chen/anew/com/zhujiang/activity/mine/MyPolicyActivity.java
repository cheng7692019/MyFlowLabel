package chen.anew.com.zhujiang.activity.mine;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.umeng.analytics.MobclickAgent;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.adpter.FragmentAdapter;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.utils.MobclickAgentUtil;

/**
 * Created by thinkpad on 2016/7/11.
 */
public class MyPolicyActivity extends BaseAppActivity {

    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.tabs)
    TabLayout tabs;
    @Bind(R.id.viewpager)
    ViewPager viewpager;
    @Bind(R.id.tv_title)
    TextView tvTitle;

    private List<String> titles;
    private List<Fragment> fragments;

    public static boolean all_refush=false;
    private FragmentAdapter mFragmentAdapteradapter;

    @Override
    protected void initViews() {
        //关闭activity DurationTrack
        MobclickAgentUtil.closeActivityDurationTrack(this);
        initToolBar();
        tvTitle.setText(getString(R.string.my_policy));
        titles = new ArrayList<>();
        fragments = new ArrayList<>();
        titles.add(getString(R.string.order_all));
        titles.add(getString(R.string.policy_into_effect));
        titles.add(getString(R.string.policy_stop));

        for (int i = 0; i < titles.size(); i++) {
            tabs.addTab(tabs.newTab().setText(titles.get(i)));
        }
        //ContStatus：不写=全部，00=生效中，01=已终止
        Bundle bundle=new Bundle();
        bundle.putString("contStatus","");
        fragments.add(MyNewPolicyFragment.newInstance(bundle));
        Bundle bundle2=new Bundle();
        bundle2.putString("contStatus","00");
        fragments.add(MyNewPolicyFragment.newInstance(bundle2));
        Bundle bundle3=new Bundle();
        bundle3.putString("contStatus","01,03");
        fragments.add(MyNewPolicyFragment.newInstance(bundle3));

        mFragmentAdapteradapter =
                new FragmentAdapter(getSupportFragmentManager(), fragments, titles);
        //给ViewPager设置适配器
        viewpager.setAdapter(mFragmentAdapteradapter);
        //将TabLayout和ViewPager关联起来。
        tabs.setupWithViewPager(viewpager);
        //给TabLayout设置适配器
        tabs.setTabsFromPagerAdapter(mFragmentAdapteradapter);
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        MobclickAgent.onPause(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        MobclickAgent.onResume(this);
        if(all_refush){
            all_refush=false;
            mFragmentAdapteradapter.notifyDataSetChanged();
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_order;
    }
}
