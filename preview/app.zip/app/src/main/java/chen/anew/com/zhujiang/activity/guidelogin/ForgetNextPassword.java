package chen.anew.com.zhujiang.activity.guidelogin;

import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;

/**
 * Created by thinkpad on 2016/6/30.
 */
public class ForgetNextPassword extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.two_code_et)
    EditText twoCodeEt;
    @Bind(R.id.two_send_btn)
    TextView twoSendBtn;
    @Bind(R.id.two_loginpass_et)
    EditText twoLoginpassEt;
    @Bind(R.id.two_confirmpass_et)
    EditText twoConfirmpassEt;
    @Bind(R.id.register_btn)
    Button registerBtn;
    private String code, phone, sessionId;
    private boolean isTime = false;

    private DialogSubscriber dialogSubscriber;
    private Subscriber subscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.set_newpassword));
        initToolBar();
        code = getIntent().getStringExtra("code");
        phone = getIntent().getStringExtra("phone");
        sessionId = getIntent().getStringExtra("sessionId");
        //Toast.makeText(ForgetNextPassword.this, "验证码：" + code, Toast.LENGTH_SHORT).show();
        initTime();
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                //Loaddialog.getInstance().dissLoading();
                if (isTime) {
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        String code = jsonObject.getString("verificationCode");
                        //Toast.makeText(ForgetNextPassword.this, "验证码：" + code, Toast.LENGTH_SHORT).show();
                        isTime = false;
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    //修改密码的返回结果
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        String forgetResult = jsonObject.getString("forgetResult");
                        if ("1".equals(forgetResult)) {
                            Toast.makeText(ForgetNextPassword.this, jsonObject.getString("resultMessage"), Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            }
        };
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_forgetnextpassword;
    }

    @OnClick({R.id.two_send_btn, R.id.register_btn})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.two_send_btn:
                isTime = true;
                initTime();
                getRemoteSendCode();
                break;
            case R.id.register_btn:
                modifyPassword();
                break;
        }
    }

    private void initTime() {
        final int countTime = 60;
        twoSendBtn.setText("重新发送(" + countTime + ")");
        twoSendBtn.setClickable(false);
        subscriber = new Subscriber<Integer>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
            }

            @Override
            public void onNext(Integer integer) {
                if (integer == 0) {
                    //isTime = false;
                    twoSendBtn.setText("重新发送");
                    twoSendBtn.setClickable(true);
                } else {
                    twoSendBtn.setText("重新发送(" + integer + ")");
                }
            }
        };
        Observable.interval(0, 1, TimeUnit.SECONDS)
                .subscribeOn(AndroidSchedulers.mainThread())
                .observeOn(AndroidSchedulers.mainThread())
                .map(new Func1<Long, Integer>() {
                    @Override
                    public Integer call(Long increaseTime) {
                        return countTime - increaseTime.intValue();
                    }
                })
                .take(countTime + 1)
                .subscribe(subscriber);
    }

    //修改密码
    private void modifyPassword() {
        String twoCodeTxt = twoCodeEt.getText().toString();
        String loginPassTxt = twoLoginpassEt.getText().toString();
        String confrimPassTxt = twoConfirmpassEt.getText().toString();
        if (!code.equals(twoCodeTxt)) {
            Toast.makeText(ForgetNextPassword.this, "验证码错误", Toast.LENGTH_SHORT).show();
        } else if (loginPassTxt.length() < 6 | confrimPassTxt.length() < 6) {
            Toast.makeText(ForgetNextPassword.this, "密码不能少于6位", Toast.LENGTH_SHORT).show();
        } else if (!loginPassTxt.equals(confrimPassTxt)) {
            Toast.makeText(ForgetNextPassword.this, "两次输入的密码不一样", Toast.LENGTH_SHORT).show();
        } else {
            //发起请求
            Gson gson = new Gson();
            HashMap<String, Object> map = new HashMap<>();
            HashMap<String, String> map2 = new HashMap<>();

            map2.put("operateType", "2");
            map2.put("sessionId", sessionId);
            map2.put("password", confrimPassTxt);
            map2.put("operateCode", phone);
            map2.put("verificationCode", twoCodeTxt);
            map2.put("mobile", phone);

            map.put("orderType", "32");
            map.put("platType", "3");
            map.put("requestObject", map2);
            String mapjson = gson.toJson(map);
            //Log.i("msg","-mapjson-"+mapjson);
            //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
            dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, ForgetNextPassword.this);
            OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.appForgetPasswordUrl + RequestURL.CreatRequestUrl(mapjson));
        }
    }

    private void getRemoteSendCode() {
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("operateType", "2");
        sessionId = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        map2.put("sessionId", sessionId);
        map2.put("customerMobile", phone);
        map2.put("operateCode", phone);

        map.put("orderType", "32");
        map.put("platType", "3");
        map.put("requestObject", map2);
        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, ForgetNextPassword.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.GetPolicyQueryCodeUrl + RequestURL.CreatRequestUrl(mapjson));
    }
}
