package chen.anew.com.zhujiang.adpter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.bean.PayModeList;
import chen.anew.com.zhujiang.utils.MyLogUtil;

/**
 * Created by thinkpad on 2016/7/8.
 */
public class BankListAdpterOld extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public ArrayList<PayModeList> datas = null;

    public BankListAdpterOld(ArrayList<PayModeList> datas) {
        this.datas = datas;
    }

    private static ClickListener clickListener;

    public interface ClickListener {
        void onItemClick(int position, View v);
    }

    public void setOnItemClickListener(ClickListener clickListener) {
        this.clickListener = clickListener;
    }

    public void updateView(ArrayList<PayModeList> datas) {
        this.datas = datas;
        this.notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_enable_bank, viewGroup, false);
        return new ViewHolder(view);
    }


    //将数据与界面进行绑定的操作
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {
        PayModeList payModeList = datas.get(position);
        ViewHolder viewHolder = (ViewHolder) holder;
        viewHolder.bank_name.setText(payModeList.getBankName());
        String bankCode=payModeList.getBankCode();
        MyLogUtil.i("payMode","-payMode-"+bankCode);
        int bank=Integer.valueOf(bankCode.substring(1));
        switch (bank){
            case 100:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0100);
                break;
            case 102:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0102);
                break;
            case 103:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0103);
                break;
            case 104:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0104);
                break;
            case 105:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0105);
                break;
            case 301:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0301);
                break;
            case 302:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0302);
                break;
            case 303:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0303);
                break;
            case 304:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0304);
                break;
            case 305:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0305);
                break;
            case 306:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0306);
                break;
            case 307:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0307);
                break;
            case 308:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0308);
                break;
            case 309:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0309);
                break;
        }

    }


    //获取数据的数量
    @Override
    public int getItemCount() {
        return datas.size();
    }

    //自定义的ViewHolder，持有每个Item的的所有界面元素
    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView bank_name;
        public ImageView bank_img;

        public ViewHolder(View view) {
            super(view);
            view.setOnClickListener(this);
            bank_name = (TextView) view.findViewById(R.id.bank_name);
            bank_img = (ImageView) view.findViewById(R.id.bank_img);
        }

        @Override
        public void onClick(View view) {
            clickListener.onItemClick(getAdapterPosition(), view);
        }

    }
}

