package chen.anew.com.zhujiang.bean;

import java.io.Serializable;
import java.util.List;

/**
 * Created by thinkpad on 2016/7/8.
 */
public class PayModeList implements Serializable {

    private String bankIcon;

    private List<AccTypeList> accTypeList ;

    private String bankName;

    private String bankCode;

    public void setBankIcon(String bankIcon){
        this.bankIcon = bankIcon;
    }
    public String getBankIcon(){
        return this.bankIcon;
    }
    public void setAccTypeList(List<AccTypeList> accTypeList){
        this.accTypeList = accTypeList;
    }
    public List<AccTypeList> getAccTypeList(){
        return this.accTypeList;
    }
    public void setBankName(String bankName){
        this.bankName = bankName;
    }
    public String getBankName(){
        return this.bankName;
    }
    public void setBankCode(String bankCode){
        this.bankCode = bankCode;
    }
    public String getBankCode(){
        return this.bankCode;
    }

    @Override
    public String toString() {
        return "PayModeList{" +
                "bankIcon='" + bankIcon + '\'' +
                ", accTypeList=" + accTypeList +
                ", bankName='" + bankName + '\'' +
                ", bankCode='" + bankCode + '\'' +
                '}';
    }
}
