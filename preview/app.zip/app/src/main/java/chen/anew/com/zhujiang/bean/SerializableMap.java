package chen.anew.com.zhujiang.bean;

import java.io.Serializable;
import java.util.Map;

/**
 * Created by thinkpad on 2016/7/6.
 */
public class SerializableMap implements Serializable {

    private Map<String,String> map;

    public SerializableMap(Map<String,String> map){
        this.map=map;
    }

    public Map<String, String> getMap() {
        return map;
    }

    public void setMap(Map<String, String> map) {
        this.map = map;
    }
}
