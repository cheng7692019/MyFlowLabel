package chen.anew.com.zhujiang.bean;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.List;

import chen.anew.com.zhujiang.greendao.Activity_List;

/**
 * Created by thinkpad on 2016/6/30.
 */
public class ActivityBean implements Parcelable {

    private String activity_month;

    private List<Activity_List> activity_List;

    public ActivityBean(String activity_month, List<Activity_List> activity_List) {
        this.activity_month = activity_month;
        this.activity_List = activity_List;
    }

    protected ActivityBean(Parcel in) {
        activity_month = in.readString();
        activity_List = in.createTypedArrayList(Activity_List.CREATOR);
    }

    public static final Creator<ActivityBean> CREATOR = new Creator<ActivityBean>() {
        @Override
        public ActivityBean createFromParcel(Parcel in) {
            return new ActivityBean(in);
        }

        @Override
        public ActivityBean[] newArray(int size) {
            return new ActivityBean[size];
        }
    };

    public void setActivity_month(String activity_month) {
        this.activity_month = activity_month;
    }

    public String getActivity_month() {
        return this.activity_month;
    }

    public void setActivity_List(List<Activity_List> activity_List) {
        this.activity_List = activity_List;
    }

    public List<Activity_List> getActivity_List() {
        return this.activity_List;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(activity_month);
        dest.writeTypedList(activity_List);
    }
}
