package chen.anew.com.zhujiang.activity.mine.persondata;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.Bind;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.swipehelper.SimpleItemTouchHelperCallback;
import chen.anew.com.zhujiang.adpter.BankUsedListAdpter;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.bean.EbizUserBindcardDTO;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;

/**
 * Created by thinkpad on 2016/7/18.
 */
public class MyBankCardActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.common_recyclerview)
    RecyclerView commonRecyclerview;
    @Bind(R.id.no_policy)
    ImageView noPolicy;

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    private ArrayList<EbizUserBindcardDTO> ebizUserBindcardDTOLists;
    private BankUsedListAdpter bankUsedListAdpter;
    private ItemTouchHelper mItemTouchHelper;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.mine_bank));
        initToolBar();
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg", "-result-" + result);
                Gson gson = new Gson();
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String resultCode = jsonObject.getString("resultCode");
                    if ("1".equals(resultCode)) {
                        ebizUserBindcardDTOLists = gson.fromJson(jsonObject.getString("ebizUserBindcardDTOList"), new TypeToken<ArrayList<EbizUserBindcardDTO>>() {
                        }.getType());
                        if(ebizUserBindcardDTOLists!=null&&ebizUserBindcardDTOLists.size()>0){
                            bankUsedListAdpter.updateView(ebizUserBindcardDTOLists);
                        }else{
                            commonRecyclerview.setVisibility(View.GONE);
                            noPolicy.setVisibility(View.VISIBLE);
                        }
                    } else {
                        Toast.makeText(MyBankCardActivity.this, jsonObject.getString("resultMessage"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        //初始化 commonRecyclerview
        commonRecyclerview.setHasFixedSize(true);
        final LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        commonRecyclerview.setLayoutManager(llm);
        ebizUserBindcardDTOLists=new ArrayList<>();
        bankUsedListAdpter= new BankUsedListAdpter(ebizUserBindcardDTOLists,MyBankCardActivity.this);
        commonRecyclerview.setAdapter(bankUsedListAdpter);
        ItemTouchHelper.Callback callback = new SimpleItemTouchHelperCallback(bankUsedListAdpter,this);
        mItemTouchHelper = new ItemTouchHelper(callback);
        mItemTouchHelper.attachToRecyclerView(commonRecyclerview);
        getBankUsedList();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.common_list;
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void getBankUsedList() {
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("customerId", Common.userInfo.getCustomerId());

        map.put("orderType", "32");
        map.put("platType", "3");
        map.put("requestObject", map2);
        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, MyBankCardActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.getBankListByIdUrl + RequestURL.CreatRequestUrl(mapjson));
    }


}
