package chen.anew.com.zhujiang.activity.mine;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.anton46.stepsview.StepsView;
import com.google.gson.Gson;
import com.umeng.analytics.MobclickAgent;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.bean.SurrenderEntry;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.VerifyUtil;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;

/**
 * Created by thinkpad on 2016/7/13.
 */
public class SurrenderEntryStepTwoActivity extends BaseAppActivity {
    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.stepsView)
    StepsView stepsView;
    @Bind(R.id.applicationsamount_tv)
    TextView applicationsamountTv;
    @Bind(R.id.netfee_tv)
    TextView netfeeTv;
    @Bind(R.id.actualamountreceived_tv)
    TextView actualamountreceivedTv;
    @Bind(R.id.postaccountvalue_tv)
    TextView postaccountvalueTv;
    @Bind(R.id.refundaccount_tv)
    TextView refundaccountTv;
    @Bind(R.id.accountholder_tv)
    TextView accountholderTv;
    @Bind(R.id.phonecode_tv)
    TextView phonecodeTv;
    @Bind(R.id.inputviacode_et)
    EditText inputviacodeEt;
    @Bind(R.id.sendviacode_btn)
    TextView sendviacodeBtn;
    @Bind(R.id.save_btn)
    Button saveBtn;

    private SurrenderEntry surrenderEntry;
    private final String[] labels = {"", ""};
    private String withdrawMoney, netfee, availableMoney, isCancelPolicy, isWithdrawAll, code;

    private Subscriber subscriber;
    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private boolean isCodeflag = false;

    private MessageReceiver receiver;
    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.confirm_surrender_info));
        initToolBar();
        Bundle bundle = getIntent().getExtras();
        surrenderEntry = (SurrenderEntry) bundle.getSerializable("surrenderEntry");
        withdrawMoney = bundle.getString("withdrawMoney");
        netfee = bundle.getString("netfee");
        availableMoney = bundle.getString("availableMoney");

        isCancelPolicy = bundle.getString("isCancelPolicy");
        isWithdrawAll = bundle.getString("isWithdrawAll");

        applicationsamountTv.setText(withdrawMoney + "元");
        netfeeTv.setText(netfee + "元");
        actualamountreceivedTv.setText(availableMoney + "元");

        postaccountvalueTv.setText( VerifyUtil.roundTo2(Double.valueOf(surrenderEntry.getContValue())-(Double.valueOf(withdrawMoney)))+ "元");
        String accountNo = surrenderEntry.getAccountNo();
        refundaccountTv.setText(surrenderEntry.getAccountType() + "(" + accountNo.substring(accountNo.length() - 4) + ")");
        accountholderTv.setText(surrenderEntry.getName());
        phonecodeTv.setText(surrenderEntry.getCustomerMobile());

        stepsView.setLabels(labels)
                .setBarColorIndicator(getResources().getColor(R.color.chang_white))
                .setProgressColorIndicator(getResources().getColor(R.color.colorAccent))
                .setLabelColorIndicator(getResources().getColor(R.color.white))
                .setCompletedPosition(1)
                .drawView();

        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                if (isCodeflag) {
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        code = jsonObject.getString("verificationCode");
                        isCodeflag=false;
                        //Toast.makeText(SurrenderEntryStepTwoActivity.this, "验证码：" + code, Toast.LENGTH_LONG).show();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    //确认退保
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        String operationResult = jsonObject.getString("operationResult");
                        //处理结果：1-成功,0-失败
                        if ("1".equals(operationResult)) {
                            Intent intent = new Intent(SurrenderEntryStepTwoActivity.this, ReFundSuccessActivity.class);

                            //友盟统计退保
                            HashMap<String, String> you_map = new HashMap<>();
                            you_map.put("cont_no",surrenderEntry.getContNo());
                            you_map.put("mobile", Common.userInfo.getMobile());
                            you_map.put("quantity",availableMoney);
                            you_map.put("is_success","true");
                            MobclickAgent.onEvent(SurrenderEntryStepTwoActivity.this, "surrender_03", you_map);

                            startActivity(intent);
                        } else {
                            Intent iFalse = new Intent(SurrenderEntryStepTwoActivity.this, ReFundFailActivity.class);
                            iFalse.putExtra("contNo", surrenderEntry.getContNo());
                            //友盟统计退保
                            HashMap<String, String> you_map = new HashMap<>();
                            you_map.put("cont_no",surrenderEntry.getContNo());
                            you_map.put("mobile", Common.userInfo.getMobile());
                            you_map.put("quantity",availableMoney);
                            you_map.put("is_success","false");
                            MobclickAgent.onEvent(SurrenderEntryStepTwoActivity.this, "surrender_03", you_map);

                            startActivity(iFalse);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        //注册广播
        receiver = new MessageReceiver();
        IntentFilter filter = new IntentFilter("CHEN.COM.SURRENDERENTRYSTEPTWOACTIVITY");
        this.registerReceiver(receiver, filter);
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public class MessageReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean flag=intent.getBooleanExtra("is_finish",false);
            if(flag){
                if(!isFinishing()){
                    finish();
                }
            }
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(dialogSubscriber!=null&&dialogSubscriber.isUnsubscribed()){
            dialogSubscriber.unsubscribe();
        }
        if(receiver!=null){
            unregisterReceiver(receiver);
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_surrenderentry_steptwo;
    }

    @OnClick({R.id.sendviacode_btn, R.id.save_btn})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.sendviacode_btn:
                //发送验证码
                initTime();
                sendVerifCode();
                break;
            case R.id.save_btn:
                String inputCode = inputviacodeEt.getText().toString();
                if (code == null) {
                    Toast.makeText(this, "请先请求发送验证码", Toast.LENGTH_SHORT).show();
                } else if (code != null && !code.equals(inputCode)) {
                    Toast.makeText(this, "验证码不正确", Toast.LENGTH_SHORT).show();
                } else {
                    confirmRefund();
                }
                break;
        }
    }


    private void initTime() {
        final int countTime = 60;
        sendviacodeBtn.setText("重新发送(" + countTime + ")");
        sendviacodeBtn.setClickable(false);
        subscriber = new Subscriber<Integer>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
            }

            @Override
            public void onNext(Integer integer) {
                if (integer == 0) {
                    sendviacodeBtn.setText("重新发送");
                    sendviacodeBtn.setClickable(true);
                } else {
                    sendviacodeBtn.setText("重新发送(" + integer + ")");
                }
            }
        };
        Observable.interval(0, 1, TimeUnit.SECONDS)
                .subscribeOn(AndroidSchedulers.mainThread())
                .observeOn(AndroidSchedulers.mainThread())
                .map(new Func1<Long, Integer>() {
                    @Override
                    public Integer call(Long increaseTime) {
                        return countTime - increaseTime.intValue();
                    }
                })
                .take(countTime + 1)
                .subscribe(subscriber);
    }

    private void sendVerifCode() {
        isCodeflag = true;
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("operateType", "1");
        map2.put("operateCode", surrenderEntry.getOrderNo());
        map2.put("mobile", surrenderEntry.getCustomerMobile());

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.sendVerificationCodeUrl + RequestURL.CreatRequestUrl(mapjson));

    }

    private void confirmRefund() {

        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();

        map2.put("availableMoney", availableMoney);
        map2.put("contNo", surrenderEntry.getContNo());
        map2.put("orderNo", surrenderEntry.getOrderNo());
        map2.put("verificationCode", code);
        map2.put("withdrawMoney", withdrawMoney);
        map2.put("isWithdrawAll", isWithdrawAll);
        map2.put("isCancelPolicy", isCancelPolicy);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.ConfirmRefundUrl + RequestURL.CreatRequestUrl(mapjson));

    }
}
