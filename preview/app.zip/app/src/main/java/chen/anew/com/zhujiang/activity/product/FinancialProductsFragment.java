package chen.anew.com.zhujiang.activity.product;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.greenrobot.greendao.query.Query;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.Bind;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.adpter.ProductAdpter;
import chen.anew.com.zhujiang.base.BaseFragment;
import chen.anew.com.zhujiang.greendao.ProductList;
import chen.anew.com.zhujiang.greendao.ProductListDao;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.OkHttpUtils;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.pullrefresh.layout.BaseFooterView;
import chen.anew.com.zhujiang.pullrefresh.layout.BaseHeaderView;
import chen.anew.com.zhujiang.pullrefresh.layout.PullRefreshLayout;
import chen.anew.com.zhujiang.rxandroid.RecyclerViewSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import me.zhanghai.android.materialprogressbar.IndeterminateProgressDrawable;

/**
 * Created by thinkpad on 2016/6/30.
 */
public class FinancialProductsFragment extends BaseFragment implements BaseHeaderView.OnRefreshListener, BaseFooterView.OnLoadListener {

    @Bind(R.id.recyclerview)
    RecyclerView mRecyclerView;
    @Bind(R.id.root)
    PullRefreshLayout pullRefreshLayout;
    @Bind(R.id.header)
    BaseHeaderView headerView;
    @Bind(R.id.footer)
    BaseFooterView footerView;
    @Bind(R.id.no_policy)
    ImageView no_policy;
    @Bind(R.id.progress_bar)
    ProgressBar progressBar;
    //    private CommonSubscriber commonSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private ProductAdpter productAdpter;
    private ArrayList<ProductList> productLists;
    private int mcurrentPage = 1;
    private RecyclerViewSubscriber recyclerViewSubscriber;

    private static boolean is_first=true;
    private ProductListDao productListDao;


    @Override
    protected void initViews() {
        mPageName="FinancialProductsFragment";
        productListDao = MyApp.daoSession.getProductListDao();
        IndeterminateProgressDrawable indeterminateProgressDrawable = new IndeterminateProgressDrawable(getActivity());
        indeterminateProgressDrawable.setTint(getActivity().getResources().getColor(R.color.colorAccent));
        progressBar.setProgressDrawable(indeterminateProgressDrawable);
        progressBar.setIndeterminateDrawable(indeterminateProgressDrawable);
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg", "-result-" + result);
                Gson gson = new Gson();
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String resultCode = jsonObject.getString("resultCode");
                    if ("1".equals(resultCode)) {
                        //成功获得活动列表
//                        JSONObject jsonObject = new JSONObject(result)
                        List<ProductList> nowProductList = gson.fromJson(jsonObject.getString("productList"), new TypeToken<ArrayList<ProductList>>() {
                        }.getType());
                        //初始化列表
                        productLists.addAll(nowProductList);
                        if (mcurrentPage == 1) {
                            if (nowProductList != null && nowProductList.size() + 1 < 5) {
                                pullRefreshLayout.setHasFooter(false);
                            } else {
                                pullRefreshLayout.setHasFooter(true);
                            }
                            is_first=false;
                            productListDao.insertOrReplaceInTx(nowProductList);
                            productAdpter.updateView(productLists);
                        } else {
                            //加载更多
                            if (nowProductList != null && nowProductList.size() + 1 < 5) {
                                pullRefreshLayout.setHasFooter(false);
                            } else {
                                pullRefreshLayout.setHasFooter(true);
                            }
                            footerView.stopLoad();
                            productAdpter.updateView(productLists);
                        }
                    } else {
                        pullRefreshLayout.setHasFooter(false);
                        if (productLists.size() == 0) {
                            no_policy.setVisibility(View.VISIBLE);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        initReview();
    }

    private void initReview() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(layoutManager);

        productLists = new ArrayList<>();
        productAdpter = new ProductAdpter(productLists, getContext());
        mRecyclerView.setAdapter(productAdpter);
        headerView.setOnRefreshListener(this);
        footerView.setOnLoadListener(this);
        productAdpter.setOnItemClickListener(new ProductAdpter.ClickListener() {
            @Override
            public void onItemClick(int position, View v) {
                ProductList product_list = productLists.get(position);
                Intent intent = new Intent(getActivity(), ProductItemActivity.class);
                Bundle bundle = new Bundle();
                bundle.putParcelable("product_list", product_list);
                intent.putExtras(bundle);
                startActivity(intent);
                MyLogUtil.i("click", "-activity_list-" + product_list.toString());
            }
        });
        if(is_first){
            getAppWebsiteProductList(mcurrentPage);
        }else{
            getNoWebProductList();
        }
    }

    private void getNoWebProductList(){
        Query query = productListDao.queryBuilder().where(ProductListDao.Properties.ProductType.eq("1"))
                .build();
        List<ProductList> nowProductList = (List<ProductList>) query.list();
        if(nowProductList!=null&&nowProductList.size()>0){
            progressBar.setVisibility(View.GONE);
            productLists.clear();
            productLists.addAll(nowProductList);
            productAdpter.updateView(productLists);
            no_policy.setVisibility(View.GONE);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (recyclerViewSubscriber != null && recyclerViewSubscriber.isUnsubscribed()) {
            recyclerViewSubscriber.unsubscribe();
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.common_new_recyclerview;
    }

    private void getAppWebsiteProductList(int mcurrentPage) {
        if (!OkHttpUtils.isNetworkAvailable(getActivity())) {
            if (headerView != null) {
                headerView.stopRefresh();
            }
            getNoWebProductList();
            pullRefreshLayout.setHasFooter(false);
            progressBar.setVisibility(View.GONE);
            //Toast.makeText(getActivity(), "暂时没有可用的网络", Toast.LENGTH_SHORT).show();
            return;
        }
        if (mcurrentPage == 1) {
            productLists.clear();
        }
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        HashMap<String, Object> map3 = new HashMap<>();

        map2.put("currentPage", "" + mcurrentPage);
        map2.put("pageSize", "5");
        map2.put("queryAll", "false");

        map3.put("type", "1");
        map3.put("pageParams", map2);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map3);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        recyclerViewSubscriber = new RecyclerViewSubscriber(subscriberOnNextListener, getActivity(), headerView, footerView, progressBar);
        OkHttpObservable.getInstance().getData(recyclerViewSubscriber, RequestURL.GetAppWebsiteProductListUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    @Override
    public void onLoad(BaseFooterView baseFooterView) {
        mcurrentPage = mcurrentPage + 1;
        getAppWebsiteProductList(mcurrentPage);
    }

    @Override
    public void onRefresh(BaseHeaderView baseHeaderView) {
        mcurrentPage = 1;
        getAppWebsiteProductList(mcurrentPage);
    }
}
