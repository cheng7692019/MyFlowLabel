package chen.anew.com.zhujiang.activity.mine.persondata;

import android.content.Intent;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.utils.VerifyUtil;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;

/**
 * Created by thinkpad on 2016/7/18.
 */
public class PhoneCodeBindActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.right_tv_title)
    TextView rightTvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.username_et)
    EditText usernameEt;
    @Bind(R.id.valcode_et)
    EditText valcodeEt;
    @Bind(R.id.sendcode_btn)
    Button sendcodeBtn;

    private DialogSubscriber dialogSubscriber;
    private Subscriber subscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private String code, phoneTxt,sessionId;
    private int http_step;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.bind_phone));
        rightTvTitle.setText(getResources().getString(R.string.complete));
        initToolBar();

        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg", "-responseBody-" + result);
                switch (http_step) {
                    case 1:
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            String mobileAuthFlag = jsonObject.getString("mobileAuthFlag");
                            if ("1".equals(mobileAuthFlag)) {
                                http_step=-1;
                                Toast.makeText(PhoneCodeBindActivity.this, "该手机号已注册不能再绑定", Toast.LENGTH_SHORT).show();
                            } else {
                                initTime();
                                getRemoteSendCode(phoneTxt);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 2:
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            code = jsonObject.getString("verificationCode");
                            //Toast.makeText(PhoneCodeBindActivity.this, "验证码：" + code, Toast.LENGTH_LONG).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 3:
                        if(TextUtils.isEmpty(result)){
                            Toast.makeText(PhoneCodeBindActivity.this, "验证失败", Toast.LENGTH_SHORT).show();
                        }else{
                            try {
                                JSONObject jsonObject=new JSONObject(result);
                                String verificationCode=jsonObject.getString("verificationCode");
                                if ("0".equals(verificationCode)) {
                                    modifyPhone();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        break;
                    case 4:
                        try {
                            JSONObject jsonObject=new JSONObject(result);
                            String updateResult=jsonObject.getString("updateResult");
                            String resultMessage=jsonObject.getString("resultMessage");
                            if ("1".equals(updateResult)) {
                                Toast.makeText(PhoneCodeBindActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                                Common.userInfo.setMobile(phoneTxt);
                                //创建Intent对象
                                Intent intent = new Intent();
                                //设置Intent的Action属性
                                intent.setAction("CHEN.COM.UPDATEPERSONDATA");
                                intent.putExtra("mobile",phoneTxt);
                                //发送广播,改变手机显示
                                sendBroadcast(intent);
                                MyApp.daoSession.getUserInfoDao().update(Common.userInfo);
                                PhoneCodeBindActivity.this.finish();
                            } else if ("0".equals(updateResult)) {
                                Toast.makeText(PhoneCodeBindActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        break;
                }
            }
        };
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_bindphone;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
        if (subscriber != null && subscriber.isUnsubscribed()) {
            subscriber.unsubscribe();
        }
    }

    private void initTime() {
        final int countTime = 60;
        sendcodeBtn.setText("重新发送(" + countTime + ")");
        sendcodeBtn.setClickable(false);
        subscriber = new Subscriber<Integer>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
            }

            @Override
            public void onNext(Integer integer) {
                if (integer == 0) {
                    sendcodeBtn.setText("重新发送");
                    sendcodeBtn.setClickable(true);
                } else {
                    sendcodeBtn.setText("重新发送(" + integer + ")");
                }
            }
        };
        Observable.interval(0, 1, TimeUnit.SECONDS)
                .subscribeOn(AndroidSchedulers.mainThread())
                .observeOn(AndroidSchedulers.mainThread())
                .map(new Func1<Long, Integer>() {
                    @Override
                    public Integer call(Long increaseTime) {
                        return countTime - increaseTime.intValue();
                    }
                })
                .take(countTime + 1)
                .subscribe(subscriber);
    }

    @OnClick({R.id.right_tv_title, R.id.sendcode_btn})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.right_tv_title:
                phoneTxt = usernameEt.getText().toString();
                String codeTxt = valcodeEt.getText().toString();
                if(http_step==-1){
                    Toast.makeText(PhoneCodeBindActivity.this, "该手机号已注册不能再绑定", Toast.LENGTH_SHORT).show();
                }else if (!VerifyUtil.VerificationPhone(phoneTxt)) {
                    Toast.makeText(PhoneCodeBindActivity.this, "手机号码格式不对", Toast.LENGTH_SHORT).show();
                } else if (code==null) {
                    Toast.makeText(PhoneCodeBindActivity.this, "请先请求发送验证码", Toast.LENGTH_SHORT).show();
                } else if (!code.equals(codeTxt)) {
                    Toast.makeText(PhoneCodeBindActivity.this, "手机号码格式不对", Toast.LENGTH_SHORT).show();
                }else{
                    //更改手机号
                    valCodePhone();
                }
                break;
            case R.id.sendcode_btn:
                phoneTxt = usernameEt.getText().toString();
                if (!VerifyUtil.VerificationPhone(phoneTxt)) {
                    Toast.makeText(PhoneCodeBindActivity.this, "手机号码格式不对", Toast.LENGTH_SHORT).show();
                } else {
                    isMobiles(phoneTxt);
                }
                break;
        }
    }

    private void isMobiles(String phoneTxt) {
        http_step = 1;
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("mobile", phoneTxt);
        map.put("orderType", "32");
        map.put("platType", "3");
        map.put("requestObject", map2);
        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, PhoneCodeBindActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.GetIsMobileAuthUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    private void getRemoteSendCode(String phoneTxt) {
        http_step = 2;
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("operateType", "2");
        sessionId = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        map2.put("sessionId", sessionId);
        map2.put("customerMobile", phoneTxt);
        map2.put("operateCode", phoneTxt);

        map.put("orderType", "32");
        map.put("platType", "3");
        map.put("requestObject", map2);
        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, PhoneCodeBindActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.GetPolicyQueryCodeUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    private void valCodePhone() {
        http_step = 3;
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("operateType", "2");
        sessionId = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        map2.put("verificationCode", code);
        map2.put("sessionId", sessionId);
        map2.put("operateCode", phoneTxt);
        map2.put("customerMobile", phoneTxt);

        map.put("orderType", "32");
        map.put("platType", "3");
        map.put("requestObject", map2);
        String mapjson = gson.toJson(map);
        MyLogUtil.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, PhoneCodeBindActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.validatePolicyQueryCodeUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    private void modifyPhone() {
        http_step = 4;
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("customerId", Common.userInfo.getCustomerId());
        map2.put("mobile", phoneTxt);

        map.put("orderType", "32");
        map.put("platType", "3");
        map.put("requestObject", map2);
        String mapjson = gson.toJson(map);
        MyLogUtil.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, PhoneCodeBindActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.editAccountInfoUrl + RequestURL.CreatRequestUrl(mapjson));
    }

}
