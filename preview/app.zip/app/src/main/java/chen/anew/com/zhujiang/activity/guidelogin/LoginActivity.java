package chen.anew.com.zhujiang.activity.guidelogin;

import android.content.Intent;
import android.os.Build;
import android.support.design.widget.TextInputLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.igexin.sdk.PushManager;
import com.readystatesoftware.systembartint.SystemBarTintManager;
import com.umeng.analytics.MobclickAgent;

import org.greenrobot.greendao.query.Query;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.activity.main.MainActivity;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.greendao.UserInfo;
import chen.anew.com.zhujiang.greendao.UserInfoDao;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.utils.SharedPreferencesUtils;
import chen.anew.com.zhujiang.utils.VerifyUtil;
import chen.anew.com.zhujiang.utils.ViewUtils;
import chen.anew.com.zhujiang.widget.EditSpinner;
import chen.anew.com.zhujiang.widget.WaveLoadingView;
import de.hdodenhof.circleimageview.CircleImageView;


/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends BaseAppActivity {

    @Bind(R.id.email)
    EditSpinner email;
    @Bind(R.id.password)
    EditText password;
    @Bind(R.id.waveLoadingView)
    WaveLoadingView waveLoadingView;
    @Bind(R.id.toolbar)
    Toolbar app_bar;
    @Bind(R.id.tv_title)
    TextView tv_title;

    @Bind(R.id.textinput_username)
    TextInputLayout textinput_username;
    @Bind(R.id.textinput_password)
    TextInputLayout textinput_password;
    @Bind(R.id.edit_sipnner_email)
    EditText edit_sipnner_email;
    @Bind(R.id.head_img)
    CircleImageView head_img;
    @Bind(R.id.email_login_form)
    LinearLayout emailLoginForm;

    /*@Bind(R.id.bottom_linear)
    LinearLayout bottomLinear;*/

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private UserInfoDao userDao;

    @Override
    protected void initViews() {
        textinput_password = (TextInputLayout) findViewById(R.id.textinput_password);
        tv_title.setText(getResources().getString(R.string.user_login));
        initToolBar();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ViewUtils.setTranslucentStatus(LoginActivity.this, true);
            SystemBarTintManager tintManager = new SystemBarTintManager(this);
            // enable status bar tint
            tintManager.setStatusBarTintEnabled(true);
            // enable navigation bar tint
            tintManager.setNavigationBarTintEnabled(true);
            tintManager.setTintColor(ContextCompat.getColor(this, R.color.white));
        }
        PushManager.getInstance().initialize(this);
        userDao = MyApp.daoSession.getUserInfoDao();
        Query query = userDao.queryBuilder().build();
        List userList = query.list();
        email.setHead_img(head_img);
        email.setItemData(userList);
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                //Loaddialog.getInstance().dissLoading();
                Gson gson = new Gson();
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String loginResult = jsonObject.getString("loginResult");
                    if ("0".equals(loginResult)) {
                        Toast.makeText(LoginActivity.this, "" + jsonObject.getString("resultMessage"), Toast.LENGTH_SHORT).show();
                    } else if ("1".equals(loginResult)) {
                        UserInfo userInfo = gson.fromJson(jsonObject.getString("userInfo").toString(), UserInfo.class);
                        MyLogUtil.i("msg", "-userInfo-" + userInfo.toString());
                        Common.userInfo = userInfo;
                        Common.customer_id = userInfo.getCustomerId();
                        MobclickAgent.onProfileSignIn(Common.customer_id);
                        //保存登录信息
                       /* Query query = userDao.queryBuilder().where(
                                UserInfoDao.Properties.CustomerId.eq(Common.customer_id))
                                .build();
                        List userList = query.list();
                        if(userList!=null&userList.size()>0){
                            UserInfo2 userInfo2= (UserInfo2) userList.get(0);
                            userDao.delete(userInfo2);
                            userDao.insert(userInfo);
                        }else{
                            userDao.insert(userInfo);
                        }*/
                        //缓存fragment通知更新姓名图像
                        Intent intent2 = new Intent();
                        //设置Intent的Action属性
                        intent2.setAction("CHEN.COM.UPDATEPERSONDATA_MINE");
                        intent2.putExtra("realname", userInfo.getRealName());
                        intent2.putExtra("headimgUrl", userInfo.getHeadimgurl());
                        //发送广播,改变姓名显示
                        sendBroadcast(intent2);

                        userDao.insertOrReplace(userInfo);
                        SharedPreferencesUtils.setParam(LoginActivity.this, SharedPreferencesUtils.CUSTOMER_ID, Common.customer_id);
                        String pass = password.getText().toString();
                        SharedPreferencesUtils.setParam(LoginActivity.this, SharedPreferencesUtils.CUSTOMER_PASSWORD, pass);
                        startActivity(new Intent(LoginActivity.this, MainActivity.class));
                        finish();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };

        //验证手机号
        edit_sipnner_email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (s.length() > 6 && VerifyUtil.checkNumber(s.toString())) {
                    edit_sipnner_email.setInputType(InputType.TYPE_CLASS_NUMBER); //输入类型
                    edit_sipnner_email.setFilters(new InputFilter[]{new InputFilter.LengthFilter(11)}); //
                } else if (s.length() < 6) {
                    edit_sipnner_email.setInputType(InputType.TYPE_CLASS_TEXT); //输入类型
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        //获取焦点
       /* password.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                AnimatorSet animatorSet = new AnimatorSet();//组合动画
                float curTranslationY = emailLoginForm.getTranslationY();
                ObjectAnimator animator = ObjectAnimator.ofFloat(emailLoginForm, "translationY", curTranslationY, -400f);
                ObjectAnimator alpha = ObjectAnimator.ofFloat(emailLoginForm, "alpha", 0.3f, 1f);
                animatorSet.setInterpolator(new DecelerateInterpolator());
                animatorSet.play(animator).with(alpha);//两个动画同时开始
                animatorSet.setDuration(300);
                animatorSet.start();

                AnimatorSet animatorSet2 = new AnimatorSet();//组合动画
                float curTranslationY2 = bottomLinear.getTranslationY();
                ObjectAnimator animator2 = ObjectAnimator.ofFloat(bottomLinear, "translationY", curTranslationY2, -400f);
                ObjectAnimator alpha2 = ObjectAnimator.ofFloat(bottomLinear, "alpha", 0.3f, 1f);
                animatorSet2.setInterpolator(new DecelerateInterpolator());
                animatorSet2.play(animator2).with(alpha2);//两个动画同时开始
                animatorSet2.setDuration(300);
                animatorSet2.start();
            }
        });*/
        waveLoadingView.setFull(true);
//        waveLoadingView.setMeasuredDimension();
        /*mWaveLoadingView.setShapeType(WaveLoadingView.ShapeType.CIRCLE);
        mWaveLoadingView.setTopTitle("Top Title");
        mWaveLoadingView.setCenterTitleColor(Color.GRAY);
        mWaveLoadingView.setBottomTitleSize(18);
        mWaveLoadingView.setProgressValue(80);
        mWaveLoadingView.setBorderWidth(10);
        mWaveLoadingView.setAmplitudeRatio(60);
        mWaveLoadingView.setWaveColor(Color.GRAY);
        mWaveLoadingView.setBorderColor(Color.GRAY);*/
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_login;
    }

    private void initToolBar() {
        setSupportActionBar(app_bar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        app_bar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
    }

    @OnClick({R.id.login_btn, R.id.register_btn, R.id.forget_tv})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.forget_tv:
                startActivity(new Intent(LoginActivity.this, ForgetPassword.class));
                break;
            case R.id.login_btn:
                //Loaddialog.getInstance().initLoding(LoginActivity.this);
                String pass = password.getText().toString();
                String username = email.getEditString();
                if (pass.length() < 6) {
                    Toast.makeText(LoginActivity.this, "密码不能少于6位", Toast.LENGTH_SHORT).show();
                } else if (username.length() < 6) {
                    Toast.makeText(LoginActivity.this, "用户名格式不对", Toast.LENGTH_SHORT).show();
                } else if (VerifyUtil.checkNumber(username) && !VerifyUtil.VerificationPhone(username)) {
                    Toast.makeText(LoginActivity.this, "用户名格式不对", Toast.LENGTH_SHORT).show();
                } else {
                    loginRemote();
                }
                break;
            case R.id.register_btn:
               /* if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    animator = ViewAnimationUtils.createCircularReveal(
                            register_btn,
                            getWidth(),
                            getHeight(),
                            getWidth(),
                            0);
                }*/
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
//                finish();
                break;
        }
    }

    private void loginRemote() {
        String phone = email.getEditString();
        String pass = password.getText().toString();
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("user", phone);
        map2.put("password", pass);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, LoginActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.LoginUrl + RequestURL.CreatRequestUrl(mapjson));
    }


}

