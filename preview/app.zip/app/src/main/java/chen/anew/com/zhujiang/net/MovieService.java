package chen.anew.com.zhujiang.net;

/**
 * Created by liukun on 16/3/9.
 */
public interface MovieService {


//    @GET("/mobile/appUser/appUser.action")
//    Observable<ResponseBody> getLogin(@QueryMap Map<String, String> options);


}
