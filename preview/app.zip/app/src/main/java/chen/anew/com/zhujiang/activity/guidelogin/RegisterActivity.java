package chen.anew.com.zhujiang.activity.guidelogin;


import android.content.Intent;
import android.graphics.Color;
import android.support.v7.widget.Toolbar;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.anton46.stepsview.StepsView;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.activity.main.MainActivity;
import chen.anew.com.zhujiang.activity.mine.setup.SetPayPasswordActivity;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.greendao.UserInfo;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.utils.SharedPreferencesUtils;
import chen.anew.com.zhujiang.utils.VerifyUtil;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;

/**
 * Created by thinkpad on 2016/6/26.
 */
public class RegisterActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.right_tv_title)
    TextView rightTvTitle;
    @Bind(R.id.stepsView)
    StepsView stepsView;
    @Bind(R.id.one_phone)
    EditText one_phone;

//    private final String[] labels = {"①", "②", "③"};
    private final String[] labels = {"", "", ""};
    @Bind(R.id.register_one_linear)
    LinearLayout registerOneLinear;
    @Bind(R.id.two_text_tv)
    TextView twoTextTv;
    @Bind(R.id.two_phone_tv)
    TextView twoPhoneTv;
    @Bind(R.id.two_code_et)
    EditText twoCodeEt;
    @Bind(R.id.two_send_btn)
    TextView twoSendBtn;
    @Bind(R.id.two_loginpass_et)
    EditText twoLoginpassEt;
    @Bind(R.id.two_confirmpass_et)
    EditText twoConfirmpassEt;
    @Bind(R.id.register_two_linear)
    LinearLayout registerTwoLinear;
    @Bind(R.id.register_three_linear)
    LinearLayout registerThreeLinear;

    private DialogSubscriber dialogSubscriber;
    private Subscriber subscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    private int step_tag = 1;
    private String phoneTxt, sessionId, code,confrimPassTxt;
    private boolean isTime = false;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.input_phone));
        rightTvTitle.setText(getResources().getString(R.string.over));
        rightTvTitle.setVisibility(View.GONE);
        initToolBar();
        stepsView.setLabels(labels)
                .setBarColorIndicator(getResources().getColor(R.color.chang_white))
                .setProgressColorIndicator(getResources().getColor(R.color.colorAccent))
                .setLabelColorIndicator(getResources().getColor(R.color.white))
                .setCompletedPosition(0)
                .drawView();

        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg", "-responseBody-" + result);
                //Loaddialog.getInstance().dissLoading();
                String mobileAuthFlag = null;
                switch (step_tag) {
                    case 1:
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            mobileAuthFlag = jsonObject.getString("mobileAuthFlag");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if ("1".equals(mobileAuthFlag)) {
                            Toast.makeText(RegisterActivity.this, "该手机号已注册", Toast.LENGTH_SHORT).show();
                        } else {
                            //下一步操作
                            step_tag = 2;
                            stepsView.setCompletedPosition(1).drawView();
                            tvTitle.setText(getResources().getString(R.string.set_passwordcode));
                            //添加动画
                            // registerOneLinear.startAnimation(MyAnimation.getInstance().getHiddenAnimation());
                            registerOneLinear.setVisibility(View.GONE);
                            // registerTwoLinear.startAnimation(MyAnimation.getInstance().getShowAnimation());
                            registerTwoLinear.setVisibility(View.VISIBLE);
                            getRemoteSendCode();
                        }
                        break;
                    case 2:
                        //收到验证码的处理
                        if(!isTime){
                            initTwo();
                        }
                        initTime();
                        MyLogUtil.i("msg", "-验证码-responseBody-2-" + result);
                        //解析验证码
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            code = jsonObject.getString("verificationCode");
                           // Toast.makeText(RegisterActivity.this, "验证码：" + code, Toast.LENGTH_LONG).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 3:
                        //注册
                        MyLogUtil.i("msg", "-注册返回结果-" + result);
                        Gson gson=new Gson();
                        try {
                            JSONObject jsonObject=new JSONObject(result);
                            UserInfo userInfo=gson.fromJson(jsonObject.getString("userInfo"),UserInfo.class);
                            Common.userInfo=userInfo;
                            Common.customer_id=userInfo.getCustomerId();
                            MyApp.daoSession.getUserInfoDao().insert(userInfo);
                            SharedPreferencesUtils.setParam(RegisterActivity.this,SharedPreferencesUtils.CUSTOMER_ID,userInfo.getCustomerId());
                            SharedPreferencesUtils.setParam(RegisterActivity.this,SharedPreferencesUtils.CUSTOMER_PASSWORD,confrimPassTxt);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        stepsView.setCompletedPosition(2).drawView();
                        tvTitle.setText(getResources().getString(R.string.register_complete));
                        registerTwoLinear.setVisibility(View.GONE);
                        registerThreeLinear.setVisibility(View.VISIBLE);
                        rightTvTitle.setVisibility(View.VISIBLE);
                        showSetPayPassword();
                        break;
                }
            }
        };
    }


    @Override
    protected int getContentViewId() {
        return R.layout.activity_register;
    }


    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @OnClick({R.id.register_btn, R.id.two_send_btn, R.id.right_tv_title})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.register_btn:
                switch (step_tag) {
                    case 1:
                        isMobiles();
                        break;
                    case 2:
                        register();
                        break;
                    case 3:
                        //第三步完成完善资料，跳到填写资料
                        startActivity(new Intent(RegisterActivity.this, BasicInformationActivity.class));
                        finish();
                        break;
                }
                break;
            case R.id.two_send_btn:
                getRemoteSendCode();
                break;
            case R.id.right_tv_title:
                startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                finish();
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
        if (subscriber != null && subscriber.isUnsubscribed()) {
            subscriber.unsubscribe();
        }
    }

    private void isMobiles() {
        phoneTxt = one_phone.getText().toString();
        if (TextUtils.isEmpty(phoneTxt) | !VerifyUtil.VerificationPhone(phoneTxt)) {
            Toast.makeText(RegisterActivity.this, "手机号格式不对", Toast.LENGTH_SHORT).show();
        } else {
            Gson gson = new Gson();
            HashMap<String, Object> map = new HashMap<>();
            HashMap<String, String> map2 = new HashMap<>();
            map2.put("mobile", phoneTxt);
            map.put("orderType", "32");
            map.put("platType", "3");
            map.put("requestObject", map2);
            String mapjson = gson.toJson(map);
            //Log.i("msg","-mapjson-"+mapjson);
            //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
            dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, RegisterActivity.this);
            OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.GetIsMobileAuthUrl + RequestURL.CreatRequestUrl(mapjson));
        }
    }

    private void initTwo() {
        SpannableString spanText = new SpannableString("已发送短信验证码到号码");
        spanText.setSpan(new ForegroundColorSpan(Color.BLUE), 3, 8,
                Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        twoTextTv.setText(spanText);
        twoPhoneTv.setText("" + phoneTxt.substring(0, 3) + "****" + phoneTxt.substring(7, 11));
    }

    private void getRemoteSendCode() {
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("operateType", "2");
        sessionId = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        map2.put("sessionId", sessionId);
        map2.put("customerMobile", phoneTxt);
        map2.put("operateCode", phoneTxt);
        map2.put("functionType", "1");

        map.put("orderType", "32");
        map.put("platType", "3");
        map.put("requestObject", map2);
        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, RegisterActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.GetPolicyQueryCodeUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    private void initTime() {
        final int countTime = 60;
        twoSendBtn.setText("重新发送(" + countTime + ")");
        twoSendBtn.setClickable(false);
        isTime = true;
        subscriber = new Subscriber<Integer>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
            }

            @Override
            public void onNext(Integer integer) {
                if (integer == 0) {
                    //isTime = false;
                    twoSendBtn.setText("重新发送");
                    twoSendBtn.setClickable(true);
                } else {
                    twoSendBtn.setText("重新发送(" + integer + ")");
                }
            }
        };
        Observable.interval(0, 1, TimeUnit.SECONDS)
                .subscribeOn(AndroidSchedulers.mainThread())
                .observeOn(AndroidSchedulers.mainThread())
                .map(new Func1<Long, Integer>() {
                    @Override
                    public Integer call(Long increaseTime) {
                        return countTime - increaseTime.intValue();
                    }
                })
                .take(countTime + 1)
                .subscribe(subscriber);
    }

    private void register() {
        String twoCodeTxt = twoCodeEt.getText().toString();
        String loginPassTxt = twoLoginpassEt.getText().toString();
        confrimPassTxt = twoConfirmpassEt.getText().toString();
        if (!code.equals(twoCodeTxt)) {
            Toast.makeText(RegisterActivity.this, "验证码错误", Toast.LENGTH_SHORT).show();
        } else if (loginPassTxt.length() < 6 | confrimPassTxt.length() < 6) {
            Toast.makeText(RegisterActivity.this, "密码不能少于6位", Toast.LENGTH_SHORT).show();
        } else if (!loginPassTxt.equals(confrimPassTxt)) {
            Toast.makeText(RegisterActivity.this, "两次输入的密码不一样", Toast.LENGTH_SHORT).show();
        } else {
            //发起注册
            step_tag = 3;
            Gson gson = new Gson();
            HashMap<String, Object> map = new HashMap<>();
            HashMap<String, String> map2 = new HashMap<>();
            map2.put("operateType", "2");
            map2.put("sessionId", sessionId);
            map2.put("password", confrimPassTxt);
            map2.put("operateCode", phoneTxt);
            map2.put("verificationCode", twoCodeTxt);
            map2.put("mobile", phoneTxt);

            map.put("orderType", "32");
            map.put("platType", "3");
            map.put("requestObject", map2);
            String mapjson = gson.toJson(map);
            //Log.i("msg","-mapjson-"+mapjson);
            //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
            dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, RegisterActivity.this);
            OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.RegistUrl + RequestURL.CreatRequestUrl(mapjson));
        }
    }


    private void showSetPayPassword(){
        LayoutInflater inflater = RegisterActivity.this.getLayoutInflater();
        View layout = inflater.inflate(R.layout.set_dialgo,
                (ViewGroup) this.findViewById(R.id.setdia_linear));
        final Button cacle_btn = (Button) layout.findViewById(R.id.cacle_btn);
        final Button setpaypass_btn = (Button) layout.findViewById(R.id.setpaypass_btn);
        final MaterialDialog materialDialog=new MaterialDialog.Builder(RegisterActivity.this)
                .title(R.string.safe_title)
                .customView(layout, true)
                .show();
        cacle_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                materialDialog.dismiss();
            }
        });
        setpaypass_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //设置
                materialDialog.dismiss();
                startActivity(new Intent(RegisterActivity.this,SetPayPasswordActivity.class));
            }
        });
    }
}
