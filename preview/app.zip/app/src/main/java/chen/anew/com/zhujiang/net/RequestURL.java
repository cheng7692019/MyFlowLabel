package chen.anew.com.zhujiang.net;

import android.content.Context;
import android.util.Log;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import chen.anew.com.zhujiang.BuildConfig;
import chen.anew.com.zhujiang.utils.Md5Util;


public class RequestURL {

    //uat、预生产、生产环境统一配置
    public static String Host = BuildConfig.Host;
    public static String ESERVICE_9001 = BuildConfig.ESERVICE_9001;
    public static String ESERVICE_7003 = BuildConfig.ESERVICE_7003;
    public static String Key = BuildConfig.Key;

    // 版本号URL
    public static String VersionUrl ="http://www.prlife.com.cn/rcms/app/androidApk/android_version.json";
    // 登录
    public static String LoginUrl = Host + "/mobile/appUser/appUser.action?action=appLogin";
    public static final int Login = 0;

    // 注册
    public static String RegistUrl = Host + "/mobile/appUser/appUser.action?action=appRegister";
    public static final int Regist = 1;

    // 获取手机验证码
    public static String GetPolicyQueryCodeUrl = Host + "/mobile/policyQuery/policyQuery.action?action=getPolicyQueryCode";
    public static final int GetPolicyQueryCode = 2;

    // 手机是否被验证
    public static String GetIsMobileAuthUrl = Host + "/mobile/personalcenter/personalcenter.action?action=getIsMobileAuth";
    public static final int GetIsMobileAuth = 3;

    //修改密码
    public static String changePasswordUrl = Host + "/mobile/user/user.action?action=changePassword";
    public static final int changePassword = 4;

    //验证手机号
    public static String validatePolicyQueryCodeUrl = Host + "/mobile/policyQuery/policyQuery.action?action=validatePolicyQueryCode";
    public static final int validatePolicyQueryCode = 5;

    //账户信息
    public static String initAccountInfoUrl = Host + "/mobile/personalcenter/personalcenter.action?action=initAccountInfo";
    public static final int initAccountInfo = 6;

    //修改用户信息
    public static String editAccountInfoUrl = Host + "/mobile/appUser/appUser.action?action=editAccountInfo";

    //修改用户信息
    // public static String editAccountInfoUrl = Host + "/mobile/personalcenter/personalcenter.action?action=editAccountInfo";
    public static final int editAccountInfo = 7;

    //产品信息
    public static String getProductIntroductionUrl = Host + "/mobile/info/info.action?action=getProductIntroduction";
    public static final int getProductIntroduction = 8;

    //我的保单
    public static String GetPolicyListUrl = Host + "/mobile/manage/manageQuery.action?action=getPolicyList";
    public static final int GetPolicyListInfo = 9;

    //我的资产
    public static String MyAssetsListUrl = Host + "/mobile/asset/asset.action?action=getLinkedConts";

    //保单明细
    public static String GetPolicyInfoUrl = Host + "/mobile/manage/manageQuery.action?action=getPolicyInfo";
    public static final int GetPolicyInfo = 10;

    //我的订单
    public static String GetOrderListUrl = Host + "/mobile/app/appQuery.action?action=getOrderList";
    public static final int GetOrderListInfo = 11;

    //订单明细
    public static String GetOrderInfoUrl = Host + "/mobile/app/appQuery.action?action=getOrderInfo";
    public static final int GetOrderInfo = 12;

    //支付发送手机验证码
    public static String sendVerificationCodeUrl = Host + "/mobile/manage/cont.action?action=sendVerificationCode";
    public static final int sendVerificationCode = 13;


    //忘记密码
    public static String appForgetPasswordUrl = Host + "/mobile/appUser/appUser.action?action=appForgetPassword";
    public static final int appForgetPasswordCode = 14;


    //理财资产
    public static String GetAssetInfoUrl = Host + "/mobile/asset/asset.action?action=getAssetInfo";
    public static final int GetAssetInfo = 15;


    //产品列表
    public static String GetAppWebsiteProductListUrl = Host + "/mobile/appProduct/appProduct.action?action=getAppWebsiteProductList";
    public static final int GetAppWebsiteProductList = 16;


    //退保录入
    public static String GetRefundInfoUrl = Host + "/mobile/manage/cont.action?action=getRefundInfo";
    public static final int GetRefundInfo = 17;


    //退保核算
    public static String GetRefundCalUrl = Host + "/mobile/manage/cont.action?action=getRefundCal";
    public static final int GetRefundCal = 18;


    //退保提交
    public static String ConfirmRefundUrl = Host + "/mobile/manage/cont.action?action=confirmRefund";
    public static final int ConfirmRefund = 19;


    //得到用户银行卡列表
    public static String getBankListByIdUrl = Host + "/mobile/appBank/appBank.action?action=getBankListById";
    public static final int getBankListByIdCode = 20;


    //解除银行卡
    public static String unbindBankToUserUrl = Host + "/mobile/appBank/appBank.action?action=unbindBankToUser";
    public static final int unbindBankToUserCode = 21;

    //app版本列表
    public static String GetCmsVersionListUrl = Host + "/mobile/asset/asset.action?action=getContDayHighchartsData";
    public static final int GetCmsVersionList = 22;

    //支付密码是否存在
    public static String ExistsPayPasswordFlagUrl = Host + "/mobile/appUser/appUser.action?action=existsPayPasswordFlag";
    public static final int ExistsPayPasswordFlagCode = 23;

    //保存支付密码
    public static String SaveAccountSecurityUrl = Host + "/mobile/appAccountSecurity/appAccountSecurity.action?action=saveAccountSecurity";
    public static final int SaveAccountSecurityCode = 24;

    //修改支付密码
    public static String ResetAccountSecurityAlterUrl = Host + "/mobile/appAccountSecurity/appAccountSecurity.action?action=resetAccountSecurity";
    public static final int ResetAccountSecurityAlterCode = 25;

    //忘记支付密码
    public static String ResetAccountSecurityForgetUrl = Host + "/mobile/appAccountSecurity/appAccountSecurity.action?action=resetAccountSecurity";
    public static final int ResetAccountSecurityForgetCode = 26;

    //产品录入
    public static String GetInputInfoUrl = Host + "/mobile/product/inputInfo.action?action=getInputInfo";
    public static final int GetInputInfo = 27;

    //保单价值
    public static String GetContValueByContNoUrl = Host + "/mobile/app/appQuery.action?action=getContValueByContNo";
    public static final int GetContValueByContNoCode = 28;

    //核保校验
    public static String UnderwriteCheckUrl = Host + "/mobile/app/appCont.action?action=underwriteCheck";
    public static final int UnderwriteCheck = 29;

    //支付方式
    public static String GetPaymentListUrl = Host + "/mobile/app/appQuery.action?action=getPaymentList";
    public static final int GetPaymentListCode = 30;

    //承保
    public static String SignPolicyUrl = Host + "/mobile/app/appCont.action?action=signPolicy";
    public static final int SignPolicyCode = 31;

    //验证支付密码
    public static String ValidateAccountSecurityUrl = Host + "/mobile/appAccountSecurity/appAccountSecurity.action?action=validateAccountSecurity";
    public static final int ValidateAccountSecurityCode = 32;

    //回访
    public static String DoRevisitUrl = Host + "/mobile/manage/cont.action?action=doRevisit";
    public static final int DoRevisitCode = 33;

    //支付验证验证码
    public static String CheckVerificationCodeUrl = Host + "/mobile/manage/manageQuery.action?action=getAcceptList";
    public static final int CheckVerificationCodeMark = 34;

    //反馈信息
    public static String feedbackCodeUrl = Host + "/mobile/appFeedback/appFeedback.action?action=saveFeedback";
    public static final int feedbackCodeCodeMark = 35;

    //APP活动列表
    public static String GetAppActivityListUrl = Host + "/mobile/appActivity/appActivity.action?action=getAppActivityList";
    public static final int GetAppActivityListCode = 36;

    /**
     * 生成请求链接
     *
     * @param json
     * @return
     */
    public static String CreatRequestUrl(Context context, String json) {
        String requestUrl = "";
        String encodejson = "";
        String md5 = Key + json;
        md5 = Md5Util.MD5(md5).toLowerCase();
        try {
            encodejson = URLEncoder.encode(json, "utf-8");
        } catch (UnsupportedEncodingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        requestUrl = "&requestMessage=" + encodejson;
        requestUrl = requestUrl + "&sign=" + md5;
        Log.d("json:", json);
        Log.d("encodejson:", encodejson);
        Log.d("toMd5", md5);
        Log.d("sign:", Md5Util.MD5(md5));
        return requestUrl;
    }


    /**
     * 生成请求链接
     *
     * @param json
     * @return
     */
    public static String CreatRequestUrl(String json) {
        String requestUrl = "";
        String encodejson = "";
        String md5 = Key + json;
        md5 = Md5Util.MD5(md5).toLowerCase();
        try {
            encodejson = URLEncoder.encode(json, "utf-8");
        } catch (UnsupportedEncodingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        requestUrl = "&requestMessage=" + encodejson;
        requestUrl = requestUrl + "&sign=" + md5;
        return requestUrl;
    }

}
