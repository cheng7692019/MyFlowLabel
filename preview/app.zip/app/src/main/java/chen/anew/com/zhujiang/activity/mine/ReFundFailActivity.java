package chen.anew.com.zhujiang.activity.mine;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.Toolbar;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.TextView;

import com.afollestad.materialdialogs.AlertDialogWrapper;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;

/**
 * Created by thinkpad on 2016/7/13.
 */

public class ReFundFailActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.contno_msg)
    TextView contnoMsg;
    @Bind(R.id.fail_msg)
    TextView failMsg;

    private String contNo, phone;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.surrender_fail));
        initToolBar();
        contNo = getIntent().getStringExtra("contNo");
        contnoMsg.setText("退保失败，" + contNo);
        failMsg.setText(getString(R.string.fail_msg));
        phone = "4006-933-366";
        SpannableString spanClause = new SpannableString(phone);
        ClickableSpan clickClause = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                // TODO Auto-generated method stub
                new AlertDialogWrapper.Builder(ReFundFailActivity.this)
                        .setTitle(R.string.call_customer)
                        .setMessage(R.string.confirm_customer)
                        .setPositiveButton(R.string.next_confirm, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                if (ActivityCompat.checkSelfPermission(ReFundFailActivity.this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                                    Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + phone));
                                    startActivity(intent);
                                }

                            }
                        });
            }
        };
        spanClause.setSpan(clickClause, 0, phone.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        //不是设点击颜色时需要设前景色
        spanClause.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorAccent)), 0, phone.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        failMsg.append(spanClause);
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_refund_fail;
    }


    @OnClick(R.id.confirm_btn)
    public void onClick() {
        //结束SURRENDERENTRYSTEPONEACTIVITY
        Intent intent = new Intent();
        //设置Intent的Action属性
        intent.setAction("CHEN.COM.SURRENDERENTRYSTEPONEACTIVITY");
        intent.putExtra("is_finish",true);
        //发送广播,改变消息颜色
        sendBroadcast(intent);
        //结束SURRENDERENTRYSTEPTWOACTIVITY
        Intent intent2 = new Intent();
        //设置Intent的Action属性
        intent2.setAction("CHEN.COM.SURRENDERENTRYSTEPTWOACTIVITY");
        intent2.putExtra("is_finish",true);
        //发送广播,改变消息颜色
        sendBroadcast(intent2);
        finish();
    }
}
