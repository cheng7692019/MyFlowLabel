package chen.anew.com.zhujiang.bean;

import java.io.Serializable;

/**
 * Created by thinkpad on 2016/7/11.
 */
public class OrderList implements Serializable {

    private String getStartDateString;

    private String operateDate;

    private String orderNo;

    private String getEndDateString;

    private String prem;

    private String contNo;

    private String realName;

    private String orderStatus;

    private String productName;

    private String invoiceStatus;

    private String isEpolicy;

    private String productType;

    public void setGetStartDateString(String getStartDateString){
        this.getStartDateString = getStartDateString;
    }
    public String getGetStartDateString(){
        return this.getStartDateString;
    }
    public void setOperateDate(String operateDate){
        this.operateDate = operateDate;
    }
    public String getOperateDate(){
        return this.operateDate;
    }
    public void setOrderNo(String orderNo){
        this.orderNo = orderNo;
    }
    public String getOrderNo(){
        return this.orderNo;
    }
    public void setGetEndDateString(String getEndDateString){
        this.getEndDateString = getEndDateString;
    }
    public String getGetEndDateString(){
        return this.getEndDateString;
    }
    public void setPrem(String prem){
        this.prem = prem;
    }
    public String getPrem(){
        return this.prem;
    }
    public void setContNo(String contNo){
        this.contNo = contNo;
    }
    public String getContNo(){
        return this.contNo;
    }
    public void setRealName(String realName){
        this.realName = realName;
    }
    public String getRealName(){
        return this.realName;
    }
    public void setOrderStatus(String orderStatus){
        this.orderStatus = orderStatus;
    }
    public String getOrderStatus(){
        return this.orderStatus;
    }
    public void setProductName(String productName){
        this.productName = productName;
    }
    public String getProductName(){
        return this.productName;
    }
    public void setInvoiceStatus(String invoiceStatus){
        this.invoiceStatus = invoiceStatus;
    }
    public String getInvoiceStatus(){
        return this.invoiceStatus;
    }
    public void setIsEpolicy(String isEpolicy){
        this.isEpolicy = isEpolicy;
    }
    public String getIsEpolicy(){
        return this.isEpolicy;
    }
    public void setProductType(String productType){
        this.productType = productType;
    }
    public String getProductType(){
        return this.productType;
    }

}
