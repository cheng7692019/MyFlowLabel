package chen.anew.com.zhujiang.bean;

import java.io.Serializable;

/**
 * Created by thinkpad on 2016/7/25.
 */
public class ShareList implements Serializable {

    private String imgUrl;

    private String shareDesc;

    private String title;

    private String dataUrl;

    private String type;

    public void setImgUrl(String imgUrl){
        this.imgUrl = imgUrl;
    }
    public String getImgUrl(){
        return this.imgUrl;
    }
    public void setShareDesc(String shareDesc){
        this.shareDesc = shareDesc;
    }
    public String getShareDesc(){
        return this.shareDesc;
    }
    public void setTitle(String title){
        this.title = title;
    }
    public String getTitle(){
        return this.title;
    }
    public void setDataUrl(String dataUrl){
        this.dataUrl = dataUrl;
    }
    public String getDataUrl(){
        return this.dataUrl;
    }
    public void setType(String type){
        this.type = type;
    }
    public String getType(){
        return this.type;
    }

}
