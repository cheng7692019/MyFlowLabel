package chen.anew.com.zhujiang.pullrefresh.support.impl;

import android.view.View;

/**
 * Created by Ybao on 16/7/24.
 */
public interface OnScrollListener {
    void onScrollChanged(View scrollView, int x, int y, int oldx, int oldy);
}
