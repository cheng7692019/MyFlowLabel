package chen.anew.com.zhujiang.activity;

import android.os.Handler;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.joanzapata.pdfview.PDFView;
import com.joanzapata.pdfview.listener.OnPageChangeListener;


import java.io.File;

import butterknife.Bind;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.web.JavaScriptObject;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.net.DownloadFile;
import chen.anew.com.zhujiang.net.DownloadFileUrlConnectionImpl;
import chen.anew.com.zhujiang.widget.Loaddialog;


/**
 * Created by thinkpad on 2016/7/7.
 */
public class PDFViewPagerActivity extends BaseAppActivity implements DownloadFile.Listener,OnPageChangeListener {
    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.pdfView)
    PDFView pdfView;
    DownloadFile downloadFile;
    Integer pageNumber = 1;
    private String pdfName,title;

    public JavaScriptObject jso;


    @Override
    protected void initViews() {
        String pdfurl = getIntent().getStringExtra("pdfurl");
        title = getIntent().getStringExtra("title");
        jso = new JavaScriptObject(this);
        initToolBar();
        tvTitle.setText(title);
        pdfName=pdfurl.substring(pdfurl.lastIndexOf("/")+1);
        downloadFile = new DownloadFileUrlConnectionImpl(PDFViewPagerActivity.this, new Handler(), this);
        Loaddialog.getInstance().initLoding(PDFViewPagerActivity.this);
        downloadFile.download(pdfurl, new File(getExternalFilesDir("pdf"), pdfName).getAbsolutePath());
    }

    @Override
    public void onSuccess(String url, String destinationPath) {
        Loaddialog.getInstance().dissLoading();
        pdfView.fromFile(new File(destinationPath))
                //.pages(0, 2, 1, 3, 3, 3) //all pages are displayed by default
                .enableDoubletap(true)
                .swipeVertical(true)
                .defaultPage(pageNumber)
                .showMinimap(false)
                .onPageChange(this)
                .load();
    }

    @Override
    public void onFailure(Exception e) {
        Loaddialog.getInstance().dissLoading();
    }

    @Override
    public void onProgressUpdate(int progress, int total) {

    }

    @Override
    public void onPageChanged(int page, int pageCount) {
        pageNumber = page;
        tvTitle.setText(String.format("%s %s  / %s", title, page, pageCount));
        //setTitle(String.format("%s %s / %s", pdfName, page, pageCount));
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_pdfview;
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
