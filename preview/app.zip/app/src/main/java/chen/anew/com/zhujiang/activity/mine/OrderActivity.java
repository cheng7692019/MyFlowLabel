package chen.anew.com.zhujiang.activity.mine;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.umeng.analytics.MobclickAgent;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.main.MainActivity;
import chen.anew.com.zhujiang.adpter.FragmentAdapter;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.utils.MobclickAgentUtil;

/**
 * Created by thinkpad on 2016/7/10.
 */

public class OrderActivity extends BaseAppActivity {
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.tabs)
    TabLayout tabs;
    @Bind(R.id.viewpager)
    ViewPager viewpager;

    @Bind(R.id.tv_title)
    TextView tvTitle;

    private List<String> titles;
    private List<Fragment> fragments;
    private boolean buy_success;

    @Override
    protected void initViews() {
        initToolBar();
        tvTitle.setText(getString(R.string.my_order));
        //关闭activity DurationTrack
        MobclickAgentUtil.closeActivityDurationTrack(this);
        titles = new ArrayList<>();
        fragments = new ArrayList<>();
        titles.add(getString(R.string.order_all));
        titles.add(getString(R.string.order_into_effect));
        titles.add(getString(R.string.order_paid));
        titles.add(getString(R.string.order_colse));
        buy_success=getIntent().getBooleanExtra("buy_success",false);
        for (int i = 0; i < titles.size(); i++) {
            tabs.addTab(tabs.newTab().setText(titles.get(i)));
        }
        //ContStatus：不写=全部，00=订单成交，01=等待付款，02=已关闭；
        Bundle bundle=new Bundle();
        bundle.putString("orderStatus","");
        fragments.add(OrderFragment.newInstance(bundle));
        Bundle bundle2=new Bundle();
        bundle2.putString("orderStatus","00");
        fragments.add(OrderFragment.newInstance(bundle2));
        Bundle bundle3=new Bundle();
        bundle3.putString("orderStatus","01");
        fragments.add(OrderFragment.newInstance(bundle3));
        Bundle bundle4=new Bundle();
        bundle4.putString("orderStatus","02");
        fragments.add(OrderFragment.newInstance(bundle4));
        FragmentAdapter mFragmentAdapteradapter =
                new FragmentAdapter(getSupportFragmentManager(), fragments, titles);
        //给ViewPager设置适配器
        viewpager.setAdapter(mFragmentAdapteradapter);
        //将TabLayout和ViewPager关联起来。
        tabs.setupWithViewPager(viewpager);
        //给TabLayout设置适配器
        tabs.setTabsFromPagerAdapter(mFragmentAdapteradapter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        MobclickAgent.onPause(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        MobclickAgent.onResume(this);
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(buy_success){
                    MainActivity.is_mine=true;
                    finish();
                }else{
                    finish();
                }
            }
        });
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_order;
    }

}
