package chen.anew.com.zhujiang.activity.mine.about;

import android.support.v7.widget.Toolbar;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;

import butterknife.Bind;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;

/**
 * Created by thinkpad on 2016/7/22.
 */
public class AboutPearlRiverLifeActivity extends BaseAppActivity {
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.about_webView)
    WebView aboutWebView;

    private final String aboutUrl="http://waptest.prlife.com.cn:9001/rcms/app/appweb/index.html?plat=1#aboutus/aboutus";

    @Override
    protected void initViews() {
        initToolBar();
        WebSettings setting = aboutWebView.getSettings();
        setting.setJavaScriptEnabled(true);//支持js
        setting.setDefaultTextEncodingName("utf-8");//设置字符编码
        setting.setAllowFileAccess(true);
        setting.setBuiltInZoomControls(false);
        aboutWebView.loadUrl(aboutUrl);
    }


    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_life_about;
    }

}
