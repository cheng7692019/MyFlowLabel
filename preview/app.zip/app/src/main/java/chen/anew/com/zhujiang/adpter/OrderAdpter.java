package chen.anew.com.zhujiang.adpter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.bean.OrderList;
import chen.anew.com.zhujiang.utils.VerifyUtil;

/**
 * Created by thinkpad on 2016/6/30.
 */
public class OrderAdpter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public ArrayList<OrderList> datas = null;

    public Context context;

    public OrderAdpter(ArrayList<OrderList> datas, Context context) {
        this.context = context;
        this.datas = datas;
    }

    private  ClickListener clickListener;

    public interface ClickListener {
        void onItemClick(int position, View v);
    }

    public void setOnItemClickListener(ClickListener clickListener) {
        this.clickListener = clickListener;
    }


    public void updateView(ArrayList<OrderList> datas) {
        this.datas = datas;
        this.notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_myorder, viewGroup, false);
        return new ViewHolder(view);
    }


    //将数据与界面进行绑定的操作
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {
        OrderList orderList = datas.get(position);
        ViewHolder viewHolder = (ViewHolder) holder;
        // order_number, status_tv, product_type, product_name, premium_tv, insuredname_tv, insurednumber_tv, order_time;
        viewHolder.order_number.setText(orderList.getOrderNo());
        String orderStatus=orderList.getOrderStatus();
        //08是"00":已生效，02是"01":待支付，05是"02":已关闭
        if("08".equals(orderStatus)){
            viewHolder.insuredname_tv.setVisibility(View.VISIBLE);
            viewHolder.insuredname_tv.setText("被保险人  "+orderList.getRealName());
            viewHolder.status_tv.setText("已生效");
            viewHolder.status_tv.setTextColor(0xFFF1B627);//黄色：6位变8位加 0xFF (0x是代表颜色整数的标记，ff是表示透明度，0000FF表示颜色)
        }else if("02".equals(orderStatus)){
            viewHolder.status_tv.setText("立即支付");
            viewHolder.status_tv.setTextColor(0xFFE06473);//红色
        }else {
            viewHolder.status_tv.setTextColor(0xFF797979);//灰色
        }
        String product_type=orderList.getProductType();
        if ("0".equals(product_type)|"2".equals(product_type)|"3".equals(product_type)) {
            viewHolder.product_type.setText("保障");
            viewHolder.product_type.setBackgroundResource(R.color.right_setbtn);
        } else if (product_type.equals("4")|product_type.equals("1")|product_type.equals("6")) {
            viewHolder.product_type.setText("理财");
            viewHolder.product_type.setBackgroundResource(R.color.colorAccent);
        }
        viewHolder.product_name.setText(VerifyUtil.clearStr(orderList.getProductName()));
        viewHolder.premium_tv.setText(orderList.getPrem()+"元");
        String contNo=orderList.getContNo().trim();
        if("".equals(contNo)){
            viewHolder.insurednumber_tv.setText("— —");
        }else{
            viewHolder.insurednumber_tv.setText(orderList.getContNo());
        }
        viewHolder.order_time.setText(orderList.getOperateDate());
        String index = orderList.getOrderStatus();
        int intdex;
        if(index.contains("0")){
            intdex=Integer.parseInt(index.substring(1));
        }else{
            intdex=Integer.parseInt(index);
        }
        switch (intdex) {
            case 1:
                viewHolder.status_tv.setText("待客户确认");
                break;
            case 2:
                viewHolder.status_tv.setText("立即支付");
                break;
            case 3:
                viewHolder.status_tv.setText("待公司确认");
                break;
            case 4:
                viewHolder.status_tv.setText("待上载影像");
                break;
            case 5:
                viewHolder.status_tv.setText("已关闭");
                break;
            case 6:
                viewHolder.status_tv.setText("已撤销");
                break;
            case 7:
                viewHolder.status_tv.setText("公司谢绝");
                break;
            case 8:
                viewHolder.status_tv.setText("已生效");
                break;
            case 9:
                viewHolder.status_tv.setText("已退保");
                break;
            case 10:
                viewHolder.status_tv.setText("待签单");
                break;
            case 11:
                viewHolder.status_tv.setText("待生成电子保单");
                break;
            case 12:
                viewHolder.status_tv.setText("退保审核中");
                break;
            case 13:
                viewHolder.status_tv.setText("待出单");
                break;
            case 14:
                viewHolder.status_tv.setText("支付中");
                break;
            case 16:
                viewHolder.status_tv.setText("待出单");
                break;
            case 17:
                viewHolder.status_tv.setText("预约成功");
                break;
        }



    }


    //获取数据的数量
    @Override
    public int getItemCount() {
        return datas.size();
    }


    //自定义的ViewHolder，持有每个Item的的所有界面元素
    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView order_number, status_tv, product_type, product_name, premium_tv, insuredname_tv, insurednumber_tv, order_time;

        public ViewHolder(View view) {
            super(view);
            view.setOnClickListener(this);
            order_number = (TextView) view.findViewById(R.id.order_number);
            status_tv = (TextView) view.findViewById(R.id.status_tv);
            product_type = (TextView) view.findViewById(R.id.product_type);
            product_name = (TextView) view.findViewById(R.id.product_name);
            premium_tv = (TextView) view.findViewById(R.id.premium_tv);
            insuredname_tv = (TextView) view.findViewById(R.id.insuredname_tv);

            insurednumber_tv = (TextView) view.findViewById(R.id.insurednumber_tv);
            order_time = (TextView) view.findViewById(R.id.order_time);
        }

        @Override
        public void onClick(View view) {
            clickListener.onItemClick(getAdapterPosition(), view);
        }

    }
}

