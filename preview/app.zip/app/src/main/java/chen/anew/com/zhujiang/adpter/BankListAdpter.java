package chen.anew.com.zhujiang.adpter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.bean.PayModeList;

/**
 * Created by thinkpad on 2016/7/8.
 */
public class BankListAdpter extends BaseAdapter {

    private LayoutInflater inflater;
    private List<PayModeList> imgs;
    private Context context;

    public BankListAdpter(Context context, List<PayModeList> imgs) {
        this.inflater = LayoutInflater.from(context);
        this.context = context;
        this.imgs = imgs;
    }

    /**
     * 当ListView数据发生变化时,调用此方法来更新ListView
     *
     * @param imgs
     */
    public void updateListView(List<PayModeList> imgs) {
        this.imgs = imgs;
        notifyDataSetChanged();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.list_enable_bank,
                    parent, false);
            viewHolder = new ViewHolder();
            viewHolder.bank_name = (TextView) convertView
                    .findViewById(R.id.bank_name);
            viewHolder.bank_img = (ImageView) convertView
                    .findViewById(R.id.bank_img);
            viewHolder.bank_code = (TextView) convertView
                    .findViewById(R.id.bank_code);
            viewHolder.single_quota_tv = (TextView) convertView
                    .findViewById(R.id.single_quota_tv);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        PayModeList payModeList = imgs.get(position);
        if (payModeList != null) {
            viewHolder.bank_name.setText(payModeList.getBankName());
            String bankCode = payModeList.getBankCode();
         /*   if(isvis_code){
                payModeList.getAccTypeList().get(0);
                viewHolder.bank_code.setVisibility(View.VISIBLE);
                viewHolder.bank_code.setText();
                viewHolder.single_quota_tv.setVisibility(View.VISIBLE);
                viewHolder.single_quota_tv.setText("单笔限额"+payModeList.getAccTypeList().get(0).getAccLimit()+"元");
            }*/
            int bank = Integer.valueOf(bankCode.substring(1));
            switch (bank) {
                case 100:
                    viewHolder.bank_img.setImageResource(R.mipmap.bank_0100);
                    break;
                case 102:
                    viewHolder.bank_img.setImageResource(R.mipmap.bank_0102);
                    break;
                case 103:
                    viewHolder.bank_img.setImageResource(R.mipmap.bank_0103);
                    break;
                case 104:
                    viewHolder.bank_img.setImageResource(R.mipmap.bank_0104);
                    break;
                case 105:
                    viewHolder.bank_img.setImageResource(R.mipmap.bank_0105);
                    break;
                case 301:
                    viewHolder.bank_img.setImageResource(R.mipmap.bank_0301);
                    break;
                case 302:
                    viewHolder.bank_img.setImageResource(R.mipmap.bank_0302);
                    break;
                case 303:
                    viewHolder.bank_img.setImageResource(R.mipmap.bank_0303);
                    break;
                case 304:
                    viewHolder.bank_img.setImageResource(R.mipmap.bank_0304);
                    break;
                case 305:
                    viewHolder.bank_img.setImageResource(R.mipmap.bank_0305);
                    break;
                case 306:
                    viewHolder.bank_img.setImageResource(R.mipmap.bank_0306);
                    break;
                case 307:
                    viewHolder.bank_img.setImageResource(R.mipmap.bank_0307);
                    break;
                case 308:
                    viewHolder.bank_img.setImageResource(R.mipmap.bank_0308);
                    break;
                case 309:
                    viewHolder.bank_img.setImageResource(R.mipmap.bank_0309);
                    break;
            }
        }
        return convertView;
    }

    static class ViewHolder {
        TextView bank_name,bank_code,single_quota_tv;
        ImageView bank_img;
    }

    @Override
    public long getItemId(int arg0) {
        return arg0;
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return imgs.size();
    }

    @Override
    public Object getItem(int arg0) {
        // TODO Auto-generated method stub
        return imgs.get(arg0);
    }
}

