package chen.anew.com.zhujiang.base;

import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.readystatesoftware.systembartint.SystemBarTintManager;
import com.umeng.analytics.MobclickAgent;

import butterknife.ButterKnife;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.TransitionMode;

/**
 * Created by thinkpad on 2016/6/25.
 */
public abstract class BaseAppActivity extends AppCompatActivity {

    protected abstract void initViews();

    protected abstract int getContentViewId();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition();
        setContentView(getContentViewId());
        setStatusBarColor();
        ButterKnife.bind(this);
        initViews();
    }


    private void overridePendingTransition() {
        TransitionMode mode = getOverridePendingTransitionMode();
        if (mode != null)
            switch (mode) {
                case LEFT:
                    overridePendingTransition(R.anim.left_in, R.anim.left_out);
                    break;
                case RIGHT:
                    overridePendingTransition(R.anim.right_in, R.anim.right_out);
                    break;
                case TOP:
                    overridePendingTransition(R.anim.top_in, R.anim.top_out);
                    break;
                case BOTTOM:
                    overridePendingTransition(R.anim.bottom_in, R.anim.bottom_out);
                    break;
                case SCALE:
                    overridePendingTransition(R.anim.scale_in, R.anim.scale_out);
                    break;
                case FADE:
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                    break;
                default:
                    break;
            }
    }

    private void setStatusBarColor() {
        if (getStatusBarColor() != -1) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                int tintColor = getStatusBarColor();
                SystemBarTintManager mTintManager = new SystemBarTintManager(this);
                if (tintColor != 0) {
                    mTintManager.setStatusBarTintEnabled(true);
                    mTintManager.setTintColor(tintColor);
                } else {
                    mTintManager.setStatusBarTintEnabled(false);
                    mTintManager.setTintDrawable(null);
                }
            }
        }
    }

    protected TransitionMode getOverridePendingTransitionMode() {
        return null;
    }

    protected int getStatusBarColor() {
        return 0;
    }

    @Override
    protected void onResume() {
        super.onResume();
        MobclickAgent.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        MobclickAgent.onPause(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ButterKnife.unbind(this);
    }
}
