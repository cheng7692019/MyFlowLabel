package chen.anew.com.zhujiang.dialog;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.widget.BGAMoocStyleRefreshView;

/**
 * Created by liukun on 16/3/10.
 */
public class DialogHandler extends Handler {

    public static final int SHOW_PROGRESS_DIALOG = 1;
    public static final int DISMISS_PROGRESS_DIALOG = 2;

    private Dialog dialog;

    private Context context;
    private boolean cancelable;
    private DialogCancelListener mProgressCancelListener;

    public DialogHandler(Context context, DialogCancelListener mProgressCancelListener,
                         boolean cancelable) {
        super();
        this.context = context;
        this.mProgressCancelListener = mProgressCancelListener;
        this.cancelable = cancelable;
    }

    private void initDialog(){
        if (dialog == null) {
            dialog = new Dialog(context, R.style.recordbutton_alert_dialog);
            View contentView = LayoutInflater.from(context).inflate(R.layout.dialog_mooc_alert_dialog, null);
            BGAMoocStyleRefreshView moocImage = (BGAMoocStyleRefreshView) contentView.findViewById(R.id.zeffect_recordbutton_dialog_imageview);
            moocImage.setOriginalImage(R.mipmap.refresh_star);
            moocImage.setUltimateColor(R.color.colorPrimary);
            moocImage.startRefreshing();
            dialog.setContentView(contentView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            dialog.setCancelable(cancelable);
            if (cancelable) {
                dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialogInterface) {
                        mProgressCancelListener.onCancelProgress();
                    }
                });
            }
            if (!dialog.isShowing()) {
                dialog.show();
            }
        }
    }

    private void dismissProgressDialog(){
        if (dialog != null) {
            dialog.dismiss();
            dialog = null;
        }
    }

    @Override
    public void handleMessage(Message msg) {
        switch (msg.what) {
            case SHOW_PROGRESS_DIALOG:
                initDialog();
                break;
            case DISMISS_PROGRESS_DIALOG:
                dismissProgressDialog();
                break;
        }
    }

}
