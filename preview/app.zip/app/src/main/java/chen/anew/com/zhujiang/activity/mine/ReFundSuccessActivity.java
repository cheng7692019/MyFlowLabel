package chen.anew.com.zhujiang.activity.mine;

import android.content.Intent;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;

/**
 * Created by thinkpad on 2016/7/13.
 */

public class ReFundSuccessActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.surrender_success));
        initToolBar();
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_refund_success;
    }

    @OnClick(R.id.confirm_btn)
    public void onClick() {
        //结束SURRENDERENTRYSTEPONEACTIVITY
        Intent intent = new Intent();
        //设置Intent的Action属性
        intent.setAction("CHEN.COM.SURRENDERENTRYSTEPONEACTIVITY");
        intent.putExtra("is_finish",true);
        sendBroadcast(intent);
        //结束SURRENDERENTRYSTEPTWOACTIVITY
        Intent intent2 = new Intent();
        intent2.setAction("CHEN.COM.SURRENDERENTRYSTEPTWOACTIVITY");
        intent2.putExtra("is_finish",true);
        sendBroadcast(intent2);
        MyNewPolicyFragment.ispolicySuccess=true;
        MyPolicyActivity.all_refush=true;
        //更新总资产
        Intent intent3 = new Intent();
        //设置Intent的Action属性
        intent3.setAction("CHEN.COM.UPDATEPERSONDATA_MINE");
        intent3.putExtra("refush_assets",true);
        //发送广播,改变消息颜色
        sendBroadcast(intent);
        //保单页面刷新
       // MyPolicyFragment.nomore=true;
        finish();
    }
}
