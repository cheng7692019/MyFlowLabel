package chen.anew.com.zhujiang.activity.mine.persondata;

import android.content.Intent;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.utils.VerifyUtil;

/**
 * Created by thinkpad on 2016/7/15.
 */
public class ModifyNameActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.right_tv_title)
    TextView rightTvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.username_et)
    EditText usernameEt;

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private String realname;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.user_name));
        rightTvTitle.setText(getResources().getString(R.string.complete));
        initToolBar();
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg", "-responseBody-" + result);
                try {
                    JSONObject jsonObject=new JSONObject(result);
                    String updateResult=jsonObject.getString("updateResult");
                    String resultMessage=jsonObject.getString("resultMessage");
                    if ("1".equals(updateResult)) {
                        Toast.makeText(ModifyNameActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                        Common.userInfo.setRealName(realname);
                        MyApp.daoSession.getUserInfoDao().update(Common.userInfo);
                        //创建Intent对象
                        Intent intent = new Intent();
                        //设置Intent的Action属性
                        intent.setAction("CHEN.COM.UPDATEPERSONDATA");
                        intent.putExtra("realname",realname);
                        sendBroadcast(intent);

                        //创建Intent对象
                        Intent intent2 = new Intent();
                        //设置Intent的Action属性
                        intent2.setAction("CHEN.COM.UPDATEPERSONDATA_MINE");
                        intent2.putExtra("realname",realname);
                        //发送广播,改变姓名显示
                        sendBroadcast(intent2);

                        //发送广播,改变邮箱显示
                        ModifyNameActivity.this.finish();
                    } else if ("0".equals(updateResult)) {
                        Toast.makeText(ModifyNameActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_modifyname;
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @OnClick(R.id.right_tv_title)
    public void onClick() {
        realname=usernameEt.getText().toString();
        if(TextUtils.isEmpty(realname)){
            Toast.makeText(ModifyNameActivity.this, "姓名不能为空", Toast.LENGTH_SHORT).show();
        }else if(!VerifyUtil.isChinse(realname)){
            Toast.makeText(ModifyNameActivity.this, "姓名必须为中文", Toast.LENGTH_SHORT).show();
        }else{
            Gson gson = new Gson();
            HashMap<String, Object> map = new HashMap<>();
            HashMap<String, String> map2 = new HashMap<>();
            map2.put("customerId", Common.userInfo.getCustomerId());
            map2.put("realName", realname);
            map.put("orderType", "32");
            map.put("platType", "3");
            map.put("requestObject", map2);
            String mapjson = gson.toJson(map);
            //Log.i("msg","-mapjson-"+mapjson);
            //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
            dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, ModifyNameActivity.this);
            OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.editAccountInfoUrl + RequestURL.CreatRequestUrl(mapjson));
        }
    }
}
