package chen.anew.com.zhujiang.utils;

import android.graphics.Bitmap;
import android.graphics.Matrix;

/**
 * Created by thinkpad on 2016/7/15.
 */

public class ZoomBitmap {

    public static Bitmap zoomImage(Bitmap bgimage, double newWidth,
                                   double newHeight) {
        // ��ȡ���ͼƬ�Ŀ�͸�
        float width = bgimage.getWidth();
        float height = bgimage.getHeight();
        // ��������ͼƬ�õ�matrix����
        Matrix matrix = new Matrix();
        // ������������
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height;
        // ����ͼƬ����
        matrix.postScale(scaleWidth, scaleHeight);
        Bitmap bitmap = Bitmap.createBitmap(bgimage, 0, 0, (int) width,
                (int) height, matrix, true);
        return bitmap;
    }

}
