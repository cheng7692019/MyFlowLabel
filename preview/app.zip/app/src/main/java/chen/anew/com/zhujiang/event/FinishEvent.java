package chen.anew.com.zhujiang.event;

/**
 * Created by SilenceDut on 2015/11/28.
 */
public class FinishEvent {

    protected boolean isFalg;

    public FinishEvent(boolean isFalg) {
        this.isFalg = isFalg;
    }

    public boolean isFalg() {
        return isFalg;
    }

    public void setFalg(boolean falg) {
        isFalg = falg;
    }
}
