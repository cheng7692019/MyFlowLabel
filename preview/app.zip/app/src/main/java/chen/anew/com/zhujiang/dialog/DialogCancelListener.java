package chen.anew.com.zhujiang.dialog;

/**
 * Created by liukun on 16/3/10.
 */
public interface DialogCancelListener {
    void onCancelProgress();
}
