package chen.anew.com.zhujiang.bean;

import java.io.Serializable;

public class RequestBody implements Serializable{

	private String orderType;
	private String platType;
	private Object requestObject;
	
	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
	public String getPlatType() {
		return platType;
	}

	public void setPlatType(String platType) {
		this.platType = platType;
	}
	
	public Object getRequestObject() {
		return requestObject;
	}

	public void setRequestObject(Object requestObject) {
		this.requestObject = requestObject;
	}
	
}
