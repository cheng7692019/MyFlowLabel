package chen.anew.com.zhujiang.bean;

import java.io.Serializable;

/**
 * Created by thinkpad on 2016/7/8.
 */
public class AccTypeList implements Serializable {

    private String accType;

    private String accTypeName;

    private int accLimit;

    public void setAccType(String accType) {
        this.accType = accType;
    }

    public String getAccType() {
        return this.accType;
    }

    public void setAccTypeName(String accTypeName) {
        this.accTypeName = accTypeName;
    }

    public String getAccTypeName() {
        return this.accTypeName;
    }

    public void setAccLimit(int accLimit) {
        this.accLimit = accLimit;
    }

    public int getAccLimit() {
        return this.accLimit;
    }
}
