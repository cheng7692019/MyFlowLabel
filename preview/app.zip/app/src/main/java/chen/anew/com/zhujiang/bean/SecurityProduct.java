package chen.anew.com.zhujiang.bean;

import java.io.Serializable;
import java.util.List;

/**
 * Created by thinkpad on 2016/7/25.
 */
public class SecurityProduct implements Serializable{

//    private List<ItemPropertyList> itemPropertyList;

    private String productSummary;

    private String appntAge;

    private String maxMult;

//    private List<DescriptionList> descriptionList;

    private String articleUrl;

    private String productType;

    private String rate;

    private String costFeePeriod;

    private String itemCode;

//    private List<ItemPropertyMap> itemPropertyMap;

    private String assureRate;

    private String productPicUrl;

    private String productCode;

    private String promptUrl;

    private String isHot;

    private String policyType;

    private String producInfoPicUrl;

    private String validateDesc;

    private String price;

    private String product_desc_url;

    private String salesNumber;

    private String reveal_url;

    private List<ShareList> shareList;

    private String insurePeriod;

    private String descriptionUrl;

    private String productAbstract;

    private String filing_number;

    private String productName;

    private String impart_url;

 /*   public void setItemPropertyList(List<ItemPropertyList> itemPropertyList) {
        this.itemPropertyList = itemPropertyList;
    }

    public List<ItemPropertyList> getItemPropertyList() {
        return this.itemPropertyList;
    }*/

    public void setProductSummary(String productSummary) {
        this.productSummary = productSummary;
    }

    public String getProductSummary() {
        return this.productSummary;
    }

    public void setAppntAge(String appntAge) {
        this.appntAge = appntAge;
    }

    public String getAppntAge() {
        return this.appntAge;
    }

    public void setMaxMult(String maxMult) {
        this.maxMult = maxMult;
    }

    public String getMaxMult() {
        return this.maxMult;
    }

 /*   public void setDescriptionList(List<DescriptionList> descriptionList) {
        this.descriptionList = descriptionList;
    }
    public List<DescriptionList> getDescriptionList() {
        return this.descriptionList;
    }*/

    public void setArticleUrl(String articleUrl) {
        this.articleUrl = articleUrl;
    }

    public String getArticleUrl() {
        return this.articleUrl;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductType() {
        return this.productType;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getRate() {
        return this.rate;
    }

    public void setCostFeePeriod(String costFeePeriod) {
        this.costFeePeriod = costFeePeriod;
    }

    public String getCostFeePeriod() {
        return this.costFeePeriod;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getItemCode() {
        return this.itemCode;
    }

   /* public void setItemPropertyMap(List<ItemPropertyMap> itemPropertyMap) {
        this.itemPropertyMap = itemPropertyMap;
    }

    public List<ItemPropertyMap> getItemPropertyMap() {
        return this.itemPropertyMap;
    }*/

    public void setAssureRate(String assureRate) {
        this.assureRate = assureRate;
    }

    public String getAssureRate() {
        return this.assureRate;
    }

    public void setProductPicUrl(String productPicUrl) {
        this.productPicUrl = productPicUrl;
    }

    public String getProductPicUrl() {
        return this.productPicUrl;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductCode() {
        return this.productCode;
    }

    public void setPromptUrl(String promptUrl) {
        this.promptUrl = promptUrl;
    }

    public String getPromptUrl() {
        return this.promptUrl;
    }

    public void setIsHot(String isHot) {
        this.isHot = isHot;
    }

    public String getIsHot() {
        return this.isHot;
    }

    public void setPolicyType(String policyType) {
        this.policyType = policyType;
    }

    public String getPolicyType() {
        return this.policyType;
    }

    public void setProducInfoPicUrl(String producInfoPicUrl) {
        this.producInfoPicUrl = producInfoPicUrl;
    }

    public String getProducInfoPicUrl() {
        return this.producInfoPicUrl;
    }

    public void setValidateDesc(String validateDesc) {
        this.validateDesc = validateDesc;
    }

    public String getValidateDesc() {
        return this.validateDesc;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPrice() {
        return this.price;
    }

    public void setProduct_desc_url(String product_desc_url) {
        this.product_desc_url = product_desc_url;
    }

    public String getProduct_desc_url() {
        return this.product_desc_url;
    }

    public void setSalesNumber(String salesNumber) {
        this.salesNumber = salesNumber;
    }

    public String getSalesNumber() {
        return this.salesNumber;
    }

    public void setReveal_url(String reveal_url) {
        this.reveal_url = reveal_url;
    }

    public String getReveal_url() {
        return this.reveal_url;
    }

    public void setShareList(List<ShareList> shareList) {
        this.shareList = shareList;
    }

    public List<ShareList> getShareList() {
        return this.shareList;
    }

    public void setInsurePeriod(String insurePeriod) {
        this.insurePeriod = insurePeriod;
    }

    public String getInsurePeriod() {
        return this.insurePeriod;
    }

    public void setDescriptionUrl(String descriptionUrl) {
        this.descriptionUrl = descriptionUrl;
    }

    public String getDescriptionUrl() {
        return this.descriptionUrl;
    }

    public void setProductAbstract(String productAbstract) {
        this.productAbstract = productAbstract;
    }

    public String getProductAbstract() {
        return this.productAbstract;
    }

    public void setFiling_number(String filing_number) {
        this.filing_number = filing_number;
    }

    public String getFiling_number() {
        return this.filing_number;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductName() {
        return this.productName;
    }

    public void setImpart_url(String impart_url) {
        this.impart_url = impart_url;
    }

    public String getImpart_url() {
        return this.impart_url;
    }

}
