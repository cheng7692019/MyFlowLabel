package chen.anew.com.zhujiang.activity.mine.about;

import android.graphics.Color;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.sdk.android.oss.ClientException;
import com.alibaba.sdk.android.oss.OSS;
import com.alibaba.sdk.android.oss.OSSClient;
import com.alibaba.sdk.android.oss.ServiceException;
import com.alibaba.sdk.android.oss.callback.OSSCompletedCallback;
import com.alibaba.sdk.android.oss.callback.OSSProgressCallback;
import com.alibaba.sdk.android.oss.internal.OSSAsyncTask;
import com.alibaba.sdk.android.oss.model.PutObjectRequest;
import com.alibaba.sdk.android.oss.model.PutObjectResult;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.adpter.ChoosePhotoListAdapter;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.event.GlidePauseOnScrollListener;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.OssConfig;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.CommonSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.GlideImageLoader;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.widget.Loaddialog;
import cn.finalteam.galleryfinal.CoreConfig;
import cn.finalteam.galleryfinal.FunctionConfig;
import cn.finalteam.galleryfinal.GalleryFinal;
import cn.finalteam.galleryfinal.PauseOnScrollListener;
import cn.finalteam.galleryfinal.ThemeConfig;
import cn.finalteam.galleryfinal.model.PhotoInfo;

/**
 * Created by thinkpad on 2016/7/22.
 */
public class HelpAndFeedbackActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.right_tv_title)
    TextView rightTvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.helpback_et)
    EditText helpbackEt;
    @Bind(R.id.lv_photo)
    GridView lvPhoto;

    private ChoosePhotoListAdapter choosePhotoListAdapter;
    private FunctionConfig functionConfig;
    private List<PhotoInfo> all_resultList;
    private final int REQUEST_CODE_GALLERY = 1001;
    private PhotoInfo photoInfo;

    private int currentNum = 0;
    private String resultUrl;

    private CommonSubscriber commonSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    @Override
    protected void initViews() {
        rightTvTitle.setText(R.string.complete);
        tvTitle.setText(R.string.feed_back);
        initToolBar();
        initPhoto();
        all_resultList = new ArrayList<>();
        photoInfo = new PhotoInfo();
        photoInfo.setPhotoId(-1);
        all_resultList.add(photoInfo);
        choosePhotoListAdapter = new ChoosePhotoListAdapter(HelpAndFeedbackActivity.this, all_resultList);
        lvPhoto.setAdapter(choosePhotoListAdapter);
        lvPhoto.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                PhotoInfo photoInfo = all_resultList.get(position);
                if (photoInfo.getPhotoId() == -1) {
                    GalleryFinal.openGalleryMuti(REQUEST_CODE_GALLERY, functionConfig, mOnHanlderResultCallback);
                }
            }
        });
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String resultMessage = jsonObject.getString("resultMessage");
                    String resultCode = jsonObject.getString("resultCode");
                    Loaddialog.getInstance().dissLoading();
                    if ("1".equals(resultCode)) {
                        Toast.makeText(HelpAndFeedbackActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                        finish();
                    } else if ("0".equals(resultCode)) {
                        helpbackEt.clearComposingText();
                        all_resultList.clear();
                        choosePhotoListAdapter.updateList(all_resultList);
                        Toast.makeText(HelpAndFeedbackActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
    }

    private void initPhoto() {
        ThemeConfig theme = new ThemeConfig.Builder()
                .setTitleBarBgColor(Color.WHITE)
                .setTitleBarTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorAccent))
                .setTitleBarIconColor(ContextCompat.getColor(getApplicationContext(), R.color.colorAccent))
                .setFabNornalColor(ContextCompat.getColor(getApplicationContext(), R.color.colorAccent))
                .setFabPressedColor(ContextCompat.getColor(getApplicationContext(), R.color.colorAccent))
                .setCheckNornalColor(Color.WHITE)
                .setCheckSelectedColor(ContextCompat.getColor(getApplicationContext(), R.color.colorAccent))
                .build();
        functionConfig = new FunctionConfig.Builder()
                .setEnableEdit(true)
                .setEnableRotate(true)
                .setMutiSelectMaxSize(3)
              /*  .setForceCrop(true)
                .setForceCropEdit(true)*/
                .setEnablePreview(true).build();
        GlideImageLoader imageLoader = new GlideImageLoader();
        PauseOnScrollListener pauseOnScrollListener = new GlidePauseOnScrollListener(false, true);
        CoreConfig coreConfig = new CoreConfig.Builder(HelpAndFeedbackActivity.this, imageLoader, theme)
                .setFunctionConfig(functionConfig)
                .setPauseOnScrollListener(pauseOnScrollListener)
                .setNoAnimcation(true)
                .build();
        GalleryFinal.init(coreConfig);
    }

    private GalleryFinal.OnHanlderResultCallback mOnHanlderResultCallback = new GalleryFinal.OnHanlderResultCallback() {
        @Override
        public void onHanlderSuccess(int reqeustCode, List<PhotoInfo> resultList) {
            if (resultList != null) {
                all_resultList.clear();
                all_resultList.addAll(resultList);
                all_resultList.add(photoInfo);
                choosePhotoListAdapter.updateList(all_resultList);
            }
        }

        @Override
        public void onHanlderFailure(int requestCode, String errorMsg) {
            Toast.makeText(HelpAndFeedbackActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
        }
    };

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_helpfeedback;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(commonSubscriber!=null&&commonSubscriber.isUnsubscribed()){
            commonSubscriber.unsubscribe();
        }
    }

    @OnClick(R.id.right_tv_title)
    public void onClick() {
        String helpback = helpbackEt.getText().toString();
        if (!TextUtils.isEmpty(helpback)) {
            if (all_resultList != null && all_resultList.size() > 1) {
                all_resultList.remove(all_resultList.size()-1);
                Loaddialog.getInstance().initLoding(HelpAndFeedbackActivity.this);
                for (int i = 0; i < all_resultList.size(); i++) {
                    final PhotoInfo photoInfo = all_resultList.get(i);
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Long date = new Date().getTime();
                            OssConfig.driver = "app/android/" + date.toString() + UUID.randomUUID().toString().toString() + OssConfig.bucket + ".jpg";
                            OssConfig.oss = new OSSClient(HelpAndFeedbackActivity.this, OssConfig.endpoint, OssConfig.credentialProvider);
                            asyncPutObjectFromLocalFile(OssConfig.oss, OssConfig.bucket, OssConfig.driver, photoInfo.getPhotoPath());
                        }
                    });
                }
            }else{
                //没有图片的提交
                subMitFeedback(helpback, resultUrl);
            }
        } else {
            Toast.makeText(HelpAndFeedbackActivity.this, "请先填写反馈内容", Toast.LENGTH_SHORT).show();
        }
    }

    // 从本地文件上传，使用非阻塞的异步接口
    public void asyncPutObjectFromLocalFile(OSS oss, String testBucket, String testObject, String uploadFilePath) {
        // 构造上传请求
        PutObjectRequest put = new PutObjectRequest(testBucket, testObject, uploadFilePath);
        // 异步上传时可以设置进度回调
        put.setProgressCallback(new OSSProgressCallback<PutObjectRequest>() {
            @Override
            public void onProgress(PutObjectRequest request, long currentSize, long totalSize) {
                MyLogUtil.i("msg", "currentSize: " + currentSize + " totalSize: " + totalSize);
            }
        });
        OSSAsyncTask task = oss.asyncPutObject(put, new OSSCompletedCallback<PutObjectRequest, PutObjectResult>() {
            @Override
            public void onSuccess(PutObjectRequest request, PutObjectResult result) {
                // 只有设置了servercallback，这个值才有数据
                String serverCallbackReturnJson = result.getServerCallbackReturnBody();
                MyLogUtil.i("msg", "-BucketName-" + request.getBucketName() + "-getObjectKey-" + request.getObjectKey());
                currentNum++;
                String headimgUrl = OssConfig.endpoint + "/" + request.getBucketName() + "/" + request.getObjectKey();
                Message message = new Message();
                message.what = Common.REFRESH_DATA_FINISH;
                message.obj = headimgUrl;
                handler.sendMessage(message);
               /* Log.i("msg", "-headimgUrl-" + headimgUrl);
                Log.i("msg", serverCallbackReturnJson);
                Log.i("msg", "-headimgUrl-" + headimgUrl);*/
            }

            @Override
            public void onFailure(PutObjectRequest request, ClientException clientExcepion, ServiceException serviceException) {
                // 请求异常
                if (clientExcepion != null) {
                    // 本地异常如网络异常等
                    clientExcepion.printStackTrace();
                }
                if (serviceException != null) {
                    // 服务异常
                    MyLogUtil.i("msg", serviceException.getErrorCode());
                    MyLogUtil.i("msg", serviceException.getRequestId());
                    MyLogUtil.i("msg", serviceException.getHostId());
                    MyLogUtil.i("msg", serviceException.getRawMessage());
                }
            }
        });
    }

    private Handler handler = new Handler() {
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case Common.REFRESH_DATA_FINISH:
                    //modifyHead(msg.obj.toString()); #
                    if (currentNum == 1) {
                        resultUrl = msg.obj.toString();
                    } else {
                        resultUrl = resultUrl + "#" + msg.obj.toString();
                    }
                    if (currentNum == all_resultList.size()) {
                        String helpback = helpbackEt.getText().toString();
                        subMitFeedback(helpback, resultUrl);
                    }
                    break;
            }
        }
    };

    private void subMitFeedback(String content, String imgs) {
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();

        map2.put("content", content);
        if(!TextUtils.isEmpty(imgs)){
            map2.put("pic", imgs);
        }

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        commonSubscriber = new CommonSubscriber(subscriberOnNextListener, HelpAndFeedbackActivity.this);
        OkHttpObservable.getInstance().getData(commonSubscriber, RequestURL.feedbackCodeUrl + RequestURL.CreatRequestUrl(mapjson));
    }
}
