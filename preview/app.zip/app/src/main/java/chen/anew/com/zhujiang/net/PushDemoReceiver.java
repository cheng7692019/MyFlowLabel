package chen.anew.com.zhujiang.net;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.google.gson.Gson;
import com.igexin.sdk.PushConsts;

import org.json.JSONException;
import org.json.JSONObject;

import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.greendao.MessageBean;
import chen.anew.com.zhujiang.greendao.MessageBeanDao;
import chen.anew.com.zhujiang.utils.MyLogUtil;

/**
 * Created by thinkpad on 2016/7/27.
 */

public class PushDemoReceiver extends BroadcastReceiver {

    private MessageBeanDao messageBeanDao;

    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getExtras();
        switch (bundle.getInt(PushConsts.CMD_ACTION)) {
            case PushConsts.GET_CLIENTID:
                String cid = bundle.getString("clientid");
                MyLogUtil.i("msg","-cid-"+cid);
                // TODO:处理cid返回
                break;
            case PushConsts.GET_MSG_DATA:
                String taskid = bundle.getString("taskid");
                String messageid = bundle.getString("messageid");
                if (Common.userInfo != null) {
                    messageBeanDao = MyApp.daoSession.getMessageBeanDao();
                    byte[] payload = bundle.getByteArray("payload");
                    if (payload != null) {
                        String data = new String(payload);
                        MyLogUtil.i("msg","-data-"+data);
                        Gson gson = new Gson();
                        try {
                            JSONObject jsonObject = new JSONObject(data);
                            MessageBean messageBean = gson.fromJson(jsonObject.toString(), MessageBean.class);
                            messageBean.setCustomerId(Common.userInfo.getCustomerId());
                            messageBean.setIsRead("N");
                            messageBeanDao.insert(messageBean);
                            sendMessageHintBroadcast(messageBean.getTitle(),context);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }
                break;
        }
    }

    private void sendMessageHintBroadcast(String title,Context context) {
        //创建Intent对象
        Intent intent = new Intent();
        //设置Intent的Action属性
        intent.setAction("CHEN.COM.MESSAGE_HINT_ACTION");
        intent.putExtra("img_red",1);
        intent.putExtra("title",title);
       /* Bundle bundle=new Bundle();
        bundle.putSerializable("messageBean",messageBean);
        intent.putExtras(bundle);*/
        //发送广播
        context.sendBroadcast(intent);

        Intent intent2 = new Intent();
        //设置Intent的Action属性
        intent2.setAction("CHEN.COM.UPDATEPERSONDATA_MINE");
        intent2.putExtra("img_red",1);
        //发送广播
        context.sendBroadcast(intent2);

    }

}
