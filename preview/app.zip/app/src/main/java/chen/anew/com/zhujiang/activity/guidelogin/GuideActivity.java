package chen.anew.com.zhujiang.activity.guidelogin;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.utils.DensityUtil;
import chen.anew.com.zhujiang.utils.SharedPreferencesUtils;
import chen.anew.com.zhujiang.viewpage.CirclePageIndicator;
import chen.anew.com.zhujiang.viewpage.PagerAdapter;


/**
 * Created by liruiyuan on 2015/12/22.
 */
public class GuideActivity extends Activity implements ViewPager.OnPageChangeListener {

    private ViewPager vp;
    private List<View> views;
    private ViewPagerAdapter vpAdapter;
    private View view1, view2, view3;
    private int preIndex = 0;

    private ImageView page_one_text;
    private Animation animationText;
    private PageThreeAnimationListener pageThreeAnimationListener;

    private ImageView page_two_text;
    private Animation animationText2;

    private ImageView page_three_text, page_three_go;
    private Animation animationText3, animationGo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        init();
        boolean first_star= (boolean) SharedPreferencesUtils.getParam(GuideActivity.this, SharedPreferencesUtils.FIRST_STAR, false);
        if(first_star){
            startActivity(new Intent(GuideActivity.this, SplashActivity.class));
            finish();
        }
        initPageOne();
        initPageTwo();
        pageThreeInit();
    }

    public void init() {
        setContentView(R.layout.activity_guide);
        views = new ArrayList<>();
        view1 = LayoutInflater.from(this).inflate(R.layout.layout_guide_one, null);
        view2 = LayoutInflater.from(this).inflate(R.layout.layout_guide_two, null);
        view3 = LayoutInflater.from(this).inflate(R.layout.layout_guide_three, null);

        views.add(view1);
        views.add(view2);
        views.add(view3);

        vpAdapter = new ViewPagerAdapter(views);
        vp = (ViewPager) findViewById(R.id.viewpager);
        vp.setAdapter(vpAdapter);
        vp.addOnPageChangeListener(this);
        CirclePageIndicator indy_guid = (CirclePageIndicator) findViewById(R.id.indy_guid);
        indy_guid.setViewPager(vp);
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    private void initPageOne() {
        page_one_text = (ImageView) view1.findViewById(R.id.page_one_text);
        int[] location = new int[2];
        DensityUtil densityUtil = new DensityUtil(this);
        page_one_text.getLocationOnScreen(location);
        float fromXDelta = location[0];
        float toYDelta = location[1];
        animationText = new TranslateAnimation(fromXDelta, fromXDelta, densityUtil.getScreenHeight(), toYDelta);
        animationText.setDuration(500);
        animationText.setFillAfter(true);
        page_one_text.startAnimation(animationText);

    }

    private void initPageTwo() {
        page_two_text = (ImageView) view2.findViewById(R.id.page_two_text);
        int[] location = new int[2];
        DensityUtil densityUtil = new DensityUtil(this);
        page_two_text.getLocationOnScreen(location);
        float fromXDelta = location[0];
        float toYDelta = location[1];
        animationText2 = new TranslateAnimation(fromXDelta, fromXDelta, densityUtil.getScreenHeight(), toYDelta);
        animationText2.setDuration(500);
        animationText2.setFillAfter(true);
    }

    private void pageThreeInit() {
        pageThreeAnimationListener = new PageThreeAnimationListener();
        page_three_text = (ImageView) view3.findViewById(R.id.page_three_text);
        page_three_go = (ImageView) view3.findViewById(R.id.page_three_go);

        animationGo = AnimationUtils.loadAnimation(this, R.anim.tutorail_alpha_common);
        animationGo.setAnimationListener(pageThreeAnimationListener);

        int[] location = new int[2];
        DensityUtil densityUtil = new DensityUtil(this);
        page_three_text.getLocationOnScreen(location);
        float fromXDelta = location[0];
        float toYDelta = location[1];
        animationText3 = new TranslateAnimation(fromXDelta, fromXDelta, densityUtil.getScreenHeight(), toYDelta);
        animationText3.setDuration(500);
        animationText3.setFillAfter(true);
        animationText3.setAnimationListener(pageThreeAnimationListener);
        page_three_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferencesUtils.setParam(GuideActivity.this,SharedPreferencesUtils.FIRST_STAR, true);
                startActivity(new Intent(GuideActivity.this, SplashActivity.class));
                finish();
            }
        });
    }


    private class PageThreeAnimationListener implements Animation.AnimationListener {

        @Override
        public void onAnimationStart(Animation animation) {
        }

        @Override
        public void onAnimationEnd(Animation animation) {
            if (animation == animationText3) {
                page_three_text.setVisibility(View.VISIBLE);
                page_three_go.startAnimation(animationGo);
            } else if (animation == animationGo) {
                page_three_go.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public void onAnimationRepeat(Animation animation) {
        }
    }

    private void pageOneStart() {
        page_one_text.startAnimation(animationText);
    }

    private void pageOneStop() {
        page_one_text.setVisibility(View.INVISIBLE);
    }

    private void pageOneDestroy() {
        animationText.cancel();
    }

    private void pageTwoStart() {
        page_two_text.setVisibility(View.INVISIBLE);
        page_two_text.startAnimation(animationText2);
    }

    private void pageThreeStart() {
        page_three_text.setVisibility(View.INVISIBLE);
        page_three_go.setVisibility(View.INVISIBLE);
        page_three_text.startAnimation(animationText3);
    }

    private class ViewPagerAdapter extends PagerAdapter {

        private List<View> views;

        public ViewPagerAdapter(List<View> views) {
            this.views = views;
        }

        @Override
        public void destroyItem(ViewGroup viewGroup, int arg1, Object arg2) {
            viewGroup.removeView(views.get(arg1));
        }

        @Override
        public int getCount() {
            if (views != null) {
                return views.size();
            }
            return 0;
        }

        @Override
        public Object instantiateItem(ViewGroup viewGroup, int arg1) {
            viewGroup.addView(views.get(arg1), 0);
            return views.get(arg1);
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return (arg0 == arg1);
        }
    }

    @Override
    public void onPageScrollStateChanged(int arg0) {

    }

    @Override
    public void onPageScrolled(int arg0, float arg1, int arg2) {

    }

    @Override
    public void onPageSelected(int page) {
        switch (page) {
            case 0:
                pageOneStart();
                break;
            case 1:
                if (preIndex < page) {
                    pageOneStop();
                }
                pageTwoStart();
                break;
            case 2:
                pageThreeStart();
                break;
        }
        preIndex = page;
    }

    @Override
    protected void onDestroy() {
        if (0 == preIndex) {
            pageOneDestroy();
        }
        super.onDestroy();
    }

}
