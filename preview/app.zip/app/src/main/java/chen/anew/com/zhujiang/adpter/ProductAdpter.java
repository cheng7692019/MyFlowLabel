package chen.anew.com.zhujiang.adpter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.greendao.ProductList;

/**
 * Created by thinkpad on 2016/6/30.
 */
public class ProductAdpter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public ArrayList<ProductList> datas = null;

    public Context context;

    public ProductAdpter(ArrayList<ProductList> datas, Context context) {
        this.context = context;
        this.datas = datas;
    }

    static ClickListener clickListener;

    public interface ClickListener {
        void onItemClick(int position, View v);
    }

    public void setOnItemClickListener(ClickListener clickListener) {
        this.clickListener = clickListener;
    }


    public void updateView(ArrayList<ProductList> datas) {
        this.datas = datas;
        this.notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_financial_products, viewGroup, false);
        return new ViewHolder(view);
    }


    //将数据与界面进行绑定的操作
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {
        ProductList product = datas.get(position);
        ViewHolder viewHolder = (ViewHolder) holder;
//        insurance_name_tv, history_rate_tv, startamount_tv,mixinterestrates_tv,refundfee_tv;
        viewHolder.insurance_name_tv.setText(product.getProductName());
        viewHolder.history_rate_tv.setText(product.getHistoryRate());
        viewHolder.startamount_tv.setText(product.getPrice());
        viewHolder.mixinterestrates_tv.setText(product.getAssureRate());
        viewHolder.refundfee_tv.setText(product.getCostFeePeriod());

        String status = product.getStatus();
        //02已发布,05已下架，06已售完,07代售
        int intstatus = Integer.parseInt(status.substring(1));
        String isHot = product.getIsHot();
        switch (intstatus) {
            case 2:
                if ("1".equals(isHot)) {
                    viewHolder.insuretype_logo_iv.setImageResource(R.mipmap.home_table_recommend);
                }else{
                    viewHolder.insuretype_logo_iv.setImageResource(0);
                }
                break;
            case 5:
                viewHolder.insuretype_logo_iv.setImageResource(R.mipmap.unshelve);
                break;
            case 6:
                viewHolder.insuretype_logo_iv.setImageResource(R.mipmap.sold_out);
                break;
            case 7:
                viewHolder.insuretype_logo_iv.setImageResource(R.mipmap.for_sale);
                break;
            default:
                break;
        }
    }


    //获取数据的数量
    @Override
    public int getItemCount() {
        return datas.size();
    }


    //自定义的ViewHolder，持有每个Item的的所有界面元素
    static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView insurance_name_tv, history_rate_tv, startamount_tv, mixinterestrates_tv, refundfee_tv;
        public ImageView insuretype_logo_iv;

        public ViewHolder(View view) {
            super(view);
            view.setOnClickListener(this);
            insurance_name_tv = (TextView) view.findViewById(R.id.insurance_name_tv);
            history_rate_tv = (TextView) view.findViewById(R.id.history_rate_tv);
            startamount_tv = (TextView) view.findViewById(R.id.startamount_tv);
            mixinterestrates_tv = (TextView) view.findViewById(R.id.mixinterestrates_tv);
            refundfee_tv = (TextView) view.findViewById(R.id.refundfee_tv);
            insuretype_logo_iv = (ImageView) view.findViewById(R.id.insuretype_logo_iv);
        }

        @Override
        public void onClick(View view) {
            clickListener.onItemClick(getAdapterPosition(), view);
        }

    }
}

