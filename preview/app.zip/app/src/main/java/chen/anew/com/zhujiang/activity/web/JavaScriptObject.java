package chen.anew.com.zhujiang.activity.web;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import com.umeng.analytics.MobclickAgent;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import chen.anew.com.zhujiang.activity.PDFViewPagerActivity;
import chen.anew.com.zhujiang.activity.guidelogin.LoginActivity;
import chen.anew.com.zhujiang.activity.guidelogin.RegisterActivity;
import chen.anew.com.zhujiang.activity.mine.persondata.MyPersonalData;
import chen.anew.com.zhujiang.activity.product.BuyStepOneProductActivity;
import chen.anew.com.zhujiang.activity.product.SecurityDetailsActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.utils.MyLogUtil;


/**
 * Web调用本地代码
 *
 * @author Administrator
 */

public class JavaScriptObject {

    private Context context;
    public String itemCode;
    public String status;

    public JavaScriptObject(Context context) {
        this.context = context;
    }

    /**
     * 显示Toast
     *
     * @param content
     */
    @JavascriptInterface
    public void showToast(String content) {
        Toast.makeText(context, content, Toast.LENGTH_SHORT).show();
    }

    @JavascriptInterface
    public void showToast_loading() {
        //Loaddialog.getInstance().initLoding(context);
    }

    @JavascriptInterface
    public void hideLoading() {
        //Loaddialog.getInstance().dissLoading();
    }

    /**
     * 跳转到网页加载页
     *
     * @param
     */
    @JavascriptInterface
    public void toWebActivity(String title, String url) {
        Intent i = new Intent(context, WebViewActivity.class);
        i.putExtra("title", title);
        i.putExtra("url", url);
        context.startActivity(i);
    }

    @JavascriptInterface
    public void toFunctionActivity(String title, String url, String explain) {
        Intent i = new Intent(context, WebViewActivity.class);
        i.putExtra("title", title);
        i.putExtra("url", url);
        i.putExtra("explain", explain);
        context.startActivity(i);
    }

    @JavascriptInterface
    public void toProductDetailAccidentActivity(String itemCode, String status) {
        if(WebMatchViewFragment.flag){
            Intent i = new Intent(context, SecurityDetailsActivity.class);
            i.putExtra("itemCode", itemCode);
            i.putExtra("status", status);
            //友盟统计购买
            HashMap<String, String> you_map = new HashMap<>();
            you_map.put("product_type", itemCode);
            you_map.put("mobile", Common.userInfo.getMobile());
            you_map.put("status", status);
            MobclickAgent.onEvent(context, "purchase_01", you_map);

            context.startActivity(i);
        }
    }

    @JavascriptInterface
    public void toEnterInfoActivity() {
        Intent i = new Intent(context, BuyStepOneProductActivity.class);
        context.startActivity(i);
    }


    @JavascriptInterface
    public void toEnterInfoActivity(String productName,
                                    String productCode,
                                    String totalmoney, String days, String begindate,
                                    String articleUrl, String descriptionUrl, String promptUrl) {
        //prdouctName=产品名称，productCode=产品编号，totalmoney=总价格，days=客户选择的保险周期，begindate=生效日期
        // Intent i = new Intent(context, EnterInfoActivity.class);
        Intent i = new Intent(context, BuyStepOneProductActivity.class);
        String endDate = null;
        if (TextUtils.isEmpty(Common.customer_id)) {
            context.startActivity(new Intent(context,
                    LoginActivity.class));
            Toast.makeText(context, "请先登录", Toast.LENGTH_SHORT).show();
        } else {
            i.putExtra("itemCode", itemCode);
            i.putExtra("productName", productName);
            i.putExtra("productCode", productCode);
            i.putExtra("totalmoney", totalmoney);
            i.putExtra("days", days);
            i.putExtra("startDate", begindate);

            String dateArray[] = begindate.split("-");
            String year = dateArray[0];
            String month = dateArray[1];
            String day = dateArray[2];
            String amount = days.substring(0, days.length() - 1);                    //截取最后一个字符前的所有字符
            String dateUnit = days.substring(days.length() - 1, days.length());    //截取最后一个字符

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date date = null;
            try {
                date = sdf.parse(begindate);                //将date转String
            } catch (ParseException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            if (dateUnit.equals("天")) {
                calendar.add(Calendar.DATE, Integer.valueOf(amount));        //date加天数
                date = calendar.getTime();
                endDate = sdf.format(date);            //将String转date

            } else if (dateUnit.equals("月")) {
                calendar.add(Calendar.MONTH, Integer.valueOf(amount));        //date加天数
                date = calendar.getTime();
                endDate = sdf.format(date);            //将String转date

            } else if (dateUnit.equals("年")) {
                calendar.add(Calendar.YEAR, Integer.valueOf(amount));        //date加天数
                date = calendar.getTime();
                endDate = sdf.format(date);            //将String转date
            }
            i.putExtra("endDate", endDate);

            //友盟统计购买
            HashMap<String, String> you_map = new HashMap<>();
            you_map.put("product_type", itemCode);
            you_map.put("mobile", Common.userInfo.getMobile());
            you_map.put("days", days);
            you_map.put("startDate", begindate);
            you_map.put("endDate", endDate);
            MobclickAgent.onEvent(context, "purchase_02", you_map);

            context.startActivity(i);
        }
    }

    //    showUrl
    @JavascriptInterface
    public void showUrl(String title,String pdfurl) {
        Intent intent = new Intent(context, PDFViewPagerActivity.class);
        intent.putExtra("pdfurl", pdfurl);
        MyLogUtil.i("msg","-pdfurl-"+pdfurl);
        intent.putExtra("title", title);
        context.startActivity(intent);
    }

    //原生传数据到网页
    @JavascriptInterface
    public String productInfoToHtml() {
        JSONObject map;
        JSONArray array = new JSONArray();
        try {
            map = new JSONObject();
            map.put("itemCode", itemCode);
            map.put("status", status);
            array.put(map);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        String string = array.toString();
        return array.toString();
    }

    //判断用户是否登入
    public void is_accout() {
        if (TextUtils.isEmpty(Common.customer_id)) {
            context.startActivity(new Intent(context,
                    LoginActivity.class));
            Toast.makeText(context, "请先登录", Toast.LENGTH_SHORT).show();
        } else {
            Intent intent = new Intent(context, BuyStepOneProductActivity.class);
            intent.putExtra("itemCode", itemCode);
            intent.putExtra("sum", 2);                                            //FragmentVertical1.number.getText().toString()
            intent.putExtra("productName", "我的");
//            intent.putExtra("insurePeriod", ProductDetailActivity.insurePeriod);
//            intent.putExtra("productCode", ProductDetailActivity.productCode);

            intent.putExtra("startDate", "");
            intent.putExtra("endDate", "");
            context.startActivity(intent);
        }
    }

    /*
     * 活动接口
     */
    //跳到登录页面
    @JavascriptInterface
    public void gotoLogin() {
        Intent i = new Intent(context, LoginActivity.class);
        context.startActivity(i);
    }

    //跳到注册页面
    @JavascriptInterface
    public void gotoRegister() {
        Intent i = new Intent(context, RegisterActivity.class);
        context.startActivity(i);
    }

    //跳转修改信息
    @JavascriptInterface
    public void gotoChangeInfo() {
        Intent intent = new Intent(context, MyPersonalData.class);
        context.startActivity(intent);
    }

    @JavascriptInterface
    public int getLoginState() {
        if (TextUtils.isEmpty(Common.customer_id)) {
            return 0;
        } else {
            return 1;
        }
    }

    //获取用户信息	（顺序 customer_id,name,idNo,mobile,idAuth,mobileAuth,emailAuth)
   /* @JavascriptInterface
    public String[] getUserInfo() {
        String[] userInfos = new String[7];
        userInfos[0] = Common.userInfo.getCustomerId();
        userInfos[1] = Common.userInfo.getName();
        userInfos[2] = Common.userInfo.getIdNo();
        userInfos[3] = Common.userInfo.getMobile();
        userInfos[4] = Common.userInfo.getIdAuth();
        userInfos[5] = Common.userInfo.getMobileAuth();
        userInfos[6] = Common.userInfo.getEmailAuth();
        return userInfos;
    }*/

    @JavascriptInterface
    public String getUserInfo() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("customerId", Common.userInfo.getCustomerId());
            MyLogUtil.i("msg", "-getCustomerId-" + Common.userInfo.getCustomerId());
            jsonObject.put("name", Common.userInfo.getName());
            jsonObject.put("idNo", Common.userInfo.getIdNo());
            jsonObject.put("mobile", Common.userInfo.getMobile());
            jsonObject.put("idAuth", Common.userInfo.getIdAuth());
            jsonObject.put("mobileAuth", Common.userInfo.getMobileAuth());
            jsonObject.put("emailAuth", Common.userInfo.getEmailAuth());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        MyLogUtil.i("msg", "-jsonObject-" + jsonObject.toString());
        return jsonObject.toString();
        //return Common.userInfo.getCustomerId();
    }

}
