package chen.anew.com.zhujiang.activity.mine;

import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.CommonSubscriber;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.utils.VerifyUtil;

/**
 * Created by thinkpad on 2016/7/11.
 */
public class PolicyItemActivity extends BaseAppActivity {
    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.buyproductname_tv)
    TextView buyproductnameTv;
    @Bind(R.id.policyholder_relative)
    RelativeLayout policyholderRelative;
    @Bind(R.id.policynum_tv)
    TextView policynumTv;
    @Bind(R.id.policyusername_tv)
    TextView policyusernameTv;
    @Bind(R.id.policysexname_tv)
    TextView policysexnameTv;
    @Bind(R.id.documentype_tv)
    TextView documentypeTv;
    @Bind(R.id.identificationnumber_tv)
    TextView identificationnumberTv;
    @Bind(R.id.phonecode_tv)
    TextView phonecodeTv;
    @Bind(R.id.emailcode_tv)
    TextView emailcodeTv;
    @Bind(R.id.effectivedate_tv)
    TextView effectivedateTv;
    @Bind(R.id.provicecity_tv)
    TextView provicecityTv;
    @Bind(R.id.areadetailaddress_tv)
    TextView areadetailaddressTv;
    @Bind(R.id.policyitem_relative)
    RelativeLayout policyitemRelative;
    @Bind(R.id.policyname_tv)
    TextView policynameTv;
    @Bind(R.id.guaranteeperiodduration_tv)
    TextView guaranteeperioddurationTv;
    @Bind(R.id.payment_tv)
    TextView paymentTv;
    @Bind(R.id.premiums_tv)
    TextView premiumsTv;
    @Bind(R.id.universalinfo_relative)
    RelativeLayout universalinfoRelative;
    @Bind(R.id.premium_tv)
    TextView premiumTv;

    @Bind(R.id.rotateone_img)
    ImageView rotateoneImg;
    @Bind(R.id.rotatetwo_img)
    ImageView rotatetwoImg;
    @Bind(R.id.rotatethree_img)
    ImageView rotateonethreeImg;

    @Bind(R.id.policyholdergone_linear)
    LinearLayout policyholdergoneLinear;
    @Bind(R.id.policyitemtwogone_linear)
    LinearLayout policyitemtwogoneLinear;
    @Bind(R.id.universalinfogone_linear)
    LinearLayout universalinfogoneLinear;

    @Bind(R.id.universal_cardview)
    CardView universal_cardview;


    private String contNo, riskName, name, sexname, iDType, iDNo, insuredMobile, email, provinceLable, cityLable, address, contEndDate, cValiDate, payYears, prem;

    private DialogSubscriber dialogSubscriber;
    private CommonSubscriber commonSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private boolean isPolicyValue = false;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.policy_item));
        initToolBar();
        contNo = getIntent().getStringExtra("contNo");
        String contStatus= getIntent().getStringExtra("contStatus");
        if("2".equals(contStatus)|"5".equals(contStatus)){
            universal_cardview.setVisibility(View.GONE);
        }
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                //Loaddialog.getInstance().dissLoading();
                MyLogUtil.i("msg", "-result-" + result);
                if (isPolicyValue) {
                    try {
                        JSONObject jsonObject=new JSONObject(result);
                        String resultCode=jsonObject.getString("resultCode");
                        if("1".equals(resultCode)){
                            premiumTv.setText(jsonObject.getString("contValue"));
                        }else{
                            premiumTv.setText("0.00");
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    isPolicyValue=false;
                } else {
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        JSONObject contInfojo = (JSONObject) jsonObject.get("contInfo");
                        //Log.i("json","-insureds-"+contInfojo.getJSONArray("insureds").toString());
                        JSONArray insuredsArray = new JSONArray(contInfojo.getJSONArray("insureds").toString());
                        JSONObject insuredsjo = (JSONObject) insuredsArray.get(0);
                        JSONArray risksArray = new JSONArray(insuredsjo.getJSONArray("risks").toString());
                        JSONObject risksjo = (JSONObject) risksArray.get(0);
                        riskName = risksjo.getString("riskName");
                        //设险种名称
                        buyproductnameTv.setText(riskName);
                        //String orderNo = contInfojo.get("orderNo").toString();
                        //设置订单号
                        policynumTv.setText(contNo);
                        name = insuredsjo.get("name").toString();
                        //设置姓名
                        policyusernameTv.setText(name);
                        //设置性别
                        sexname = insuredsjo.get("sex").toString();
                        policysexnameTv.setText(sexname);
                        iDType = insuredsjo.get("iDType").toString();
                       /* String iDTyepStr=iDType;
                        if (iDType.equals("0")) {
                            iDTyepStr = "身份证";
                        } else if (iDType.equals("1")){
                            iDTyepStr = "证件";
                        }*/
                        //设置证件类型
                        documentypeTv.setText(iDType);
                        iDNo = insuredsjo.get("iDNo").toString();
                        //设置证件号
                        identificationnumberTv.setText(encryptIdNo(iDNo));

                        JSONObject appntInfo = (JSONObject) contInfojo.get("appntInfo");
                        email = appntInfo.get("email").toString();
                        //设置邮箱
                        emailcodeTv.setText(email);
                        insuredMobile = appntInfo.get("appntMobile").toString();
                        //设置手机号
                        phonecodeTv.setText(encryptPhone(insuredMobile));
                        //得到省
                        provinceLable = appntInfo.get("provinceLable").toString();
                        //得到市
                        cityLable = appntInfo.get("cityLable").toString();
                        provicecityTv.setText(provinceLable + cityLable);
                        address = appntInfo.getString("address").toString();
                        //设置详细地址
                        areadetailaddressTv.setText(address);
                        //险种名称riskName
                        policynameTv.setText(VerifyUtil.clearStr(riskName));
                        //保障期间
                        //contEndDate = contInfojo.get("contEndDate").toString();
                        contEndDate = risksjo.get("years").toString();
                        if(VerifyUtil.checkNumber(contEndDate.trim())){
                            guaranteeperioddurationTv.setText("至"+contEndDate+"周岁");
                        }else{
                            guaranteeperioddurationTv.setText(contEndDate);
                        }
                        cValiDate = contInfojo.getString("cValiDate").toString();
                        //交费方式
                        payYears = risksjo.get("payYears").toString();
                        //设置交费方式
                        paymentTv.setText(payYears);
                        //设置生效日期
                        effectivedateTv.setText(cValiDate);
                        prem = contInfojo.getString("prem").toString();
                        //设置保费
                        premiumsTv.setText(prem);
                        getPolicyValue();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        getPolicyItem();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
        if (commonSubscriber != null && commonSubscriber.isUnsubscribed()) {
            commonSubscriber.unsubscribe();
        }
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    //用星号代替手机号码中间字符
    public String encryptPhone(String phone) {
        String encryptionPhone = phone;
        if (!TextUtils.isEmpty(phone) && phone.length() > 7) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < phone.length(); i++) {
                char c = phone.charAt(i);
                if (i >= 3 && i <= 7) {
                    sb.append('*');
                } else {
                    sb.append(c);
                }
            }
            encryptionPhone = sb.toString();
        }
        return encryptionPhone;
    }

    //用星号代替身份证号码中间字符
    public String encryptIdNo(String IdNo) {
        String encryptionIdNo = IdNo;
        if (!TextUtils.isEmpty(IdNo) && IdNo.length() > 14) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < IdNo.length(); i++) {
                char c = IdNo.charAt(i);
                if (i >= 3 && i <= 14) {
                    sb.append('*');
                } else {
                    sb.append(c);
                }
            }
            encryptionIdNo = sb.toString();
        }
        return encryptionIdNo;
    }

    private void getPolicyItem() {
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("contNo", contNo);
        map2.put("customerId", Common.userInfo.getCustomerId());

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, PolicyItemActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.GetPolicyInfoUrl + RequestURL.CreatRequestUrl(mapjson));
    }


    private void getPolicyValue() {
        isPolicyValue = true;
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("contNo", contNo);
        map2.put("customerId", Common.userInfo.getCustomerId());

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        commonSubscriber = new CommonSubscriber(subscriberOnNextListener, PolicyItemActivity.this);
        OkHttpObservable.getInstance().getData(commonSubscriber, RequestURL.GetContValueByContNoUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    @OnClick({R.id.policyholder_relative, R.id.policyitem_relative, R.id.universalinfo_relative})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.policyholder_relative:
                int intoneVisibilit=policyholdergoneLinear.getVisibility();
                if(intoneVisibilit==0){
                    Animation animation= AnimationUtils.loadAnimation(this, R.anim.rotate_in);
                    animation.setFillAfter(true);
                    rotateoneImg.startAnimation(animation);
                    policyholdergoneLinear.setVisibility(View.GONE);
                }else{
                    Animation animation= AnimationUtils.loadAnimation(this, R.anim.rotate_out);
                    animation.setFillAfter(true);
                    rotateoneImg.startAnimation(animation);
                    policyholdergoneLinear.setVisibility(View.VISIBLE);
                }
                break;
            case R.id.policyitem_relative:
                int inttwoVisibilit=policyitemtwogoneLinear.getVisibility();
                if(inttwoVisibilit==0){
                    Animation animation= AnimationUtils.loadAnimation(this, R.anim.rotate_in);
                    animation.setFillAfter(true);
                    rotatetwoImg.startAnimation(animation);
                    policyitemtwogoneLinear.setVisibility(View.GONE);
                }else{
                    Animation animation= AnimationUtils.loadAnimation(this, R.anim.rotate_out);
                    animation.setFillAfter(true);
                    rotatetwoImg.startAnimation(animation);
                    policyitemtwogoneLinear.setVisibility(View.VISIBLE);
                }
                break;
            case R.id.universalinfo_relative:
                int inthreeVisibilit=universalinfogoneLinear.getVisibility();
                if(inthreeVisibilit==0){
                    Animation animation= AnimationUtils.loadAnimation(this, R.anim.rotate_in);
                    animation.setFillAfter(true);
                    rotateonethreeImg.startAnimation(animation);
                    universalinfogoneLinear.setVisibility(View.GONE);
                }else{
                    Animation animation= AnimationUtils.loadAnimation(this, R.anim.rotate_out);
                    animation.setFillAfter(true);
                    rotateonethreeImg.startAnimation(animation);
                    universalinfogoneLinear.setVisibility(View.VISIBLE);
                }
                break;
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_policyritem;
    }

}
