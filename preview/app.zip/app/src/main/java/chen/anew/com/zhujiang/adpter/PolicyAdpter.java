package chen.anew.com.zhujiang.adpter;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.google.gson.Gson;
import com.umeng.analytics.MobclickAgent;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.mine.SurrenderEntryStepOneActivity;
import chen.anew.com.zhujiang.bean.ContList;
import chen.anew.com.zhujiang.bean.SurrenderEntry;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.CommonSubscriber;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.utils.VerifyUtil;

/**
 * Created by thinkpad on 2016/6/30.
 */
public class PolicyAdpter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public ArrayList<ContList> datas = null;
    public Activity activity;
    private CommonSubscriber commonSubscriber;
    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    private HashMap<String, String> contMap = new HashMap<>();

    public PolicyAdpter(ArrayList<ContList> datas, Activity activity) {
        this.activity = activity;
        this.datas = datas;
    }

    private ClickListener clickListener;

    public interface ClickListener {
        void onItemClick(int position, View v);
    }

    public void setOnItemClickListener(ClickListener clickListener) {
        this.clickListener = clickListener;
    }


    public void updateView(ArrayList<ContList> datas) {
        this.datas = datas;
        this.notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_mypolicy, viewGroup, false);
        return new ViewHolder(view);
    }


    //将数据与界面进行绑定的操作
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {
        final ContList contList = datas.get(position);
        final ViewHolder viewHolder = (ViewHolder) holder;
//        product_type, product_name, premium_tv,  policynum_tv,policyvalue_tv,effectivedate_tv;
        String product_type = contList.getProductType();
        if ("2".equals(product_type)) {
            contList.setContStatus("2");
        }
        //0意外险,1万能险,2保单类,3团险,4健康宝,6投连险
        if ("0".equals(product_type) | "2".equals(product_type) | "3".equals(product_type)) {
            viewHolder.product_type.setText("保障");
            viewHolder.product_type.setBackgroundResource(R.color.right_setbtn);
        } else if (product_type.equals("4") | product_type.equals("1") | product_type.equals("6")) {
            viewHolder.product_type.setText("理财");
            viewHolder.product_type.setBackgroundResource(R.color.colorAccent);
        }

        viewHolder.product_name.setText(VerifyUtil.clearStr(contList.getMainRiskName()));
        String contStatus = contList.getContStatus();
        if ("2".equals(contStatus)) {
            //退保完成已终止
            viewHolder.policynum_tv.setVisibility(View.GONE);
            viewHolder.effectivedate_relative.setVisibility(View.GONE);
            viewHolder.yesterday_income_tv.setText(activity.getString(R.string.respective_sums) + " (元)");
            viewHolder.policyvalue_tag.setText(activity.getString(R.string.insured_num));
            viewHolder.premium_tv.setText(contList.getPrem());
        } else {
            viewHolder.policynum_tv.setVisibility(View.VISIBLE);
            viewHolder.effectivedate_relative.setVisibility(View.VISIBLE);
            viewHolder.yesterday_income_tv.setText(activity.getString(R.string.yesterday_income));
            viewHolder.policyvalue_tag.setText(activity.getString(R.string.policy_value));
            viewHolder.premium_tv.setText(contList.getDayTotalAmnt());
        }
        viewHolder.policynum_tv.setText(contList.getContNo());
        viewHolder.effectivedate_tv.setText(contList.getVlidDate());
        //是否允许退保领取,1-允许退保、0-不允许退保、2-允许退保但该渠道不能完成退保操作，提示#后面的文字（如2#请到购买渠道完成该操作)
        String isSurrenderRseceive = contList.getIsSurrenderRseceive();
        if ("0".equals(isSurrenderRseceive) | product_type.equals("6") | product_type.equals("5")) {
            viewHolder.effective_linear.setVisibility(View.GONE);
        } else {
            viewHolder.effective_linear.setVisibility(View.VISIBLE);
        }
        String canRevisit = contList.getCanRevisit();
        if ("1".equals(canRevisit)) {
            viewHolder.returnstate_btn.setBackgroundResource(R.drawable.setdialog_left_change);
            viewHolder.returnstate_btn.setText("在线回访");
            viewHolder.returnstate_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //在线回访对话框
                    showTipKnow(viewHolder.returnstate_btn, contList.getContNo());
                }
            });
        } else if ("0".equals(canRevisit)) {
            viewHolder.returnstate_btn.setBackgroundResource(R.drawable.setgray_btn_background);
            viewHolder.returnstate_btn.setClickable(false);
            viewHolder.returnstate_btn.setText("已回访");
        }
        viewHolder.surrenderstatus_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //点击事件的处理
                String isSurrenderRseceive = contList.getIsSurrenderRseceive();
                /*if ("2".equals(isSurrenderRseceive)) */
                if ("1".equals(isSurrenderRseceive)) {
                    getRefundInfo(contList.getContNo());
                } else {
                    Toast.makeText(activity, "请到购买渠道完成相关操作", Toast.LENGTH_SHORT).show();
                }
            }
        });
        //异步更新保单价值
        final String contNo = contList.getContNo();
        viewHolder.policyvalue_tv.setTag(contNo);
        if ("2".equals(contStatus)) {
            viewHolder.policyvalue_tv.setText(contList.getContNo());
        } else {
            String contValue = contMap.get(contNo);
            if (!TextUtils.isEmpty(contValue)) {
                viewHolder.policyvalue_tv.setText(contValue);
            } else {
                subscriberOnNextListener = new SubscriberOnNextListener<String>() {
                    @Override
                    public void onNext(String result) {
                        MyLogUtil.i("msg", "contValue" + result);
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            String resultCode = jsonObject.getString("resultCode");
                            if ("1".equals(resultCode)) {
                                String contValue = jsonObject.getString("contValue");
                                String contNo = jsonObject.getString("contNo");
                                if(TextUtils.isEmpty(contMap.get(contNo))){
                                    contMap.put(contNo, contValue);
                                    viewHolder.policyvalue_tv.setText(contValue);
                                }
                            }/* else {
                                viewHolder.policyvalue_tv.setText("0.00");
                            }*/
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
            }
            getContValue(contList.getContNo());
        }
    }

    @Override
    public void onViewRecycled(RecyclerView.ViewHolder holder) {
        super.onViewRecycled(holder);
        if (commonSubscriber != null && commonSubscriber.isUnsubscribed()) {
            commonSubscriber.unsubscribe();
        }
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
    }

    //获取数据的数量
    @Override
    public int getItemCount() {
        return datas.size();
    }


    //自定义的ViewHolder，持有每个Item的的所有界面元素
    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView product_type, product_name, premium_tv, policynum_tv, policyvalue_tv, effectivedate_tv, yesterday_income_tv, policyvalue_tag, effectivedate_tag;
        public Button surrenderstatus_btn, returnstate_btn;
        private LinearLayout effective_linear;
        private RelativeLayout effectivedate_relative;

        public ViewHolder(View view) {
            super(view);
            view.setOnClickListener(this);

            product_type = (TextView) view.findViewById(R.id.product_type);
            product_name = (TextView) view.findViewById(R.id.product_name);
            premium_tv = (TextView) view.findViewById(R.id.premium_tv);

            policynum_tv = (TextView) view.findViewById(R.id.policynum_tv);
            policyvalue_tv = (TextView) view.findViewById(R.id.policyvalue_tv);
            effectivedate_tv = (TextView) view.findViewById(R.id.effectivedate_tv);
            yesterday_income_tv = (TextView) view.findViewById(R.id.yesterday_income_tv);
            policyvalue_tag = (TextView) view.findViewById(R.id.policyvalue_tag);
            effectivedate_tag = (TextView) view.findViewById(R.id.effectivedate_tag);
            surrenderstatus_btn = (Button) view.findViewById(R.id.surrenderstatus_btn);
            returnstate_btn = (Button) view.findViewById(R.id.returnstate_btn);
            effective_linear = (LinearLayout) view.findViewById(R.id.effective_linear);
            effectivedate_relative = (RelativeLayout) view.findViewById(R.id.effectivedate_relative);

        }

        @Override
        public void onClick(View view) {
            clickListener.onItemClick(getAdapterPosition(), view);
        }

    }

    private void getContValue(String contNoPass) {
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("contNo", contNoPass);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        commonSubscriber = new CommonSubscriber<>(subscriberOnNextListener, activity);
        OkHttpObservable.getInstance().getData(commonSubscriber, RequestURL.GetContValueByContNoUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    //获取退保录入
    //退保录入
    private void getRefundInfo(String contNo) {
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("contNo", contNo);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                Gson gson = new Gson();
                SurrenderEntry surrenderEntry = gson.fromJson(result, SurrenderEntry.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("surrenderEntry", surrenderEntry);
                Intent intent = new Intent(activity, SurrenderEntryStepOneActivity.class);
                intent.putExtras(bundle);
                //友盟统计退保
                HashMap<String, String> you_map = new HashMap<>();
                you_map.put("cont_no",surrenderEntry.getContNo());
                you_map.put("mobile", Common.userInfo.getMobile());
                MobclickAgent.onEvent(activity, "surrender_01", you_map);

                activity.startActivity(intent);
            }
        }, activity);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.GetRefundInfoUrl + RequestURL.CreatRequestUrl(mapjson));

    }

    //显示在线回访
    private void showTipKnow(final Button btn, final String contNo) {
        LayoutInflater inflater = activity.getLayoutInflater();
        View layout = inflater.inflate(R.layout.tipshtml_dialgo,
                (ViewGroup) activity.findViewById(R.id.tip_linear));
        final TextView content_tv = (TextView) layout.findViewById(R.id.content_tv);
        content_tv.setMovementMethod(ScrollingMovementMethod.getInstance());
        content_tv.setText(activity.getResources().getString(R.string.onlinevisit_html));
        SpannableString spanText = new SpannableString("4006-833-866");
        spanText.setSpan(new ForegroundColorSpan(activity.getResources().getColor(R.color.colorAccent)), 0, spanText.length(),
                Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        content_tv.append(spanText);
        content_tv.append(activity.getResources().getString(R.string.onlinevisitend_txt));
        final Button konw_btn = (Button) layout.findViewById(R.id.konw_btn);
        konw_btn.setText(activity.getResources().getString(R.string.next_confirm));

        final MaterialDialog materialDialog = new MaterialDialog.Builder(activity)
                .title(R.string.onlinevisit_title)
                .customView(layout, true)
                .show();
        konw_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //设置
                materialDialog.dismiss();
                onlineReturnVisit(btn, contNo);
            }
        });
    }

    private void onlineReturnVisit(final Button returnstate_btn, String contNo) {
        Gson gson = new Gson();
        //01是借记卡 02是存折 暂时都用01
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, Object> map2 = new HashMap<>();
        HashMap<String, String> map3 = new HashMap<>();
        HashMap<String, String> map4 = new HashMap<>();
        HashMap<String, String> map5 = new HashMap<>();
        HashMap<String, String> map6 = new HashMap<>();
        HashMap<String, String> map7 = new HashMap<>();
        map3.put("content", activity.getResources().getString(R.string.onlinevisit1));
        map3.put("result", "1");
        map4.put("content", activity.getResources().getString(R.string.onlinevisit2));
        map4.put("result", "1");
        map5.put("content", activity.getResources().getString(R.string.onlinevisit3));
        map5.put("result", "1");
        map6.put("content", activity.getResources().getString(R.string.onlinevisit4));
        map6.put("result", "1");
        map7.put("content", activity.getResources().getString(R.string.onlinevisit5));
        map7.put("result", "1");
        List<HashMap<String, String>> listMap = new ArrayList<>();
        listMap.add(map3);
        listMap.add(map4);
        listMap.add(map5);
        listMap.add(map6);
        listMap.add(map7);

        map2.put("revisitDetailList", listMap);
        map2.put("revisitResult", "1");
        map2.put("contNo", contNo);
        Date date = new Date();
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentTime = format.format(date);
        map2.put("revisitDate", currentTime);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String resultMessage = jsonObject.getString("resultMessage");
                    String resultCode = jsonObject.getString("resultCode");
                    if ("1".equals(resultCode)) {
                        returnstate_btn.setBackgroundResource(R.drawable.setgray_btn_background);
                        returnstate_btn.setClickable(false);
                        returnstate_btn.setText("已回访");
                    }
                    Toast.makeText(activity, resultMessage, Toast.LENGTH_SHORT).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, activity);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.DoRevisitUrl + RequestURL.CreatRequestUrl(mapjson));
    }

}

