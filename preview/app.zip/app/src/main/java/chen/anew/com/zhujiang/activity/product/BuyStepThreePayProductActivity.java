package chen.anew.com.zhujiang.activity.product;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.SwitchCompat;
import android.support.v7.widget.Toolbar;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.anton46.stepsview.StepsView;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.umeng.analytics.MobclickAgent;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.activity.mine.OrderActivity;
import chen.anew.com.zhujiang.activity.mine.OrderFragment;
import chen.anew.com.zhujiang.activity.mine.setup.ForgetPayPsdSendPhoneStepOneActivity;
import chen.anew.com.zhujiang.adpter.BankListAdpter;
import chen.anew.com.zhujiang.adpter.MyUsedBankListAdpter;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.bean.EbizUserBindcardDTO;
import chen.anew.com.zhujiang.bean.PayModeList;
import chen.anew.com.zhujiang.bean.SerializableMap;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.widget.Loaddialog;
import chen.anew.com.zhujiang.widget.PasswordInputView;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;

/**
 * Created by thinkpad on 2016/7/8.
 */
public class BuyStepThreePayProductActivity extends BaseAppActivity {
    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.stepsView)
    StepsView stepsView;
    @Bind(R.id.productName_tv)
    TextView productNameTv;
    @Bind(R.id.selectbank_btn)
    Button selectbankBtn;
    @Bind(R.id.inputbankcode_et)
    EditText inputbankcodeEt;
    @Bind(R.id.quota_instruction_tv)
    TextView quotaInstructionTv;
    @Bind(R.id.quota_sum)
    TextView quotaSum;
    @Bind(R.id.respectivesums_tv)
    TextView respectivesumsTv;
    @Bind(R.id.inputviacode_et)
    EditText inputviacodeEt;
    @Bind(R.id.sendviacode_btn)
    Button sendviacodeBtn;
    @Bind(R.id.checkbox_select)
    CheckBox checkboxSelect;
    @Bind(R.id.agreeexplain_tv)
    TextView agreeexplainTv;
    @Bind(R.id.confirm_pay)
    Button confirmPay;

    private final String[] labels = {"", "", ""};
    @Bind(R.id.switch_select)
    SwitchCompat switchSelect;
    @Bind(R.id.bank_img)
    ImageView bankImg;
    @Bind(R.id.bank_name)
    TextView bankName;
    @Bind(R.id.transfer_amount)
    TextView transferAmount;
    @Bind(R.id.used_bank_cardview)
    CardView usedBank;
    @Bind(R.id.newbank_linear)
    LinearLayout newbankLinear;
    @Bind(R.id.usenewcard_tv)
    TextView usenewcardTv;


    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private DialogSubscriber dialogSubscriber;
    private Subscriber subscriber;

    private ArrayList<EbizUserBindcardDTO> ebizUserBindcardDTOLists;
    private EbizUserBindcardDTO ebizUserBindcardDTO;

    private int responseTag;
    private String orderNo, mobile, code, total, idNo, name, contNo;
    private ArrayList<PayModeList> payModeLists;
    private PayModeList payModeList;
    private Map<String, String> map;
    private boolean order_pay;

    @Override
    protected void initViews() {
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            final SerializableMap serializableMap = (SerializableMap) bundle.getSerializable("map");
            String productName = bundle.getString("productName");
            order_pay = bundle.getBoolean("order_pay", false);
            orderNo = bundle.getString("orderNo");
            if (serializableMap != null) {
                map = serializableMap.getMap();
                total = map.get("total");
                mobile = map.get("mobile");
                idNo = map.get("idNo");
                name = map.get("name");
            }
            if (order_pay) {
                total = bundle.getString("total");
                mobile = bundle.getString("mobile");
                idNo = bundle.getString("idNo");
                name = bundle.getString("name");
            }
            productNameTv.setText(productName);
            respectivesumsTv.setText(total);
        }
        tvTitle.setText(getResources().getString(R.string.online_pay));
        initToolBar();
        stepsView.setLabels(labels)
                .setBarColorIndicator(getResources().getColor(R.color.chang_white))
                .setProgressColorIndicator(getResources().getColor(R.color.colorAccent))
                .setLabelColorIndicator(getResources().getColor(R.color.white))
                .setCompletedPosition(2)
                .drawView();
        //初始化底部声明
        String INSURANCE_STATEMENT = getResources().getString(R.string.insurance_statement);
        SpannableString spanStatement = new SpannableString(INSURANCE_STATEMENT);
        ClickableSpan clickStatement = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                Loaddialog.showTipKnow(getResources().getString(R.string.insurancestatement_title), getResources().getString(R.string.confirminsurancestatement_html), "", false, BuyStepThreePayProductActivity.this);
            }
        };
        spanStatement.setSpan(clickStatement, 0, INSURANCE_STATEMENT.length(),
                Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        spanStatement.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorAccent)), 0,
                INSURANCE_STATEMENT.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        agreeexplainTv.setText("本人已阅读并同意");
        agreeexplainTv.append(spanStatement);
        agreeexplainTv.setMovementMethod(LinkMovementMethod.getInstance());

        //监听switchSelect
        switchSelect.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    usedBank.setVisibility(View.GONE);
                    newbankLinear.setVisibility(View.VISIBLE);
                } else {
                    usedBank.setVisibility(View.VISIBLE);
                    newbankLinear.setVisibility(View.GONE);
                    if (ebizUserBindcardDTO != null) {
                        initUserBindCardView();
                    } else {
                        getUsedBank();
                    }
                }
            }
        });
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg", "-result-" + result);
                Gson gson = new Gson();
                switch (responseTag) {
                    case 1:
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            String resultCode = jsonObject.getString("resultCode");
                            if ("1".equals(resultCode)) {
                                ebizUserBindcardDTOLists = gson.fromJson(jsonObject.getString("ebizUserBindcardDTOList"), new TypeToken<ArrayList<EbizUserBindcardDTO>>() {
                                }.getType());
                                if (ebizUserBindcardDTOLists != null && ebizUserBindcardDTOLists.size() > 0) {
                                    ebizUserBindcardDTO = ebizUserBindcardDTOLists.get(0);
                                    usedBank.setVisibility(View.VISIBLE);
                                    newbankLinear.setVisibility(View.GONE);
                                    switchSelect.setVisibility(View.VISIBLE);
                                    switchSelect.setChecked(false);
                                    usenewcardTv.setVisibility(View.VISIBLE);
                                    initUserBindCardView();
                                } else {
                                    usedBank.setVisibility(View.GONE);
                                    newbankLinear.setVisibility(View.VISIBLE);
                                    switchSelect.setVisibility(View.GONE);
                                    usenewcardTv.setVisibility(View.GONE);
                                }
                            } else {
                                Toast.makeText(BuyStepThreePayProductActivity.this, jsonObject.getString("resultMessage"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 2:
                        MyLogUtil.i("msg", "-bank-" + result);
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            payModeLists = gson.fromJson(jsonObject.getString("payModeList"), new TypeToken<ArrayList<PayModeList>>() {
                            }.getType());
                            MyLogUtil.i("msg", "-payModeLists-" + payModeLists.size());
                            MyLogUtil.i("msg", "-payModeLists-" + payModeLists.toString());
                            showBankList(payModeLists);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 3:
                        MyLogUtil.i("msg", "-send_code-" + result);
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            code = jsonObject.getString("verificationCode");
                            //Toast.makeText(BuyStepThreePayProductActivity.this, "验证码：" + code, Toast.LENGTH_LONG).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 4:
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            String resultCode = jsonObject.getString("resultCode");
                            if ("1".equals(resultCode)) {
                                //输入密码
                                inputPasswordDialog();
                            } else {
                                //设置支付密码
                                Loaddialog.showSetPayPassword(BuyStepThreePayProductActivity.this);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 5:
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            String resultCode = jsonObject.getString("resultCode");
                            String resultMessage = jsonObject.getString("resultMessage");
                            if ("1".equals(resultCode)) {
                                //支付密码正确
                                //用银行卡号去支付保单
                                paymentPolicy();
                            } else if ("5".equals(resultCode)) {
                                Toast.makeText(BuyStepThreePayProductActivity.this, resultMessage + ",请重置", Toast.LENGTH_LONG).show();
                            } else {
                                //支付密码错误
                                payFailDialog();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 6:
                        MyLogUtil.i("msg", "-pay-" + result);
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            String signResult = jsonObject.getString("signResult");
                            if ("1".equals(signResult)) {
                                contNo = jsonObject.getString("contNo");
                                //成功购买更新本地用户数据
                                if (map != null) {
                                    if (TextUtils.isEmpty(Common.userInfo.getRealName())) {
                                        Common.userInfo.setRealName(map.get("name"));
                                        //创建Intent对象
                                        Intent intent2 = new Intent();
                                        //设置Intent的Action属性
                                        intent2.setAction("CHEN.COM.UPDATEPERSONDATA_MINE");
                                        intent2.putExtra("realname", map.get("name"));
                                        //发送广播,改变姓名显示
                                        sendBroadcast(intent2);
                                    }
                                    if (TextUtils.isEmpty(Common.userInfo.getIdType())) {
                                        Common.userInfo.setIdType(map.get("idType"));
                                    }
                                    if (TextUtils.isEmpty(Common.userInfo.getIdNo())) {
                                        Common.userInfo.setIdNo(map.get("idNo"));
                                    }
                                    if (TextUtils.isEmpty(Common.userInfo.getSex())) {
                                        Common.userInfo.setSex(map.get("sexname"));
                                    }
                                    if (TextUtils.isEmpty(Common.userInfo.getMobile())) {
                                        Common.userInfo.setMobile(map.get("mobile"));
                                    }
                                    if (TextUtils.isEmpty(Common.userInfo.getEmail())) {
                                        Common.userInfo.setEmail(map.get("email"));
                                    }
                                    if (TextUtils.isEmpty(Common.userInfo.getZip())) {
                                        Common.userInfo.setZip(map.get("zip"));
                                    }
                                    if (TextUtils.isEmpty(Common.userInfo.getValidStartDate())) {
                                        Common.userInfo.setValidStartDate(map.get("validStartDate"));
                                    }
                                    if (TextUtils.isEmpty(Common.userInfo.getValidEndDate())) {
                                        Common.userInfo.setValidEndDate(map.get("validEndDate"));
                                    }
                                    if (TextUtils.isEmpty(Common.userInfo.getValidType())) {
                                        Common.userInfo.setIdType(map.get("validType"));
                                    }
                                    if (TextUtils.isEmpty(Common.userInfo.getProvince())) {
                                        Common.userInfo.setProvince(map.get("addressProvinceCode"));
                                    }
                                    if (TextUtils.isEmpty(Common.userInfo.getCity())) {
                                        Common.userInfo.setCity(map.get("addressCityCode"));
                                    }
                                    if (TextUtils.isEmpty(Common.userInfo.getAddress())) {
                                        Common.userInfo.setAddress(map.get("addressDetail"));
                                    }
                                    if (TextUtils.isEmpty(Common.userInfo.getOccupationCode())) {
                                        Common.userInfo.setOccupationCode(map.get("occupationCode"));
                                    }
                                    if (TextUtils.isEmpty(Common.userInfo.getAnnualSalary())) {
                                        Common.userInfo.setAnnualSalary(map.get("salary"));
                                    }
                                    MyApp.daoSession.getUserInfoDao().update(Common.userInfo);
                                }

                                //友盟统计购买
                                HashMap<String, String> you_map = new HashMap<>();
                                you_map.put("cont_no", contNo);
                                you_map.put("mobile", mobile);
                                you_map.put("quantity", total);
                                MobclickAgent.onEvent(BuyStepThreePayProductActivity.this, "purchase_04", you_map);

                                showTipTxtKnow(getResources().getString(R.string.pay_success), getResources().getString(R.string.paysuccess_content), getResources().getString(R.string.confirm_policy), BuyStepThreePayProductActivity.this);
                            } else {
                                Toast.makeText(BuyStepThreePayProductActivity.this, jsonObject.getString("resultMessage"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 7:
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            String resultCode = jsonObject.getString("resultCode");
                            String resultMessage = jsonObject.getString("resultMessage");
                            if ("1".equals(resultCode)) {
                                Toast.makeText(BuyStepThreePayProductActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                                endStep();
                            } else {
                                Toast.makeText(BuyStepThreePayProductActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        break;
                }
            }
        };
        getUsedBank();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
        if (subscriber != null && subscriber.isUnsubscribed()) {
            subscriber.unsubscribe();
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_stepthree_paybuyproduct;
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    private void initUserBindCardView() {
        Glide.with(BuyStepThreePayProductActivity.this).load(ebizUserBindcardDTO.getBankIcon()).into(bankImg);
        String cardCode = ebizUserBindcardDTO.getCardBookCode();
        bankName.setText(ebizUserBindcardDTO.getBankName() + "  (" + cardCode.substring(cardCode.length() - 4) + ")");
//        "该卡本次转账额度"
        SpannableString spanText = new SpannableString("该卡本次转账额度" + ebizUserBindcardDTO.getAccLimit() + "元");
        spanText.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.right_setbtn)), 8, spanText.length(),
                Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        transferAmount.setText(spanText);
        quotaInstructionTv.setText(getString(R.string.quota_instruction) + spanText);
    }

    @OnClick({R.id.selectbank_btn, R.id.sendviacode_btn, R.id.checkbox_select, R.id.confirm_pay, R.id.used_bank_cardview})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.selectbank_btn:
                if (payModeLists != null && payModeLists.size() > 0) {
                    showBankList(payModeLists);
                } else {
                    getEnableBank();
                }
                break;
            case R.id.sendviacode_btn:
                //发送验证码
                initTime();
                sendValCode();
                break;
            case R.id.checkbox_select:
                break;
            case R.id.confirm_pay:
                //确定支付，先验证支付密码是否存在.存在就输入支付密码，不存在就先设置
                checkFormat();
                break;
            case R.id.used_bank_cardview:
                //选择已用过的银行列表
                showUseBankList(ebizUserBindcardDTOLists);
                break;
        }
    }

    private void initTime() {
        final int countTime = 60;
        sendviacodeBtn.setText("重新发送(" + countTime + ")");
        sendviacodeBtn.setClickable(false);
        subscriber = new Subscriber<Integer>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
            }

            @Override
            public void onNext(Integer integer) {
                if (integer == 0) {
                    //isTime = false;
                    sendviacodeBtn.setText("重新发送");
                    sendviacodeBtn.setClickable(true);
                } else {
                    sendviacodeBtn.setText("重新发送(" + integer + ")");
                }
            }
        };
        Observable.interval(0, 1, TimeUnit.SECONDS)
                .subscribeOn(AndroidSchedulers.mainThread())
                .observeOn(AndroidSchedulers.mainThread())
                .map(new Func1<Long, Integer>() {
                    @Override
                    public Integer call(Long increaseTime) {
                        return countTime - increaseTime.intValue();
                    }
                })
                .take(countTime + 1)
                .subscribe(subscriber);
    }

    //检验输入的数据
    private void checkFormat() {
        if (checkboxSelect.isChecked()) {
            String inputBankCark = inputbankcodeEt.getText().toString();
            String inputviacode = inputviacodeEt.getText().toString();
            if (!switchSelect.isChecked()) {
                //表示选择用过的银行卡
                if (TextUtils.isEmpty(code)) {
                    Toast.makeText(this, "请先请求发送验证码", Toast.LENGTH_SHORT).show();
                } else if (!code.equals(inputviacode)) {
                    Toast.makeText(this, "验证码不正确", Toast.LENGTH_SHORT).show();
                } else {
                    ExistsPayPassword();
                }
            } else {
                //表示填写新的卡号
                if (payModeLists == null) {
                    Toast.makeText(this, "请选择你要支付的银行", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(inputBankCark) | inputBankCark.length() < 16) {
                    Toast.makeText(this, "银行卡号格式不正确", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(code)) {
                    Toast.makeText(this, "请先请求发送验证码", Toast.LENGTH_SHORT).show();
                } else if (code != null && !code.equals(inputviacode)) {
                    Toast.makeText(this, "验证码不正确", Toast.LENGTH_SHORT).show();
                } else {
                    ExistsPayPassword();
                }
            }
        } else {
            Toast.makeText(this, "请先同意保险费自动转账授权声明", Toast.LENGTH_SHORT).show();
        }

    }

    //获得用户用过的银行卡
    private void getUsedBank() {
        responseTag = 1;
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("customerId", Common.userInfo.getCustomerId());

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, BuyStepThreePayProductActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.getBankListByIdUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    private void showBankList(final ArrayList<PayModeList> list) {
        new MaterialDialog.Builder(this)
                .title("选择银行")
                .adapter(new BankListAdpter(BuyStepThreePayProductActivity.this, list),
                        new MaterialDialog.ListCallback() {
                            @Override
                            public void onSelection(MaterialDialog dialog, View itemView, int which, CharSequence text) {
                                payModeList = list.get(which);
                                dialog.dismiss();
                                MyLogUtil.i("msg", "-payModeList-" + payModeList.getBankName());
                                MyLogUtil.i("msg", "-payModeList-" + payModeList.getAccTypeList().get(0).getAccLimit());
                                SpannableString spanText = new SpannableString("该卡本次转账额度" + payModeList.getAccTypeList().get(0).getAccLimit() + "元");
                                spanText.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.right_setbtn)), 8, spanText.length(),
                                        Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
                                quotaInstructionTv.setText(getString(R.string.quota_instruction) + spanText);
                                selectbankBtn.setText(payModeList.getBankName());
                            }
                        })
                .show();
    }


    private void showUseBankList(final ArrayList<EbizUserBindcardDTO> list) {
        new MaterialDialog.Builder(this)
                .title("选择用过的银行卡号")
                .adapter(new MyUsedBankListAdpter(BuyStepThreePayProductActivity.this, list),
                        new MaterialDialog.ListCallback() {
                            @Override
                            public void onSelection(MaterialDialog dialog, View itemView, int which, CharSequence text) {
                                ebizUserBindcardDTO = list.get(which);
                                dialog.dismiss();
                                initUserBindCardView();
                            }
                        })
                .show();
    }

    //显示在线回访
    private void showTipKnow() {
        LayoutInflater inflater = this.getLayoutInflater();
        View layout = inflater.inflate(R.layout.tipshtml_dialgo,
                (ViewGroup) this.findViewById(R.id.tip_linear));
        final TextView content_tv = (TextView) layout.findViewById(R.id.content_tv);
        content_tv.setMovementMethod(ScrollingMovementMethod.getInstance());
        content_tv.setText(getResources().getString(R.string.onlinevisit_html));
        SpannableString spanText = new SpannableString("4006-833-866");
        spanText.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorAccent)), 0, spanText.length(),
                Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        content_tv.append(spanText);
        content_tv.append(getResources().getString(R.string.onlinevisitend_txt));
        final Button konw_btn = (Button) layout.findViewById(R.id.konw_btn);
        konw_btn.setText(getResources().getString(R.string.next_confirm));

        final MaterialDialog materialDialog = new MaterialDialog.Builder(this)
                .title(R.string.onlinevisit_title)
                .customView(layout, true)
                .show();
        konw_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //设置
                materialDialog.dismiss();
                onlineReturnVisit();
            }
        });

        materialDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                endStep();
            }
        });
    }

    private void endStep() {
        //结束PRODUCTITEMACTIVITY
        Intent intent4 = new Intent();
        //设置Intent的Action属性
        intent4.setAction("CHEN.COM.PRODUCTITEMACTIVITY");
        intent4.putExtra("is_finish", true);
        sendBroadcast(intent4);

        //结束buyStepOneProductActivity
        Intent intent = new Intent();
        //设置Intent的Action属性
        intent.setAction("CHEN.COM.BUYSTEPONEPRODUCTACTIVITY");
        intent.putExtra("is_finish", true);
        sendBroadcast(intent);
        //结束buyStepTwoProductActivity
        Intent intent2 = new Intent();
        //设置Intent的Action属性
        intent2.setAction("CHEN.COM.BUYSTEPTWOPRODUCTACTIVITY");
        intent2.putExtra("is_finish", true);
        sendBroadcast(intent2);
        if (order_pay) {
            //结束ORDERITEMACTIVITY
            Intent intent3 = new Intent();
            //设置Intent的Action属性
            intent3.setAction("CHEN.COM.ORDERITEMACTIVITY");
            intent3.putExtra("is_finish", true);
            sendBroadcast(intent3);
            //同时更新订单列表
            OrderFragment.isorderSuccess = true;
        }
        //跳转到订单列表
        Intent intent5 = new Intent(BuyStepThreePayProductActivity.this, OrderActivity.class);
        intent5.putExtra("buy_success", true);
        startActivity(intent5);
        finish();
    }

    //支付成功
    private void showTipTxtKnow(String title, String content, String btnTxt, Activity activity) {
        LayoutInflater inflater = activity.getLayoutInflater();
        View layout = inflater.inflate(R.layout.tipstxt_dialgo,
                (ViewGroup) activity.findViewById(R.id.tiptxt_linear));
        final TextView content_tv = (TextView) layout.findViewById(R.id.content_tv);
        content_tv.setMovementMethod(ScrollingMovementMethod.getInstance());
        content_tv.setText(content);
        final Button konw_btn = (Button) layout.findViewById(R.id.konw_btn);
        if (!TextUtils.isEmpty(btnTxt)) {
            konw_btn.setText(btnTxt);
        }
        final MaterialDialog materialDialog = new MaterialDialog.Builder(activity)
                .title(title)
                .cancelable(false)
                .customView(layout, true)
                .show();
        konw_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                materialDialog.dismiss();
                //显示在线回访dialog
                showTipKnow();
            }

        });
    }

    private void payFailDialog() {
        LayoutInflater inflater = this.getLayoutInflater();
        View layout = inflater.inflate(R.layout.set_dialgo,
                (ViewGroup) this.findViewById(R.id.setdia_linear));
        final Button cacle_btn = (Button) layout.findViewById(R.id.cacle_btn);
        final Button setpaypass_btn = (Button) layout.findViewById(R.id.setpaypass_btn);
        final TextView content_tv = (TextView) layout.findViewById(R.id.content_tv);
        content_tv.setText(R.string.payfail_content);
        setpaypass_btn.setText(R.string.again_input);
        final MaterialDialog materialDialog = new MaterialDialog.Builder(this)
                .title(R.string.pay_fail)
                .customView(layout, true)
                .show();
        cacle_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                materialDialog.dismiss();
            }
        });
        setpaypass_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //重新输入
                materialDialog.dismiss();
                inputPasswordDialog();
            }
        });
    }

    //输入密码
    private void inputPasswordDialog() {
        LayoutInflater inflater = this.getLayoutInflater();
        View layout = inflater.inflate(R.layout.setpaypassword_dialgo,
                (ViewGroup) this.findViewById(R.id.setdia_linear));
        final PasswordInputView passwordInputView = (PasswordInputView) layout.findViewById(R.id.passwordInputView);
        final TextView forgetpassword_tv = (TextView) layout.findViewById(R.id.forgetpassword_tv);
        final Button confirm_btn = (Button) layout.findViewById(R.id.confirm_btn);
        final MaterialDialog materialDialog = new MaterialDialog.Builder(this)
                .title(R.string.input_paypassword)
                .customView(layout, true)
                .show();
        confirm_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                materialDialog.dismiss();
                String paypassword = passwordInputView.getText().toString();
                //判断支付密码的正确与否
                ValidateAccountSecurity(paypassword);
            }
        });
        forgetpassword_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //设置
                //忘记密码
                startActivity(new Intent(BuyStepThreePayProductActivity.this, ForgetPayPsdSendPhoneStepOneActivity.class
                ));
            }
        });
    }

    //获得可以使用的银行卡列表
    private void getEnableBank() {
        responseTag = 2;
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("orderNo", orderNo);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, BuyStepThreePayProductActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.GetPaymentListUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    private void sendValCode() {
        responseTag = 3;
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("customerId", Common.userInfo.getCustomerId());
        map2.put("operateType", "3");
        map2.put("operateCode", orderNo);
        map2.put("mobile", mobile);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, BuyStepThreePayProductActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.sendVerificationCodeUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    //支付密码是否存在
    private void ExistsPayPassword() {
        responseTag = 4;
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("customerId", Common.userInfo.getCustomerId());

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, BuyStepThreePayProductActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.ExistsPayPasswordFlagUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    //验证支付密码
    private void ValidateAccountSecurity(String payPassword) {
        responseTag = 5;
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("customerId", Common.userInfo.getCustomerId());
        map2.put("payPassword", payPassword);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, BuyStepThreePayProductActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.ValidateAccountSecurityUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    private void paymentPolicy() {
        responseTag = 6;
        Gson gson = new Gson();
        //01是借记卡 02是存折 暂时都用01
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("accType", "01");
        map2.put("idNo", idNo);
        map2.put("idType", "0");
        map2.put("orderNo", orderNo);
        map2.put("customerId", Common.userInfo.getCustomerId());
        map2.put("customerMobile", mobile);
        map2.put("payAmnt", total);
        map2.put("accName", name);
        if (ebizUserBindcardDTOLists != null && ebizUserBindcardDTOLists.size() > 0) {
            if (!switchSelect.isChecked()) {
                map2.put("accNo", ebizUserBindcardDTO.getCardBookCode());
                map2.put("bankCode", ebizUserBindcardDTO.getBankCode());
            } else {
                String newBankCode = inputbankcodeEt.getText().toString();
                map2.put("accNo", newBankCode);
                map2.put("bankCode", payModeList.getBankCode());
            }
        } else {
            String newBankCode = inputbankcodeEt.getText().toString();
            map2.put("accNo", newBankCode);
            map2.put("bankCode", payModeList.getBankCode());
        }
        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, BuyStepThreePayProductActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.SignPolicyUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    private void onlineReturnVisit() {
        responseTag = 7;
        Gson gson = new Gson();
        //01是借记卡 02是存折 暂时都用01
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, Object> map2 = new HashMap<>();
        HashMap<String, String> map3 = new HashMap<>();
        HashMap<String, String> map4 = new HashMap<>();
        HashMap<String, String> map5 = new HashMap<>();
        HashMap<String, String> map6 = new HashMap<>();
        HashMap<String, String> map7 = new HashMap<>();
        map3.put("content", getResources().getString(R.string.onlinevisit1));
        map3.put("result", "1");
        map4.put("content", getResources().getString(R.string.onlinevisit2));
        map4.put("result", "1");
        map5.put("content", getResources().getString(R.string.onlinevisit3));
        map5.put("result", "1");
        map6.put("content", getResources().getString(R.string.onlinevisit4));
        map6.put("result", "1");
        map7.put("content", getResources().getString(R.string.onlinevisit5));
        map7.put("result", "1");
        List<HashMap<String, String>> listMap = new ArrayList<>();
        listMap.add(map3);
        listMap.add(map4);
        listMap.add(map5);
        listMap.add(map6);
        listMap.add(map7);

        map2.put("revisitDetailList", listMap);
        map2.put("revisitResult", "1");
        map2.put("contNo", contNo);
        Date date = new Date();
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentTime = format.format(date);
        map2.put("revisitDate", currentTime);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, BuyStepThreePayProductActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.DoRevisitUrl + RequestURL.CreatRequestUrl(mapjson));
    }
}
