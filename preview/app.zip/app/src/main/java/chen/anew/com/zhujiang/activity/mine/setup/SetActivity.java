package chen.anew.com.zhujiang.activity.mine.setup;

import android.content.Intent;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;

/**
 * Created by thinkpad on 2016/7/19.
 */

public class SetActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.set));
        initToolBar();
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg", "-payPassword-" + result);
                try {
                    JSONObject jsonObject=new JSONObject(result);
                    String resultCode=jsonObject.getString("resultCode");
                    String resultMessage=jsonObject.getString("resultMessage");
                    String payPasswordFlag=jsonObject.getString("payPasswordFlag");
                    if ("1".equals(resultCode)) {
                        if ("1".equals(payPasswordFlag)) {
                            //已设置支付密码
                            startActivity(new Intent(SetActivity.this,AlreadySetPayPasswordActivity.class));
                        }else if("0".equals(payPasswordFlag)){
                            //未设置支付密码
                            startActivity(new Intent(SetActivity.this,SetPayPasswordActivity.class));
                        }
                        //Toast.makeText(SetActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                    } else if ("0".equals(resultCode)) {
                        if ("0".equals(payPasswordFlag)) {
                            //未设置支付密码
                            startActivity(new Intent(SetActivity.this,SetPayPasswordActivity.class));
                        }else{
                            Toast.makeText(SetActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_set;
    }


    @OnClick({R.id.loginpsd_relative, R.id.paypassword_relative, R.id.forgotten_relative})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.loginpsd_relative:
                startActivity(new Intent(SetActivity.this, ModifyLoginPasswordActivity.class));
                break;
            case R.id.paypassword_relative:
                //先判断支付密码是否存在
                isCheckPay();
                break;
            case R.id.forgotten_relative:
                startActivity(new Intent(SetActivity.this, PatternSetActivity.class));
                break;
        }
    }

    private void isCheckPay(){
        //提交数据
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("customerId", Common.userInfo.getCustomerId());

        map.put("orderType", "32");
        map.put("platType", "3");
        map.put("requestObject", map2);
        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, SetActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.ExistsPayPasswordFlagUrl + RequestURL.CreatRequestUrl(mapjson));
    }
}
