package chen.anew.com.zhujiang.activity.mine.persondata;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.alibaba.sdk.android.oss.ClientException;
import com.alibaba.sdk.android.oss.OSS;
import com.alibaba.sdk.android.oss.OSSClient;
import com.alibaba.sdk.android.oss.ServiceException;
import com.alibaba.sdk.android.oss.callback.OSSCompletedCallback;
import com.alibaba.sdk.android.oss.callback.OSSProgressCallback;
import com.alibaba.sdk.android.oss.internal.OSSAsyncTask;
import com.alibaba.sdk.android.oss.model.PutObjectRequest;
import com.alibaba.sdk.android.oss.model.PutObjectResult;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;
import com.igexin.sdk.PushManager;
import com.readystatesoftware.systembartint.SystemBarTintManager;
import com.umeng.analytics.MobclickAgent;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.activity.guidelogin.LoginActivity;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.bean.OccupationVo;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.event.GlidePauseOnScrollListener;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.OssConfig;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.GlideImageLoader;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.utils.SharedPreferencesUtils;
import chen.anew.com.zhujiang.utils.TxtReader;
import chen.anew.com.zhujiang.utils.VerifyUtil;
import chen.anew.com.zhujiang.utils.ViewUtils;
import chen.anew.com.zhujiang.utils.ZoomBitmap;
import cn.finalteam.galleryfinal.CoreConfig;
import cn.finalteam.galleryfinal.FunctionConfig;
import cn.finalteam.galleryfinal.GalleryFinal;
import cn.finalteam.galleryfinal.PauseOnScrollListener;
import cn.finalteam.galleryfinal.ThemeConfig;
import cn.finalteam.galleryfinal.model.PhotoInfo;
import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by thinkpad on 2016/7/14.
 */
public class MyPersonalData extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.head_img)
    CircleImageView headImg;
    @Bind(R.id.account_tv)
    TextView accountTv;
    @Bind(R.id.username_tv)
    TextView usernameTv;
    @Bind(R.id.sexname_tv)
    TextView sexnameTv;
    @Bind(R.id.idno_type)
    TextView idnoType;
    @Bind(R.id.idno_tv)
    TextView idnoTv;
    @Bind(R.id.phone_tv)
    TextView phoneTv;
    @Bind(R.id.email_tv)
    TextView emailTv;
    @Bind(R.id.annualSalary_tv)
    TextView annualSalaryTv;

    @Bind(R.id.occupation_tv)
    TextView occupationTv;

    // 上传的bitmap
    private Bitmap upbitmap;
    private final int REQUEST_CODE_GALLERY = 1001;
    private final int REQUEST_CODE_CAMERA = 1000;


    private FunctionConfig functionConfig;

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    private MessageReceiver receiver;

    private int httpType, sex = -1;

    private String headimgUrl;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.person_data));
        initToolBar();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ViewUtils.setTranslucentStatus(MyPersonalData.this,true);
            SystemBarTintManager tintManager = new SystemBarTintManager(this);
            // enable status bar tint
            tintManager.setStatusBarTintEnabled(true);
            // enable navigation bar tint
            tintManager.setNavigationBarTintEnabled(true);
            tintManager.setTintColor(ContextCompat.getColor(this, R.color.white));
        }
        initPhoto();
        accountTv.setText(Common.userInfo.getName());
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                //Loaddialog.getInstance().dissLoading();
                Gson gson = new Gson();
                MyLogUtil.i("msg", "-result-" + result);
                if (httpType == 1) {
                    headImg.setImageBitmap(upbitmap);
                    //创建Intent对象
                    Intent intent = new Intent();
                    //设置Intent的Action属性
                    intent.setAction("CHEN.COM.UPDATEPERSONDATA_MINE");
                    intent.putExtra("headimgUrl",headimgUrl);
                    //发送广播,改变地区显示
                    sendBroadcast(intent);

                } else if (httpType == 2) {
                    //性别设置成功
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        String updateResult = jsonObject.getString("updateResult");
                        String resultMessage = jsonObject.getString("resultMessage");
                        if ("1".equals(updateResult)) {
                            Toast.makeText(MyPersonalData.this, resultMessage, Toast.LENGTH_SHORT).show();
                            if (sex == 0) {
                                sexnameTv.setText("男");
                                Common.userInfo.setSex("" + sex);
                            } else if (sex == 1) {
                                sexnameTv.setText("女");
                                Common.userInfo.setSex("" + sex);
                            }
                            MyApp.daoSession.getUserInfoDao().update(Common.userInfo);
                        } else if ("0".equals(updateResult)) {
                            Toast.makeText(MyPersonalData.this, resultMessage, Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            }
        };
        //注册广播
        receiver = new MessageReceiver();
        IntentFilter filter = new IntentFilter("CHEN.COM.UPDATEPERSONDATA");
        this.registerReceiver(receiver, filter);
        initData();
    }

    public class MessageReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String realName = intent.getStringExtra("realname");
            if (!TextUtils.isEmpty(realName)) {
                usernameTv.setText(realName);
            }
            /*String sexVal = intent.getStringExtra("sexVal");
            if (!TextUtils.isEmpty(sexVal)) {
                if ("0".equals(sexVal)) {
                    sexnameTv.setText("男");
                } else if ("1".equals(sexVal)) {
                    sexnameTv.setText("女");
                }
            }*/
            /*String idType = intent.getStringExtra("idType");
            if (!TextUtils.isEmpty(idType)) {
                if ("0".equals(idType)) {
                    idnoType.setText("身份证");
                } else {
                    idnoType.setText("其他证件");
                }
            }*/
            String idNo = intent.getStringExtra("idNo");
            if (!TextUtils.isEmpty(idNo)) {
                idnoTv.setText(VerifyUtil.encryptIdNo(idNo));
                String sexname = VerifyUtil.getSex(idNo);
                sexnameTv.setText(sexname);
            }
            String occupationCode = intent.getStringExtra("occupationCode");
            if (!TextUtils.isEmpty(occupationCode)) {
                ArrayList<OccupationVo> occupationList = new ArrayList<>();
                initLocalData(occupationList);
                OccupationVo occupationVo = VerifyUtil.getOccupationByoccupationCode(occupationList, occupationCode);
                if (occupationVo != null) {
                    //occupationCode = occupationVo.getOccupationCode();
                    occupationTv.setText(occupationVo.getOccupationName());
                }
            }
            String mobile = intent.getStringExtra("mobile");
            if (!TextUtils.isEmpty(mobile)) {
                phoneTv.setText(VerifyUtil.encryptPhone(mobile));
            }
            String email = intent.getStringExtra("email");
            if (!TextUtils.isEmpty(email)) {
                emailTv.setText(email);
            }
            String annualSalary = intent.getStringExtra("annualSalary");
            if (!TextUtils.isEmpty(annualSalary)) {
                annualSalaryTv.setText(annualSalary);
            }
        }
    }

    private void initData() {
        Glide.with(this).load(Common.userInfo.getHeadimgurl())
                .error(R.mipmap.defaulthead)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .centerCrop()
                .into(headImg);
        usernameTv.setText(Common.userInfo.getRealName());
        String sexVal = Common.userInfo.getSex();
        if (!TextUtils.isEmpty(sexVal)) {
            if ("0".equals(sexVal)) {
                sexnameTv.setText("男");
            } else if ("1".equals(sexVal)) {
                sexnameTv.setText("女");
            }
        }
        //证件类型
        String documentType = Common.userInfo.getIdType();
        if(!TextUtils.isEmpty(documentType)){
            if ("0".equals(documentType)) {
                idnoType.setText("身份证");
            } else {
                idnoType.setText("其他证件");
            }
        }
        String idNo = Common.userInfo.getIdNo();
        if (TextUtils.isEmpty(idNo)) {
            idnoTv.setText("未设置");
        } else {
            idnoTv.setText(VerifyUtil.encryptIdNo(idNo));
            String sexname = VerifyUtil.getSex(idNo);
            sexnameTv.setText(sexname);
        }
        //显示职业
        String occupationCode = Common.userInfo.getOccupationCode();
        if (!TextUtils.isEmpty(occupationCode)) {
            ArrayList<OccupationVo> occupationList = new ArrayList<>();
            initLocalData(occupationList);
            OccupationVo occupationVo = VerifyUtil.getOccupationByoccupationCode(occupationList, occupationCode);
            if (occupationVo != null) {
                //occupationCode = occupationVo.getOccupationCode();
                occupationTv.setText(occupationVo.getOccupationName());
            }
        }
        phoneTv.setText(VerifyUtil.encryptPhone(Common.userInfo.getMobile()));
        emailTv.setText(Common.userInfo.getEmail());
        annualSalaryTv.setText(Common.userInfo.getAnnualSalary()+"  (万元)");
    }

    private void initLocalData(ArrayList<OccupationVo> occupationList) {
        // 将本地res中raw文件夹中的txt转化为输入流
        InputStream inputStream2 = getResources().openRawResource(
                R.raw.new_occupation);
        TxtReader.getOccupationList(inputStream2,
                occupationList);
    }

  /*  @Override
    protected void onResume() {
        super.onResume();
        initData();
    }*/

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void initPhoto() {
        ThemeConfig theme = new ThemeConfig.Builder()
                .setTitleBarBgColor(Color.WHITE)
                .setTitleBarTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorAccent))
                .setTitleBarIconColor(ContextCompat.getColor(getApplicationContext(), R.color.colorAccent))
                .setFabNornalColor(ContextCompat.getColor(getApplicationContext(), R.color.colorAccent))
                .setFabPressedColor(ContextCompat.getColor(getApplicationContext(), R.color.colorAccent))
                .setCheckNornalColor(Color.WHITE)
                .setCheckSelectedColor(ContextCompat.getColor(getApplicationContext(), R.color.colorAccent))
                .build();
        functionConfig = new FunctionConfig.Builder()
                .setEnableEdit(true)
                .setEnableCrop(true)
                .setEnableRotate(true)
                .setCropSquare(true)
                .setForceCrop(true)
                .setForceCropEdit(true)
                .setEnablePreview(true).build();
        GlideImageLoader imageLoader = new GlideImageLoader();
        PauseOnScrollListener pauseOnScrollListener = new GlidePauseOnScrollListener(false, true);
        CoreConfig coreConfig = new CoreConfig.Builder(MyPersonalData.this, imageLoader, theme)
                .setFunctionConfig(functionConfig)
                .setPauseOnScrollListener(pauseOnScrollListener)
                .setNoAnimcation(true)
                .build();
        GalleryFinal.init(coreConfig);
    }

    private GalleryFinal.OnHanlderResultCallback mOnHanlderResultCallback = new GalleryFinal.OnHanlderResultCallback() {
        @Override
        public void onHanlderSuccess(int reqeustCode, List<PhotoInfo> resultList) {
            if (resultList != null) {
                // 解成bitmap,方便裁剪
                Bitmap bitmap = BitmapFactory.decodeFile(resultList.get(0).getPhotoPath());
                float wight = bitmap.getWidth();
                float height = bitmap.getHeight();
                upbitmap = ZoomBitmap.zoomImage(bitmap, wight / 8, height / 8);
                MyLogUtil.i("msg", "-resultList-" + resultList.get(0).getPhotoPath());
                final String path = resultList.get(0).getPhotoPath();
                Long date = new Date().getTime();
                OssConfig.driver = "app/android/" + date.toString() + UUID.randomUUID().toString().toString() + OssConfig.bucket + ".jpg";
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        OssConfig.oss = new OSSClient(MyPersonalData.this, OssConfig.endpoint, OssConfig.credentialProvider);
                        asyncPutObjectFromLocalFile(OssConfig.oss, OssConfig.bucket, OssConfig.driver, path);
                    }
                });
            }
        }

        @Override
        public void onHanlderFailure(int requestCode, String errorMsg) {
            Toast.makeText(MyPersonalData.this, errorMsg, Toast.LENGTH_SHORT).show();
        }
    };


    // 从本地文件上传，使用非阻塞的异步接口
    public void asyncPutObjectFromLocalFile(OSS oss, String testBucket, String testObject, String uploadFilePath) {
        // 构造上传请求
        PutObjectRequest put = new PutObjectRequest(testBucket, testObject, uploadFilePath);
        // 异步上传时可以设置进度回调
        put.setProgressCallback(new OSSProgressCallback<PutObjectRequest>() {
            @Override
            public void onProgress(PutObjectRequest request, long currentSize, long totalSize) {
                MyLogUtil.i("msg", "currentSize: " + currentSize + " totalSize: " + totalSize);
            }
        });
        OSSAsyncTask task = oss.asyncPutObject(put, new OSSCompletedCallback<PutObjectRequest, PutObjectResult>() {
            @Override
            public void onSuccess(PutObjectRequest request, PutObjectResult result) {
                // 只有设置了servercallback，这个值才有数据
                String serverCallbackReturnJson = result.getServerCallbackReturnBody();
                MyLogUtil.i("msg", "-BucketName-" + request.getBucketName() + "-getObjectKey-" + request.getObjectKey());
                headimgUrl = OssConfig.endpoint + "/" + request.getBucketName() + "/" + request.getObjectKey();
                Message message = new Message();
                message.what = Common.REFRESH_DATA_FINISH;
                message.obj = headimgUrl;
                handler.sendMessage(message);
                MyLogUtil.i("msg", serverCallbackReturnJson);
            }

            @Override
            public void onFailure(PutObjectRequest request, ClientException clientExcepion, ServiceException serviceException) {
                // 请求异常
                if (clientExcepion != null) {
                    // 本地异常如网络异常等
                    clientExcepion.printStackTrace();
                }
                if (serviceException != null) {
                    // 服务异常
                    MyLogUtil.i("msg", serviceException.getErrorCode());
                    MyLogUtil.i("msg", serviceException.getRequestId());
                    MyLogUtil.i("msg", serviceException.getHostId());
                    MyLogUtil.i("msg", serviceException.getRawMessage());
                }
            }
        });
    }

    private Handler handler = new Handler() {
        public void handleMessage(android.os.Message msg) {
            switch (msg.what) {
                case Common.REFRESH_DATA_FINISH:
                    Common.userInfo.setHeadimgurl(msg.obj.toString());
                    MyApp.daoSession.getUserInfoDao().update(Common.userInfo);
                    modifyHead(msg.obj.toString());
                    break;
            }
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
        if (receiver != null) {
            this.unregisterReceiver(receiver);
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_personaldata;
    }


    @OnClick({R.id.annualSalary_relative,R.id.head_relative,R.id.username_relative, R.id.sexname_relative, R.id.documenttype_relative, R.id.bank_relative, R.id.phone_relative, R.id.email_relative, R.id.address_relative, R.id.accountexit_btn, R.id
            .profession_relative})
    public void onClick(View view) {
        switch (view.getId()) {
//            annualSalary_relative
           /* case R.id.account_relative:
                startActivity(new Intent(MyPersonalData.this, ModifyNameActivity.class));
                break;*/
            case R.id.annualSalary_relative:
                startActivity(new Intent(MyPersonalData.this, ModifySalaryActivity.class));
                break;
            case R.id.head_relative:
                //显示图像拍照对话框
                showPhoto();
                break;
            case R.id.username_relative:
                if (!TextUtils.isEmpty(Common.userInfo.getRealName())) {
                    Toast.makeText(MyPersonalData.this, R.string.no_modify_username, Toast.LENGTH_SHORT).show();
                } else {
                    startActivity(new Intent(MyPersonalData.this, ModifyNameActivity.class));
                }
                break;
            case R.id.sexname_relative:
                //设置性别
                if (!TextUtils.isEmpty(Common.userInfo.getSex())) {
                    Toast.makeText(MyPersonalData.this, R.string.no_modify_sex, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MyPersonalData.this, "请先填写身份证信息", Toast.LENGTH_SHORT).show();
                }
                /*if(!TextUtils.isEmpty(Common.userInfo.getSex())){
                    Toast.makeText(MyPersonalData.this,R.string.no_modify_sex,Toast.LENGTH_SHORT).show();
                }else{
                    showSexDialog();
                }*/
                break;
            case R.id.documenttype_relative:
                if (!TextUtils.isEmpty(Common.userInfo.getIdNo())) {
                    Toast.makeText(MyPersonalData.this, R.string.no_modify_indo, Toast.LENGTH_SHORT).show();
                } else {
                    startActivity(new Intent(MyPersonalData.this, SetIdNoActivity.class));
                }
                break;
            case R.id.bank_relative:
                startActivity(new Intent(MyPersonalData.this, MyBankCardActivity.class));
                break;
            case R.id.phone_relative:
                if (!TextUtils.isEmpty(Common.userInfo.getMobile())) {
                    Toast.makeText(MyPersonalData.this, R.string.no_modify_mobile, Toast.LENGTH_SHORT).show();
                } else {
                    startActivity(new Intent(MyPersonalData.this, PhoneCodeBindActivity.class));
                }
                break;
            case R.id.profession_relative:
                //修改职业
                startActivity(new Intent(MyPersonalData.this, ModifyProfessionActivity.class));
                break;
            case R.id.email_relative:
                startActivity(new Intent(MyPersonalData.this, ModifyEmailActivity.class));
                break;
            case R.id.address_relative:
                startActivity(new Intent(MyPersonalData.this, MyAddressActivity.class));
                break;
            case R.id.accountexit_btn:
                showExitAccount();
                break;
        }
    }

    private void showExitAccount() {
        LayoutInflater inflater = this.getLayoutInflater();
        View layout = inflater.inflate(R.layout.set_dialgo,
                (ViewGroup) this.findViewById(R.id.setdia_linear));
        final Button cacle_btn = (Button) layout.findViewById(R.id.cacle_btn);
        cacle_btn.setText(R.string.cancle);
        final Button setpaypass_btn = (Button) layout.findViewById(R.id.setpaypass_btn);
        setpaypass_btn.setText(R.string.confirm_exit);
        final TextView content_tv = (TextView) layout.findViewById(R.id.content_tv);
        content_tv.setText(R.string.confirm_exit_account);
        final MaterialDialog materialDialog = new MaterialDialog.Builder(this)
                .title(R.string.account_exit)
                .customView(layout, true)
                .show();
        cacle_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                materialDialog.dismiss();
            }
        });
        setpaypass_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //设置
                materialDialog.dismiss();
                //清除customerId，password
                /*if (MainActivity.mainActivity != null) {
                    MainActivity.mainActivity.finish();
                }*/
                SharedPreferencesUtils.setParam(MyPersonalData.this, SharedPreferencesUtils.CUSTOMER_ID, "");
                SharedPreferencesUtils.setParam(MyPersonalData.this, SharedPreferencesUtils.CUSTOMER_PASSWORD, "");
                Common.userInfo = null;
                Common.customer_id = null;
                Intent intent = new Intent();
                //设置Intent的Action属性
                intent.setAction("CHEN.COM.MESSAGE_HINT_ACTION");
                intent.putExtra("is_finish", true);
                sendBroadcast(intent);
                MobclickAgent.onProfileSignOff();
                PushManager.getInstance().stopService(MyPersonalData.this);
                startActivity(new Intent(MyPersonalData.this, LoginActivity.class));
                finish();
            }
        });
    }

    private void showSexDialog() {
        new MaterialDialog.Builder(MyPersonalData.this)
                .title(R.string.select_sex)
                .items(R.array.select_sex)
                .itemsCallbackSingleChoice(0, new MaterialDialog.ListCallbackSingleChoice() {
                    @Override
                    public boolean onSelection(MaterialDialog dialog, View view, int which, CharSequence text) {
                        //0表示男,1表示女
                        sex = which;
                        modifySex("" + which);
                        return true;
                    }
                })
                .positiveText("选择")
                .show();
    }

    private void showPhoto() {
        LayoutInflater inflater = this.getLayoutInflater();
        View layout = inflater.inflate(R.layout.photo_dialgo,
                (ViewGroup) this.findViewById(R.id.photodialog_linear));
        final TextView photograph_tv = (TextView) layout.findViewById(R.id.photograph_tv);
        final TextView album_tv = (TextView) layout.findViewById(R.id.album_tv);
        final Button cancle_btn = (Button) layout.findViewById(R.id.cancle_btn);
        final MaterialDialog materialDialog = new MaterialDialog.Builder(this)
                .title(R.string.modify_head)
                .customView(layout, true)
                .show();
        cancle_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                materialDialog.dismiss();
            }
        });
        photograph_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GalleryFinal.openCamera(REQUEST_CODE_CAMERA, functionConfig, mOnHanlderResultCallback);
                materialDialog.dismiss();
            }
        });
        album_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //带配置
                GalleryFinal.openGallerySingle(REQUEST_CODE_GALLERY, functionConfig, mOnHanlderResultCallback);
                materialDialog.dismiss();
            }
        });
    }

    private void modifyHead(String headimgurl) {
        httpType = 1;
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("customerId", Common.userInfo.getCustomerId());
        map2.put("headimgurl", headimgurl);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, MyPersonalData.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.editAccountInfoUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    private void modifySex(String sex) {
        httpType = 2;
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("customerId", Common.userInfo.getCustomerId());
        map2.put("sex", sex);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, MyPersonalData.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.editAccountInfoUrl + RequestURL.CreatRequestUrl(mapjson));
    }

}
