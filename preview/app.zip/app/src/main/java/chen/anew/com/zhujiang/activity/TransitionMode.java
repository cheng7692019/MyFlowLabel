package chen.anew.com.zhujiang.activity;

/**
 * Created by thinkpad on 2016/6/25.
 */
public enum TransitionMode {
    LEFT,RIGHT,TOP,BOTTOM,SCALE,FADE
}
