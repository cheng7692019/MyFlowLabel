package chen.anew.com.zhujiang.activity.main;

import android.content.Intent;
import android.os.Build;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.readystatesoftware.systembartint.SystemBarTintManager;

import org.greenrobot.greendao.query.Query;

import java.util.List;

import butterknife.Bind;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.adpter.MessageAdpter;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.greendao.MessageBean;
import chen.anew.com.zhujiang.greendao.MessageBeanDao;
import chen.anew.com.zhujiang.utils.ViewUtils;

/**
 * Created by thinkpad on 2016/7/26.
 */

public class MessageActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.common_recyclerview)
    RecyclerView commonRecyclerview;
    @Bind(R.id.no_policy)
    ImageView noPolicy;

    private MessageBeanDao messageBeanDao;
    private MessageAdpter messageAdpter;

    @Override
    protected void initViews() {
        tvTitle.setText(R.string.message);
        initToolBar();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ViewUtils.setTranslucentStatus(MessageActivity.this,true);
            SystemBarTintManager tintManager = new SystemBarTintManager(this);
            // enable status bar tint
            tintManager.setStatusBarTintEnabled(true);
            // enable navigation bar tint
            tintManager.setNavigationBarTintEnabled(true);
            tintManager.setTintColor(ContextCompat.getColor(this, R.color.white));
        }
        messageBeanDao = MyApp.daoSession.getMessageBeanDao();
        Query query = messageBeanDao.queryBuilder().where(
                MessageBeanDao.Properties.CustomerId.eq(Common.customer_id))
                .orderDesc(MessageBeanDao.Properties.SendTime)
                .build();
        List<MessageBean> messageList = (List<MessageBean>) query.list();
        if (messageList != null & messageList.size() > 0) {
            noPolicy.setVisibility(View.GONE);
            messageAdpter=new MessageAdpter(messageList,MessageActivity.this);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
            linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
            commonRecyclerview.setLayoutManager(linearLayoutManager);
            commonRecyclerview.setAdapter(messageAdpter);
        }else{
            noPolicy.setVisibility(View.VISIBLE);
        }
        //更新数据库中所有isRead字段
        for(int i=0;i<messageList.size();i++){
            MessageBean messageBean=messageList.get(i);
            messageBean.setIsRead("Y");
            messageBeanDao.update(messageBean);
        }
        //创建Intent对象
        Intent intent = new Intent();
        //设置Intent的Action属性
        intent.setAction("CHEN.COM.MESSAGE_HINT_ACTION");
        intent.putExtra("img_red",0);
        //发送广播,改变消息颜色
        sendBroadcast(intent);

        //创建Intent对象
        Intent intent2 = new Intent();
        //设置Intent的Action属性
        intent2.setAction("CHEN.COM.UPDATEPERSONDATA_MINE");
        intent2.putExtra("img_red",0);
        //发送广播,改变消息颜色
        sendBroadcast(intent2);
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected int getContentViewId() {
        return R.layout.message_common_list;
    }

}
