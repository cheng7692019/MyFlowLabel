package chen.anew.com.zhujiang.common;


import chen.anew.com.zhujiang.greendao.UserInfo;

/**
 * Created by thinkpad on 2016/6/29.
 */
public class Common {
    public static UserInfo userInfo;

    public static String customer_id;

    public final static int REFRESH_DATA_FINISH = 1005;

    /**
     * 上传图片的限制大小(kb)
     */
    public static final int IMAGE_MAX_SIZE = 5*1024;

    /**
     * 最大改变压缩次数（内存溢出时）
     */
    public final static int REVISION_IMAGE_MAX_NUM = 3;
}
