package chen.anew.com.zhujiang.adpter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.swipehelper.ItemTouchHelperAdapter;
import chen.anew.com.zhujiang.activity.swipehelper.ItemTouchHelperViewHolder;
import chen.anew.com.zhujiang.bean.EbizUserBindcardDTO;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;

/**
 * Created by thinkpad on 2016/7/8.
 */
public class BankUsedListAdpter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements ItemTouchHelperAdapter {

    public ArrayList<EbizUserBindcardDTO> datas = null;

    private Context context;

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    public BankUsedListAdpter(ArrayList<EbizUserBindcardDTO> datas, Context context) {
        this.datas = datas;
        this.context = context;
    }

    public void updateView(ArrayList<EbizUserBindcardDTO> datas) {
        this.datas = datas;
        this.notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_used_bankcard, viewGroup, false);
        return new ViewHolder(view);
    }


    //将数据与界面进行绑定的操作
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {
        EbizUserBindcardDTO ebizUserBindcardDTO = datas.get(position);
        ViewHolder viewHolder = (ViewHolder) holder;
        viewHolder.bank_name.setText(ebizUserBindcardDTO.getBankName());
        viewHolder.bankcard_number_tv.setText(ebizUserBindcardDTO.getCardBookCode());
        String cardBookType = ebizUserBindcardDTO.getCardBookType();
//        bankcardtype_tv,bankcard_number_tv;
        if ("01".equals(cardBookType)) {
            viewHolder.bankcardtype_tv.setText("储蓄卡");
        } else if ("02".equals(cardBookType)) {
            viewHolder.bankcardtype_tv.setText("存折");
        }
        String bankCode = ebizUserBindcardDTO.getBankCode();
        int bank = Integer.valueOf(bankCode.substring(1));
        switch (bank) {
            case 100:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0100);
                break;
            case 102:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0102);
                break;
            case 103:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0103);
                break;
            case 104:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0104);
                break;
            case 105:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0105);
                break;
            case 301:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0301);
                break;
            case 302:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0302);
                break;
            case 303:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0303);
                break;
            case 304:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0304);
                break;
            case 305:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0305);
                break;
            case 306:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0306);
                break;
            case 307:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0307);
                break;
            case 308:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0308);
                break;
            case 309:
                viewHolder.bank_img.setImageResource(R.mipmap.bank_0309);
                break;
        }
    }


    //获取数据的数量
    @Override
    public int getItemCount() {
        return datas.size();
    }

    @Override
    public void onItemMove(int fromPosition, int toPosition) {
        if (fromPosition < toPosition) {
            for (int i = fromPosition; i < toPosition; i++) {
                Collections.swap(datas, i, i + 1);
            }
        } else {
            for (int i = fromPosition; i > toPosition; i--) {
                Collections.swap(datas, i, i - 1);
            }
        }
        notifyItemMoved(fromPosition, toPosition);
    }

   /* @Override
    public void onViewRecycled(RecyclerView.ViewHolder holder) {
        super.onViewRecycled(holder);
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
    }*/

    @Override
    public void onItemDismiss(final int position) {
        //删除行时的监听操作
        EbizUserBindcardDTO ebizUserBindcardDTO = datas.get(position);
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String resultCode = jsonObject.getString("resultCode");
                    String resultMessage = jsonObject.getString("resultMessage");
                    if ("1".equals(resultCode)) {
                        notifyItemRemoved(position);
                        datas.remove(position);
                        notifyItemRangeChanged(0, getItemCount());
                        Toast.makeText(context, resultMessage, Toast.LENGTH_SHORT).show();
                    }else if ("0".equals(resultCode)) {
                        Toast.makeText(context, resultMessage, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        UnbindBankToUser(ebizUserBindcardDTO.getCardBookCode());
    }

    //自定义的ViewHolder，持有每个Item的的所有界面元素
    static class ViewHolder extends RecyclerView.ViewHolder implements ItemTouchHelperViewHolder {
        protected TextView bank_name, bankcardtype_tv, bankcard_number_tv;
        protected CardView used_bank_cardview;
        protected ImageView bank_img;

        public ViewHolder(View view) {
            super(view);
            bank_name = (TextView) view.findViewById(R.id.bank_name);
            bankcardtype_tv = (TextView) view.findViewById(R.id.bankcardtype_tv);
            bankcard_number_tv = (TextView) view.findViewById(R.id.bankcard_number_tv);
            bank_img = (ImageView) view.findViewById(R.id.bank_img);
            used_bank_cardview = (CardView) view.findViewById(R.id.used_bank_cardview);
        }

        @Override
        public void onItemSelected(Context context) {
            used_bank_cardview.setBackgroundColor(ContextCompat.getColor(context, R.color.colorAccent));
            bank_name.setTextColor(ContextCompat.getColor(context, R.color.white));
            bankcardtype_tv.setTextColor(ContextCompat.getColor(context, R.color.white));
            bankcard_number_tv.setTextColor(ContextCompat.getColor(context, R.color.white));
            //bank_img.setColorFilter(ContextCompat.getColor(context, R.color.white), PorterDuff.Mode.SRC_IN);
        }

        @Override
        public void onItemClear(Context context) {
            used_bank_cardview.setBackgroundColor(ContextCompat.getColor(context, R.color.plain_background));
            //bank_img.setColorFilter(ContextCompat.getColor(context, R.color.textlight), PorterDuff.Mode.SRC_IN);
            bank_name.setTextColor(ContextCompat.getColor(context, R.color.txt_black));
            bankcardtype_tv.setTextColor(ContextCompat.getColor(context, R.color.txt_black));
            bankcard_number_tv.setTextColor(ContextCompat.getColor(context, R.color.txt_black));
        }
    }

    private void UnbindBankToUser(String cardBookCode) {
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("customerId", Common.userInfo.getCustomerId());
        map2.put("cardBookCode", cardBookCode);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, context);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.unbindBankToUserUrl + RequestURL.CreatRequestUrl(mapjson));
    }
}

