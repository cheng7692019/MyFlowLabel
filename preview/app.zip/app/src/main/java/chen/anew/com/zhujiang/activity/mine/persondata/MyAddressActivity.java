package chen.anew.com.zhujiang.activity.mine.persondata;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.InputStream;
import java.util.ArrayList;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.bean.CityVo;
import chen.anew.com.zhujiang.bean.ProvinceVo;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.utils.TxtReader;

/**
 * Created by thinkpad on 2016/7/18.
 */
public class MyAddressActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.provicecity_tv)
    TextView provicecityTv;
    @Bind(R.id.areadetail_address_tv)
    TextView areadetailAddressTv;
    @Bind(R.id.post_code_tv)
    TextView postCodeTv;
    @Bind(R.id.address_cardview)
    CardView addressCardview;
    @Bind(R.id.no_address)
    ImageView noAddress;
    @Bind(R.id.fab_add)
    FloatingActionButton fabAdd;

    public static ArrayList<ProvinceVo> provinceList;
    public static ArrayList<CityVo> cityList;

    // 需要获取的值
    private ProvinceVo currentProvinceVo = null;
    private CityVo currentCityVo = null;
    private String provinceId, cityId, addressProvince, addressCity;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.address_txt));
        initToolBar();
    }

    private void initData(){
        initLocalData();
        //初始化省份城市
        String provinceCode = Common.userInfo.getProvince();
        String cityCode = Common.userInfo.getCity();
        if (!TextUtils.isEmpty(provinceCode) && !TextUtils.isEmpty(cityCode)) {
            // 将name作为keyword获取省名称和省的编码
            for (ProvinceVo pv : provinceList) {
                if (pv.getProvincePostCode().equals(provinceCode)) {
                    currentProvinceVo = new ProvinceVo();
                    currentProvinceVo.setProvinceName(pv
                            .getProvinceName());
                    currentProvinceVo.setProvincePostCode(pv
                            .getProvincePostCode());
                }
            }
            // 将name作为keyword获取市名称和市邮政编码
            for (CityVo cv : cityList) {
                if (cv.getCityPostCode().equals(cityCode)) {
                    currentCityVo = new CityVo();
                    currentCityVo.setCityName(cv.getCityName());
                    currentCityVo.setCityPostCode(cv.getCityPostCode());
                    currentCityVo.setProvincePostCode(cv
                            .getProvincePostCode());
                }
            }
            provinceId = currentProvinceVo.getProvincePostCode();
            cityId = currentCityVo.getCityPostCode();
            // addressProvince,addressCity,occupationName,occupationCode;
            addressProvince = currentProvinceVo.getProvinceName();
            addressCity = currentCityVo.getCityName();
            provicecityTv.setText(addressProvince + addressCity);
            areadetailAddressTv.setText(Common.userInfo.getAddress());
            postCodeTv.setText(Common.userInfo.getZip());

            addressCardview.setVisibility(View.VISIBLE);
            noAddress.setVisibility(View.GONE);
            fabAdd.setVisibility(View.GONE);
        }else{
            addressCardview.setVisibility(View.GONE);
            noAddress.setVisibility(View.VISIBLE);
            fabAdd.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        initData();
    }

    private void initLocalData() {
        // 将本地res中raw文件夹中的txt转化为输入流
        provinceList = new ArrayList<>();
        cityList = new ArrayList<>();
        InputStream inputStream = getResources()
                .openRawResource(R.raw.cityinfo);
        TxtReader.getProvinceListAndCityList(inputStream, provinceList,
                cityList);
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }


    @Override
    protected int getContentViewId() {
        return R.layout.activity_myaddress;
    }

    @OnClick({R.id.address_cardview, R.id.fab_add})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.address_cardview:
                Intent intent2=new Intent(MyAddressActivity.this,ModifyAddressActivity.class);
                //addressProvince + addressCity
                if(!TextUtils.isEmpty(provinceId)&&!TextUtils.isEmpty(cityId)){
                    intent2.putExtra("addressProvince",addressProvince);
                    intent2.putExtra("addressCity",addressCity);
                    intent2.putExtra("provinceId",provinceId);
                    intent2.putExtra("cityId",cityId);
                }
                startActivity(intent2);
                break;
            case R.id.fab_add:
                Intent intent=new Intent(MyAddressActivity.this,ModifyAddressActivity.class);
                //addressProvince + addressCity
                if(!TextUtils.isEmpty(provinceId)&&!TextUtils.isEmpty(cityId)){
                    intent.putExtra("addressProvince",addressProvince);
                    intent.putExtra("addressCity",addressCity);
                    intent.putExtra("provinceId",provinceId);
                    intent.putExtra("cityId",cityId);
                }
                startActivity(intent);
                break;
        }
    }
}
