package chen.anew.com.zhujiang.activity.mine;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.Bind;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.adpter.AssetsAdpter;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.bean.MyAssets;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.fragment.MineFragment;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.OkHttpUtils;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.CommonSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import me.zhanghai.android.materialprogressbar.IndeterminateProgressDrawable;

/**
 * Created by thinkpad on 2016/7/13.
 */
public class MyAssetsActivity extends BaseAppActivity {
    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;

    @Bind(R.id.recyclerview)
    RecyclerView mRecyclerView;
    @Bind(R.id.no_policy)
    ImageView no_policy;
    @Bind(R.id.progress_bar)
    ProgressBar progressBar;

    @Bind(R.id.accountAsset_tv)
    TextView accountAssetTv;
    @Bind(R.id.dayTotalAmnt_tv)
    TextView dayTotalAmntTv;
    @Bind(R.id.totalIncome_tv)
    TextView totalIncomeTv;
    @Bind(R.id.footer_relative)
    LinearLayout footer_relative;


    private CommonSubscriber commonSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private ArrayList<MyAssets> contLists;
    private int mcurrentPage = 1;
    private AssetsAdpter assetsAdpter;
    private boolean flag;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.my_assets));
        initToolBar();
//        accountAsset, dayTotalAmnt, totalIncome;
        IndeterminateProgressDrawable indeterminateProgressDrawable = new IndeterminateProgressDrawable(getApplicationContext());
        indeterminateProgressDrawable.setTint(getApplicationContext().getResources().getColor(R.color.colorAccent));
        progressBar.setProgressDrawable(indeterminateProgressDrawable);
        progressBar.setIndeterminateDrawable(indeterminateProgressDrawable);
        accountAssetTv.setText(MineFragment.accountAsset);
        dayTotalAmntTv.setText(MineFragment.dayTotalAmnt);
        totalIncomeTv.setText(MineFragment.totalIncome);
        progressBar.setVisibility(View.VISIBLE);
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg", "-contStatus-" + result);
                Gson gson = new Gson();
                if (!TextUtils.isEmpty(result)) {
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        // String resultCode = jsonObject.getString("resultCode");
                        //成功获得活动列表
//                        JSONObject jsonObject = new JSONObject(result)
                        ArrayList<MyAssets> nowcontLists = gson.fromJson(jsonObject.getString("contList"), new TypeToken<ArrayList<MyAssets>>() {
                        }.getType());
                        //初始化列表
                        contLists.addAll(nowcontLists);
                        if (mcurrentPage == 1) {
                            if (nowcontLists != null && nowcontLists.size() + 1 < 5) {
                                flag=true;
                            } else {
                                flag=false;
                            }
                            assetsAdpter.updateView(contLists);
                        } else {
                            //加载更多
                            if (nowcontLists != null && nowcontLists.size() + 1 < 5) {
                                flag=true;
                            } else {
                                flag=false;
                            }
                            footer_relative.setVisibility(View.GONE);
                            assetsAdpter.updateView(contLists);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    footer_relative.setVisibility(View.GONE);
                    if (contLists.size() == 0) {
                        no_policy.setVisibility(View.VISIBLE);
                    }
                }
                progressBar.setVisibility(View.GONE);
            }
        };
        initReview();
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void initReview() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(layoutManager);
        contLists = new ArrayList<>();
        assetsAdpter = new AssetsAdpter(contLists, this);
//        View header = LayoutInflater.from(this).inflate(R.layout.assets_head, (ViewGroup)findViewById(R.id.statement_of_income_rl),false);
//        mRecyclerView.addView(header);
        mRecyclerView.setAdapter(assetsAdpter);
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (isSlideToBottom(recyclerView)) {
                    if(flag){
                        footer_relative.setVisibility(View.VISIBLE);
                        mcurrentPage++;
                        getOrderList(mcurrentPage);
                    }
                }
            }
        });
        getOrderList(mcurrentPage);
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_my_assets;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (commonSubscriber != null && commonSubscriber.isUnsubscribed()) {
            commonSubscriber.unsubscribe();
        }
    }

    private void getOrderList(int currentPage) {
        if(TextUtils.isEmpty(Common.customer_id)){
            return;
        }
        if (!OkHttpUtils.isNetworkAvailable(getApplicationContext())) {
            Toast.makeText(getApplicationContext(), "暂时没有可用的网络", Toast.LENGTH_SHORT).show();
            return;
        }
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        HashMap<String, Object> map3 = new HashMap<>();
        map2.put("queryAll", "false");
        map2.put("currentPage", "" + currentPage);
        map2.put("pageSize", "5");

        map3.put("customerId", Common.customer_id);
        map3.put("pageParams", map2);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map3);

        String mapjson = gson.toJson(map);
        MyLogUtil.i("msg", "-mapjson-" + mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        commonSubscriber = new CommonSubscriber(subscriberOnNextListener, getApplicationContext());
        OkHttpObservable.getInstance().getData(commonSubscriber, RequestURL.MyAssetsListUrl + RequestURL.CreatRequestUrl(mapjson));

    }

    protected boolean isSlideToBottom(RecyclerView recyclerView) {
        if (recyclerView == null) return false;
        if (recyclerView.computeVerticalScrollExtent() + recyclerView.computeVerticalScrollOffset() >= recyclerView.computeVerticalScrollRange())
            return true;
        return false;
    }
}
