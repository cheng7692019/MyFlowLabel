package chen.anew.com.zhujiang.activity.mine;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.anton46.stepsview.StepsView;
import com.google.gson.Gson;
import com.umeng.analytics.MobclickAgent;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.HashMap;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.bean.SurrenderEntry;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;

/**
 * Created by thinkpad on 2016/7/12.
 */
public class SurrenderEntryStepOneActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.stepsView)
    StepsView stepsView;
    @Bind(R.id.policynumber_tv)
    TextView policynumberTv;
    @Bind(R.id.productname_tv)
    TextView productnameTv;
    @Bind(R.id.accountvalue_tv)
    TextView accountvalueTv;
    @Bind(R.id.inputviacode_et)
    EditText inputviacodeEt;
    @Bind(R.id.full_btn)
    Button fullBtn;
    @Bind(R.id.netfee_tv)
    TextView netfeeTv;
    @Bind(R.id.amountreceived_tv)
    TextView amountreceivedTv;
    @Bind(R.id.check_terminationpolicy)
    CheckBox checkTerminationpolicy;
    @Bind(R.id.terminationpolicy_tv)
    TextView terminationpolicyTv;
    @Bind(R.id.nextconfirm_btn)
    Button nextconfirmBtn;

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    //上页面传来的值
    private String isCancelPolicy, isWithdrawAll, isHesitation, availableMoney, contValue, withdrawMoney;
    private SurrenderEntry surrenderEntry;
    private final String[] labels = {"", ""};

    //    public static SurrenderEntryStepOneActivity surrenderEntryStepOneActivity;
    private MessageReceiver receiver;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.input_information));
        initToolBar();
        Bundle bundle = getIntent().getExtras();
        surrenderEntry = (SurrenderEntry) bundle.getSerializable("surrenderEntry");
        stepsView.setLabels(labels)
                .setBarColorIndicator(getResources().getColor(R.color.chang_white))
                .setProgressColorIndicator(getResources().getColor(R.color.colorAccent))
                .setLabelColorIndicator(getResources().getColor(R.color.white))
                .setCompletedPosition(0)
                .drawView();
        policynumberTv.setText(surrenderEntry.getContNo());
        productnameTv.setText(surrenderEntry.getProductName());
        contValue = surrenderEntry.getContValue();
        accountvalueTv.setText(surrenderEntry.getContValue());
        isHesitation = surrenderEntry.getIsHesitation();
        if ("1".equals(isHesitation)) {
            //犹豫期内只能退全额
            inputviacodeEt.setText(surrenderEntry.getPoliyValue());
            inputviacodeEt.setEnabled(false);
        }else{
            //犹豫期外是否可部分领取 1是可以 部分领取不显示保单价值
            if("0".equals(surrenderEntry.getIsPartWithdraw())){
                inputviacodeEt.setText(surrenderEntry.getContValue());
                inputviacodeEt.setEnabled(false);

            }else if("1".equals(surrenderEntry.getIsPartWithdraw())){
//                inputviacodeEt.setText(surrenderEntry.getContValue());
                inputviacodeEt.setEnabled(true);
            }
        }
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg", "contValue" + result);
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String resultCode = jsonObject.getString("resultCode");
                    String resultMessage = jsonObject.getString("resultMessage");
                    if ("1".equals(resultCode)) {
                        nextconfirmBtn.setText(R.string.next_step);
                        availableMoney = jsonObject.getString("availableMoney");
                        withdrawMoney = jsonObject.getString("withdrawMoney");
                        amountreceivedTv.setText(availableMoney + "元");
                        //手续费
                        DecimalFormat df = new DecimalFormat("0.00");            //转2位小数点
                        double d = Double.valueOf(withdrawMoney) - Double.valueOf(availableMoney);
                        String db = df.format(d);
                        netfeeTv.setText(db);
                    } else if ("0".equals(resultCode)) {
                        Toast.makeText(SurrenderEntryStepOneActivity.this, resultMessage, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        inputviacodeEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!TextUtils.isEmpty(withdrawMoney)) {
                    if (!s.toString().equals(withdrawMoney)) {
                        nextconfirmBtn.setText("确定");
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        //注册广播
        receiver = new MessageReceiver();
        IntentFilter filter = new IntentFilter("CHEN.COM.SURRENDERENTRYSTEPONEACTIVITY");
        this.registerReceiver(receiver, filter);
    }

    public class MessageReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean flag=intent.getBooleanExtra("is_finish",false);
            if(flag){
                if(!isFinishing()){
                    finish();
                }
            }
        }
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
        if(receiver!=null){
            unregisterReceiver(receiver);
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_surrenderentry_stepone;
    }

    @OnClick({R.id.check_terminationpolicy, R.id.nextconfirm_btn, R.id.full_btn})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.full_btn:
                //全额
                inputviacodeEt.setText(surrenderEntry.getPoliyValue());
                break;
            case R.id.check_terminationpolicy:
                break;
            case R.id.nextconfirm_btn:
                //点击确定后获取扣除手续费和实际退保金额
                String btnTag = nextconfirmBtn.getText().toString();
                String viacode = inputviacodeEt.getText().toString();
                if ("确定".equals(btnTag)) {
                    getReturnCal(viacode);
                } else if ("下一步".equals(btnTag)) {
                    //确定跳传
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("surrenderEntry", surrenderEntry);
                    bundle.putString("withdrawMoney", withdrawMoney);    //申请金额
                    bundle.putString("netfee", netfeeTv.getText().toString());              //手续费
                    bundle.putString("availableMoney", availableMoney);                    //实际金额

                    bundle.putString("isCancelPolicy", isCancelPolicy);                                    //是否全额退保
                    bundle.putString("isWithdrawAll", isWithdrawAll);
                    Intent intent = new Intent(SurrenderEntryStepOneActivity.this, SurrenderEntryStepTwoActivity.class);
                    intent.putExtras(bundle);

                    //友盟统计退保
                    HashMap<String, String> you_map = new HashMap<>();
                    you_map.put("cont_no",surrenderEntry.getContNo());
                    you_map.put("mobile", Common.userInfo.getMobile());
                    you_map.put("quantity",availableMoney);
                    MobclickAgent.onEvent(this, "surrender_02", you_map);

                    startActivity(intent);
                }
                break;
        }
    }

    private void getReturnCal(String viacode) {
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("contNo", surrenderEntry.getContNo());
        //
        if ("1".equals(isHesitation)) {
            map2.put("isCancelPolicy", "1");
            map2.put("isWithdrawAll", "1");
            isCancelPolicy = "1";
            isWithdrawAll = "1";
            map2.put("withdrawMoney", contValue);
        } else {
            if (viacode.equals(contValue)) {
                map2.put("isCancelPolicy", "1");
                map2.put("isWithdrawAll", "1");
                isCancelPolicy = "1";
                isWithdrawAll = "1";
            } else {
                map2.put("isCancelPolicy", "0");
                map2.put("isWithdrawAll", "0");
                isCancelPolicy = "0";
                isWithdrawAll = "0";
            }
            map2.put("withdrawMoney", viacode);
        }
        map2.put("orderNo", surrenderEntry.getOrderNo());
        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.GetRefundCalUrl + RequestURL.CreatRequestUrl(mapjson));
    }

}
