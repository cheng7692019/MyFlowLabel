package chen.anew.com.zhujiang.activity.guidelogin;

import android.content.Intent;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.VerifyUtil;

/**
 * Created by thinkpad on 2016/6/30.
 */
public class ForgetPassword extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.one_phone)
    EditText onePhone;
    private String phone;
    private String sessionId;

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;


    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.recovered_pass));
        initToolBar();

        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                //Loaddialog.getInstance().dissLoading();
                if(TextUtils.isEmpty(sessionId)){
                    String mobileAuthFlag=null;
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        mobileAuthFlag = jsonObject.getString("mobileAuthFlag");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    if ("0".equals(mobileAuthFlag)) {
                        Toast.makeText(ForgetPassword.this, "该手机号还未注册", Toast.LENGTH_SHORT).show();
                    }else if ("1".equals(mobileAuthFlag)) {
                        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
                            dialogSubscriber.unsubscribe();
                        }
                        getRemoteSendCode();
                    }
                }else{
                 //返回了验证码
                    //解析验证码
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        String code = jsonObject.getString("verificationCode");
                        Intent intent=new Intent(ForgetPassword.this,ForgetNextPassword.class);
                        intent.putExtra("code",code);
                        intent.putExtra("phone",phone);
                        intent.putExtra("sessionId",sessionId);
                        startActivity(intent);
                        finish();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_forgetpassword;
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @OnClick(R.id.register_btn)
    public void onClick() {
        phone = onePhone.getText().toString();
        if (!VerifyUtil.VerificationPhone(phone)) {
            Toast.makeText(ForgetPassword.this, "手机号码格式不对", Toast.LENGTH_SHORT).show();
        } else {
            IsMobileAuth(phone);
        }
    }

    private void getRemoteSendCode() {
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("operateType", "2");
        sessionId = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        map2.put("sessionId", sessionId);
        map2.put("customerMobile", phone);
        map2.put("operateCode", phone);

        map.put("orderType", "32");
        map.put("platType", "3");
        map.put("requestObject", map2);
        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, ForgetPassword.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.GetPolicyQueryCodeUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    private void IsMobileAuth(String phone) {
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map2.put("mobile", phone);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map2);

        String mapjson = gson.toJson(map);
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, ForgetPassword.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.GetIsMobileAuthUrl + RequestURL.CreatRequestUrl(mapjson));
    }
}
