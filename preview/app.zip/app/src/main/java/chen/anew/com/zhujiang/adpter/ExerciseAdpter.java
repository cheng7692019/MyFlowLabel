package chen.anew.com.zhujiang.adpter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;

import java.util.ArrayList;

import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.greendao.Activity_List;

/**
 * Created by thinkpad on 2016/6/30.
 */
public class ExerciseAdpter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public ArrayList<Activity_List> datas = null;

    public Context context;

    public ExerciseAdpter(ArrayList<Activity_List> datas, Context context) {
        this.context = context;
        this.datas = datas;
    }

    private ClickListener clickListener;

    public interface ClickListener {
        void onItemClick(int position, View v);
    }

    public void setOnItemClickListener(ClickListener clickListener) {
        this.clickListener = clickListener;
    }


    //创建新View，被LayoutManager所调用

    @Override
    public int getItemViewType(int position) {
        return Integer.parseInt(datas.get(position).getStatus());
    }

    public void updateView(ArrayList<Activity_List> datas) {
        this.datas = datas;
        this.notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view;
        RecyclerView.ViewHolder holer = null;
        if (viewType == -1) {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(
                    R.layout.list_activity_monthitem, null);
            holer = new ViewHolder(view);
        } else {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(
                    R.layout.list_activity_dayitem, null);
            holer = new ViewHolder2(view);
        }
        return holer;
        /*View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_activity_monthitem, viewGroup, false);
        return new ViewHolder(view);*/
    }


    //将数据与界面进行绑定的操作
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {
        Activity_List activity_list = datas.get(position);
        if (getItemViewType(position) == -1) {
            ViewHolder viewHolder = (ViewHolder) holder;
            viewHolder.marker.setText(activity_list.getTitle());
            viewHolder.mTextView.setText(activity_list.getTitle() + "月活动");
        } else {
            final ViewHolder2 viewHolder2 = (ViewHolder2) holder;
            String date = activity_list.getActivityDate();
            viewHolder2.marker.setText(date.substring(date.lastIndexOf("-") + 1, date.lastIndexOf("-") + 3));
            //Log.i("date","-date-time-"+date.substring(date.lastIndexOf("-")+1));
            viewHolder2.title_tv.setText(activity_list.getTitle());
            viewHolder2.subheading_tv.setText(activity_list.getSubheading());
            if (!TextUtils.isEmpty(activity_list.getActivityImage())) {
                Glide.with(context).load(activity_list.getActivityImage()).asBitmap().into(new SimpleTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(Bitmap resource, GlideAnimation<? super Bitmap> glideAnimation) {
                        Drawable drawable = new BitmapDrawable(context.getResources(), resource);
                        viewHolder2.background_relayout.setBackgroundDrawable(drawable);
                    }
                });
            }

            int status = Integer.parseInt(activity_list.getStatus());
            //活动状态，0即将开始，1进行中，2已结束
            switch (status) {
                case 0:
                    viewHolder2.status_iv.setImageResource(R.mipmap.activity_begin);
                    break;
                case 1:
                    viewHolder2.status_iv.setImageResource(R.mipmap.activity_underway);
                    break;
                case 2:
                    viewHolder2.status_iv.setImageResource(R.mipmap.activity_end);
                    break;
            }
        }

    }


    //获取数据的数量
    @Override
    public int getItemCount() {
        return datas.size();
    }

    //自定义的ViewHolder，持有每个Item的的所有界面元素
    static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView marker;
        public TextView mTextView;

        public ViewHolder(View view) {
            super(view);
            marker = (TextView) view.findViewById(R.id.marker);
            mTextView = (TextView) view.findViewById(R.id.month_item_tv);
        }
    }

    //自定义的ViewHolder，持有每个Item的的所有界面元素
    public class ViewHolder2 extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView marker, title_tv, subheading_tv;
        public ImageView status_iv;
        public RelativeLayout background_relayout;

        public ViewHolder2(View view) {
            super(view);
            view.setOnClickListener(this);
            marker = (TextView) view.findViewById(R.id.marker);
            title_tv = (TextView) view.findViewById(R.id.title_tv);
            subheading_tv = (TextView) view.findViewById(R.id.subheading_tv);
            status_iv = (ImageView) view.findViewById(R.id.status_iv);
            background_relayout = (RelativeLayout) view.findViewById(R.id.background_relayout);

        }

        @Override
        public void onClick(View view) {
            clickListener.onItemClick(getAdapterPosition(), view);
        }

    }
}

