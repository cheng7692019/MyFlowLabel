package chen.anew.com.zhujiang.activity.web;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ProgressBar;

import butterknife.Bind;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseFragment;
import chen.anew.com.zhujiang.pullrefresh.layout.BaseHeaderView;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.widget.NormalHeaderView;

/**
 * Created by thinkpad on 2016/7/5.
 */

public class WebMatchViewFragment extends BaseFragment implements BaseHeaderView.OnRefreshListener {

    @Bind(R.id.webView)
    WebView webView;
    @Bind(R.id.header)
    NormalHeaderView headerView;
    @Bind(R.id.myProgressBar)
    ProgressBar myProgressBar;

    private String url;
    public static boolean flag = true;

    public static WebMatchViewFragment newInstance(Bundle args) {
        WebMatchViewFragment webview = new WebMatchViewFragment();
        webview.setArguments(args);
        return webview;
    }

    @Override
    protected void initViews() {
        mPageName="WebMatchViewFragment";
        Bundle bundle = getArguments();
        url = bundle.getString("url");
        MyLogUtil.i("url", "--url-" + url);
        WebSettings setting = webView.getSettings();
        setting.setDefaultTextEncodingName("utf-8");//设置字符编码
        webView.getSettings().setJavaScriptEnabled(true);//支持js
        webView.addJavascriptInterface(new JavaScriptObject(getContext()), "JavaScriptObject");
        setting.setAllowFileAccess(true);
        setting.setBuiltInZoomControls(false);
//        webView.setWebViewClient(new MyWebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress == 100) {
                    headerView.stopRefresh();
                    myProgressBar.setVisibility(View.INVISIBLE);
                } else {
                    if (View.INVISIBLE == myProgressBar.getVisibility()) {
                        myProgressBar.setVisibility(View.VISIBLE);
                    }
                    myProgressBar.setProgress(newProgress);
                }
                super.onProgressChanged(view, newProgress);
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                super.onShowCustomView(view, callback);
            }
        });
        webView.loadUrl(url);
        headerView.setOnRefreshListener(this);
    }

    @Override
    protected int getContentViewId() {
        return R.layout.fragmentmatch_webview;
    }

    @Override
    public void onRefresh(BaseHeaderView baseHeaderView) {
        webView.reload();//刷新
    }
}
