package chen.anew.com.zhujiang.activity.web;

import android.annotation.TargetApi;
import android.os.Build;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.umeng.analytics.MobclickAgent;

import butterknife.Bind;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.utils.MyLogUtil;

/**
 * Created by thinkpad on 2016/7/5.
 */
public class WebViewActivity extends BaseAppActivity {
    @Bind(R.id.webView)
    WebView webView;
    @Bind(R.id.toolbar)
    Toolbar app_bar;
    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.myProgressBar)
    ProgressBar myProgressBar;
    private String url,title;
    private final String mPageName = "WebViewActivity";

    @TargetApi(Build.VERSION_CODES.KITKAT)
    @Override
    protected void initViews() {
        initToolBar();
        title=getIntent().getStringExtra("title");
        tvTitle.setText(title);
        url=getIntent().getStringExtra("url");
        url="www.qq.com";
        MyLogUtil.i("url","--url-"+url);
        if(!TextUtils.isEmpty(url)){
            //是否包含？号
            /*if(url.contains("?")){
                url = url + "&plat=2";
            }else{
                url = url + "?plat=2";
            }*/
            WebSettings setting = webView.getSettings();
            setting.setUseWideViewPort(true);
            setting.setLoadWithOverviewMode(true);
            setting.setSupportZoom(true);
            setting.setJavaScriptEnabled(true);//支持js
            setting.setDomStorageEnabled(true);
            setting.setDefaultTextEncodingName("utf-8");//设置字符编码
            setting.setAllowFileAccess(true);
            webView.requestFocusFromTouch();// 设置支持获取手势焦点
            webView.setWebContentsDebuggingEnabled(true);

            webView.setWebViewClient(new WebViewClient());
            WebChromeClient webChromeClient=new WebChromeClient(){
                @Override
                public void onProgressChanged(WebView view, int newProgress) {
                    if (newProgress == 100) {
                        myProgressBar.setVisibility(View.INVISIBLE);
                    } else {
                        if (View.INVISIBLE == myProgressBar.getVisibility()) {
                            myProgressBar.setVisibility(View.VISIBLE);
                        }
                        myProgressBar.setProgress(newProgress);
                    }
                    super.onProgressChanged(view, newProgress);
                }
            };
            webView.setWebChromeClient(webChromeClient);
            //webView.addJavascriptInterface(new JavaScriptObject(WebViewActivity.this), "JavaScriptObject");
            MyLogUtil.i("url","--url-"+url);
            url="www.baidu.com";
            webView.loadUrl(url);
        }
    }
    @Override
    protected void onResume() {
        MobclickAgent.onPageStart(mPageName);
        super.onResume();
    }

    @Override
    protected void onPause() {
        MobclickAgent.onPageEnd(mPageName);
        super.onPause();
    }

    private void initToolBar() {
        setSupportActionBar(app_bar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        app_bar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_webview;
    }
}
