package chen.anew.com.zhujiang.fragment;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.util.ArrayMap;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ufreedom.uikit.FloatingText;

import org.adw.library.widgets.discreteseekbar.DiscreteSeekBar;
import org.greenrobot.greendao.query.Query;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.activity.guidelogin.LoginActivity;
import chen.anew.com.zhujiang.activity.main.MessageActivity;
import chen.anew.com.zhujiang.activity.product.ProductItemActivity;
import chen.anew.com.zhujiang.base.BaseFragment;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.greendao.MessageBean;
import chen.anew.com.zhujiang.greendao.MessageBeanDao;
import chen.anew.com.zhujiang.greendao.ProductList;
import chen.anew.com.zhujiang.greendao.ProductListDao;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.OkHttpUtils;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.utils.ViewUtils;
import chen.anew.com.zhujiang.widget.GiftRainView;
import chen.anew.com.zhujiang.widget.WaveLoadingView;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;

/**
 * Created by thinkpad on 2016/7/1.
 */
public class RecommendFragment extends BaseFragment {
    @Bind(R.id.center_wave)
    WaveLoadingView centerWave;
    @Bind(R.id.bottom_wave)
    WaveLoadingView bottomWave;
    @Bind(R.id.decrease_img)
    ImageView decreaseImg;
    @Bind(R.id.add_img)
    ImageView addImg;
    @Bind(R.id.dropview)
    GiftRainView dropview;
    @Bind(R.id.productname_tv)
    TextView productnameTv;
    @Bind(R.id.history_interestrate_tv)
    TextView historyInterestrateTv;
    @Bind(R.id.mix_interestrate_tv)
    TextView mixInterestrateTv;
    @Bind(R.id.surrender_year_tv)
    TextView surrenderYearTv;

    @Bind(R.id.seekbar_progress)
    DiscreteSeekBar seekbarProgress;

    @Bind(R.id.mine_buy)
    TextView mineBuy;
    @Bind(R.id.staramount_tv)
    TextView staramountTv;
    @Bind(R.id.buy_btn)
    Button buyBtn;

    @Bind(R.id.amount_et)
    EditText amountEt;
    @Bind(R.id.message_recommend_imgbtn)
    ImageView messageRecommendImgbtn;

    private int scale, maxMult, price = 1000;
    private FloatingText floatingText;
    private Subscriber addSubscriber;
    private Subscriber decreaseSubscriber;

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private  ProductList productList;
    private MessageHintReceiver receiver;
    private ProductListDao productListDao;

    private static boolean is_first = true;

    public static RecommendFragment newInstance() {
        RecommendFragment recommendFragment = new RecommendFragment();
        return recommendFragment;
    }

    @Override
    protected void initViews() {
        mPageName="RecommendFragment";
//        bottomWave.setFull(true);
//        centerWave.setTopTitle("我要买(元)\n1000元起投");
        initToolBar();
        productListDao = MyApp.daoSession.getProductListDao();
        centerWave.setCenterTitle("1000");   //centerWave默认最大值100
        //dropview.setImages(R.mipmap.diips_30, R.mipmap.diips_32, R.mipmap.water_40);
        mineBuy.bringToFront();
        staramountTv.bringToFront();
        amountEt.bringToFront();
        amountEt.setSelection(amountEt.getText().length());

        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                //Loaddialog.getInstance().dissLoading();
                MyLogUtil.i("exe", "-ActivitiesData-" + result);
                Gson gson = new Gson();
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String resultCode = jsonObject.getString("resultCode");
                    if ("1".equals(resultCode)) {
                        //成功获得活动列表
//                        JSONObject jsonObject = new JSONObject(result)
                        List<ProductList> nowProductList = gson.fromJson(jsonObject.getString("productList"), new TypeToken<ArrayList<ProductList>>() {
                        }.getType());
                        is_first = false;
                        productList = nowProductList.get(0);
                        //保存数据到数据库
                        productListDao.insertOrReplace(productList);
                        initView();
                    } else {
                        Query query = productListDao.queryBuilder().where(
                                ProductListDao.Properties.IsHot.eq("1"), ProductListDao.Properties.ProductType.eq("1"))
                                .build();
                        List<ProductList> nowProductList = (List<ProductList>) query.list();
                        productList = nowProductList.get(0);
//                        productList= MyApp.daoSession.getProductListDao().
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        if (is_first || productList == null) {
            getPeoductItemData();
        } else {
            getNoWebHotProduct();
        }
        //注册广播
        receiver = new MessageHintReceiver();
        IntentFilter filter = new IntentFilter("CHEN.COM.MESSAGE_HINT_ACTION");
        getActivity().registerReceiver(receiver, filter);
    }

    private void getNoWebHotProduct() {
        Query query = productListDao.queryBuilder().where(
                ProductListDao.Properties.IsHot.eq("1"), ProductListDao.Properties.ProductType.eq("1"))
                .build();
        List<ProductList> nowProductList = (List<ProductList>) query.list();
        if (nowProductList != null && nowProductList.size() > 0) {
            productList = nowProductList.get(0);
            initView();
        }
    }

    private void initView() {
        String status = productList.getStatus();
        if ("05".equals(status) | "06".equals(status)) {
            //已下架或售罄
            buyBtn.setBackgroundResource(R.drawable.gray_off_btn);
            buyBtn.setEnabled(false);
            if ("05".equals(status)) {
                buyBtn.setText("已下架");
            } else if ("06".equals(status)) {
                buyBtn.setText("已售罄");
            }
            seekbarProgress.setEnabled(false);
            decreaseImg.setEnabled(false);
            addImg.setEnabled(false);
        } else {
            buyBtn.setBackgroundResource(R.drawable.setdialog_right_change);
            //buyBtn.
            // (ContextCompat.getDrawable(getContext(), R.drawable.setdialog_right_change));
            seekbarProgress.setEnabled(true);
            buyBtn.setEnabled(true);
            decreaseImg.setEnabled(true);
            addImg.setEnabled(true);
            maxMult = Integer.valueOf(productList.getMaxMult());
            seekbarProgress.setMax(maxMult);
            price = Integer.valueOf(productList.getPrice());
            /*amountEt.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    //   scale = Integer.valueOf(maxMult);
                    if (!TextUtils.isEmpty(s.toString())) {
                        int scale = Integer.valueOf(s.toString());
                        int new_maxMult = maxMult * price / 2;
                        if (scale < 0) {
                            Toast.makeText(getActivity(), "金额必须大于0", Toast.LENGTH_SHORT).show();
                        }
                        if (scale > maxMult * price) {
                            Toast.makeText(getActivity(), "金额必须小于" + maxMult * price, Toast.LENGTH_SHORT).show();
                            scale = maxMult * price;
                        }
                        if (scale > new_maxMult * 0.95) {
                            amountEt.setTextColor(ContextCompat.getColor(getContext(), R.color.white));
                        } else {
                            amountEt.setTextColor(ContextCompat.getColor(getContext(), R.color.colorAccent));
                        }
                        if (scale > new_maxMult * 1.7) {
                            mineBuy.setTextColor(ContextCompat.getColor(getContext(), R.color.white));
                            staramountTv.setTextColor(ContextCompat.getColor(getContext(), R.color.white));
                        } else {
                            mineBuy.setTextColor(ContextCompat.getColor(getContext(), R.color.txt_black));
                            staramountTv.setTextColor(ContextCompat.getColor(getContext(), R.color.txt_black));
                        }
                        //amountEt.setSelection(s.toString().length());
                        centerWave.setProgressValue(scale / (maxMult * 10));
                    } else {
                        Toast.makeText(getActivity(), "金额必须大于0", Toast.LENGTH_SHORT).show();
                    }
                }
            });*/

            seekbarProgress.setOnProgressChangeListener(new DiscreteSeekBar.OnProgressChangeListener() {
                @Override
                public void onProgressChanged(DiscreteSeekBar seekBar, int value, boolean fromUser) {
                    scale = Integer.valueOf(maxMult) / 100;
                    int new_maxMult = maxMult / 2;
                    if (value > new_maxMult) {
                        centerWave.setCenterTitleColor(ContextCompat.getColor(getContext(), R.color.white));
                    } else {
                        centerWave.setCenterTitleColor(ContextCompat.getColor(getContext(), R.color.colorAccent));
                    }
                    if (value > new_maxMult * 1.7) {
                        mineBuy.setTextColor(ContextCompat.getColor(getContext(), R.color.white));
                        staramountTv.setTextColor(ContextCompat.getColor(getContext(), R.color.white));
                    } else {
                        mineBuy.setTextColor(ContextCompat.getColor(getContext(), R.color.txt_black));
                        staramountTv.setTextColor(ContextCompat.getColor(getContext(), R.color.txt_black));
                    }
                    centerWave.setProgressValue(value / scale);
                    seekBar.setIndicatorFormatter("" + price * value);
                    centerWave.setCenterTitle("" + price * value);
                }

                @Override
                public void onStartTrackingTouch(DiscreteSeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(DiscreteSeekBar seekBar) {

                }
            });
        }
        productnameTv.setText(productList.getProductName());
        historyInterestrateTv.setText(productList.getHistoryRate());
        mixInterestrateTv.setText(productList.getAssureRate());
        surrenderYearTv.setText(productList.getCostFeePeriod());
    }

    private void initToolBar() {
        MessageBeanDao messageBeanDao = MyApp.daoSession.getMessageBeanDao();
        Query query = messageBeanDao.queryBuilder().where(
                MessageBeanDao.Properties.CustomerId.eq(Common.customer_id), MessageBeanDao.Properties.IsRead.eq("N"))
                .build();
        List<MessageBean> messageList = (List<MessageBean>) query.list();
        if (messageList != null & messageList.size() > 0) {
            messageRecommendImgbtn.setImageResource(R.mipmap.message_red);
        } else {
            messageRecommendImgbtn.setImageResource(R.mipmap.new_message);
        }
    }

    public class MessageHintReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            int img_red = intent.getIntExtra("img_red", -1);
            if (img_red == 1) {
                messageRecommendImgbtn.setImageResource(R.mipmap.message_red);
            } else if (img_red == 0) {
                messageRecommendImgbtn.setImageResource(R.mipmap.new_message);
            }
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.frament_recommend;
    }

    @OnClick({R.id.decrease_img, R.id.add_img, R.id.buy_btn, R.id.relative_recommend_left})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.relative_recommend_left:
                startActivity(new Intent(getActivity(), MessageActivity.class));
                break;
            case R.id.decrease_img:
                if (productList != null) {
                    int old_total = Integer.valueOf(centerWave.getCenterTitle());
                    scale = Integer.parseInt(productList.getMaxMult()) * (Integer.parseInt(productList.getPrice()) / 100);
                    if (old_total < 1100) {
                        ViewUtils.showSnackbar(view, "亲,已经见底了加点币吧", getContext());
                        //Toast.makeText(getContext(), "亲,已经见底了加点币吧", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int new_money = old_total - 1000;
                    centerWave.setCenterTitle("" + (new_money));
                    centerWave.setProgressValue(new_money / scale);
                    centerWave.setAmplitudeRatio(20);
                    floatingText = new FloatingText.FloatingTextBuilder(getActivity())
                            .textColor(getResources().getColor(R.color.light_gold)) // floating  text color
                            .textSize(80)   // floating  text size
                            .textContent("-1000") // floating  text content
                            .offsetX(100) // the x offset  relate to the attached view
                            .offsetY(100) // the y offset  relate to the attached view
                            // .floatingAnimatorEffect(FloatingAnimator) // floating animation
                            // .floatingPathEffect(FloatingPathEffect) // floating path
                            .build();
                    floatingText.attach2Window();
                    floatingText.startFloating(decreaseImg);
                    //减号的时候
                    // dropview.startRain();
                    //bottomWave.setAmplitudeRatio(20);
                    decreaseSubscriber = new Subscriber<Integer>() {
                        @Override
                        public void onCompleted() {
                        }

                        @Override
                        public void onError(Throwable e) {
                        }

                        @Override
                        public void onNext(Integer integer) {
                            //dropview.stopRainDely();
                            centerWave.setAmplitudeRatio(integer);
                            //bottomWave.setAmplitudeRatio(integer);
                        }
                    };
                    Observable.create(new Observable.OnSubscribe<Integer>() {
                        @Override
                        public void call(Subscriber<? super Integer> subscriber) {
                            subscriber.onNext(10);
                        }
                    }).delay(1, TimeUnit.SECONDS).subscribeOn(AndroidSchedulers.mainThread())
                            .observeOn(AndroidSchedulers.mainThread()).subscribe(decreaseSubscriber);
                }
                break;
            case R.id.add_img:
                if (productList != null) {
                    int old_money = Integer.valueOf(centerWave.getCenterTitle());
                    scale = Integer.parseInt(productList.getMaxMult()) * (Integer.parseInt(productList.getPrice()) / 100);
                    old_money = old_money + 1000;
                    centerWave.setCenterTitle("" + (old_money));
                    centerWave.setProgressValue(old_money / scale);
                    centerWave.setAmplitudeRatio(20);
                    floatingText = new FloatingText.FloatingTextBuilder(getActivity())
                            .textColor(getResources().getColor(R.color.light_gold)) // floating  text color
                            .textSize(80)   // floating  text size
                            .textContent("+1000") // floating  text content
                            .offsetX(-100) // the x offset  relate to the attached view
                            .offsetY(-100) // the y offset  relate to the attached view
                            // .floatingAnimatorEffect(FloatingAnimator) // floating animation
                            // .floatingPathEffect(FloatingPathEffect) // floating path
                            .build();
                    floatingText.attach2Window();
                    floatingText.startFloating(addImg);

                    addSubscriber = new Subscriber<Integer>() {
                        @Override
                        public void onCompleted() {
                        }

                        @Override
                        public void onError(Throwable e) {
                        }

                        @Override
                        public void onNext(Integer integer) {
                            centerWave.setAmplitudeRatio(10);
                        }
                    };
                    Observable.create(new Observable.OnSubscribe<Integer>() {
                        @Override
                        public void call(Subscriber<? super Integer> subscriber) {
                            subscriber.onNext(10);
                        }
                    }).delay(1, TimeUnit.SECONDS).subscribeOn(AndroidSchedulers.mainThread())
                            .observeOn(AndroidSchedulers.mainThread()).subscribe(addSubscriber);
                }
                break;
            case R.id.buy_btn:
                //没有登录请登录
                if (Common.userInfo != null) {
                    if (productList != null) {
                        Intent intent = new Intent(getActivity(), ProductItemActivity.class);
                        Bundle bundle = new Bundle();
                        int money = Integer.valueOf(centerWave.getCenterTitle());
                        bundle.putParcelable("product_list", productList);
                        bundle.putInt("product_money", money);
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                } else {
                    startActivity(new Intent(getActivity(), LoginActivity.class));
                }
                break;
        }
    }


    private void getPeoductItemData() {
        if (!OkHttpUtils.isNetworkAvailable(getActivity())) {
            getNoWebHotProduct();
            //Toast.makeText(getActivity(), "暂时没有可用的网络", Toast.LENGTH_SHORT).show();
            return;
        }
        Gson gson = new Gson();
        ArrayMap<String, Object> map = new ArrayMap<>();
        ArrayMap<String, String> map2 = new ArrayMap<>();
//        HashMap<String, Object> map3 = new HashMap<>();
        ArrayMap<String, Object> map3 = new ArrayMap<>();


        map2.put("currentPage", "1");
        map2.put("pageSize", "1");
        map2.put("queryAll", "false");

        map3.put("isHot", "1");
        map3.put("type", "1");
        map3.put("pageParams", map2);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map3);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, getContext());
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.GetAppWebsiteProductListUrl + RequestURL.CreatRequestUrl(mapjson));
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (receiver != null) {
            getActivity().unregisterReceiver(receiver);
        }
        if (addSubscriber != null && addSubscriber.isUnsubscribed()) {
            addSubscriber.unsubscribe();
        }
        if (decreaseSubscriber != null && decreaseSubscriber.isUnsubscribed()) {
            decreaseSubscriber.unsubscribe();
        }
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
    }
}
