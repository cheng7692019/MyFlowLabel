package chen.anew.com.zhujiang.fragment;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.greenrobot.greendao.query.Query;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.MyApp;
import chen.anew.com.zhujiang.activity.main.MessageActivity;
import chen.anew.com.zhujiang.activity.web.WebViewActivity;
import chen.anew.com.zhujiang.adpter.ExerciseAdpter;
import chen.anew.com.zhujiang.base.BaseFragment;
import chen.anew.com.zhujiang.bean.ActivityBean;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.greendao.Activity_List;
import chen.anew.com.zhujiang.greendao.MessageBean;
import chen.anew.com.zhujiang.greendao.MessageBeanDao;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.OkHttpUtils;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.pullrefresh.layout.BaseFooterView;
import chen.anew.com.zhujiang.pullrefresh.layout.BaseHeaderView;
import chen.anew.com.zhujiang.pullrefresh.layout.PullRefreshLayout;
import chen.anew.com.zhujiang.rxandroid.RecyclerViewSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import me.zhanghai.android.materialprogressbar.IndeterminateProgressDrawable;

/**
 * Created by thinkpad on 2016/6/30.
 */

public class ExerciseFragment extends BaseFragment implements BaseHeaderView.OnRefreshListener, BaseFooterView.OnLoadListener{

    @Bind(R.id.message_exercise_imgbtn)
    ImageView messageExerciseImgbtn;
    @Bind(R.id.recyclerview)
    RecyclerView mRecyclerView;
    @Bind(R.id.root)
    PullRefreshLayout pullRefreshLayout;
    @Bind(R.id.header)
    BaseHeaderView headerView;
    @Bind(R.id.footer)
    BaseFooterView footerView;
    @Bind(R.id.no_policy)
    ImageView no_policy;
    @Bind(R.id.progress_bar)
    ProgressBar progressBar;

    @Bind(R.id.view_line_1)
    View view_line_1;

    private RecyclerViewSubscriber recyclerViewSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private ArrayList<Activity_List> allActivityList;
    private int mcurrentPage= 1;
    private ExerciseAdpter exerciseAdpter;
    private MessageHintReceiver receiver;

    public static ExerciseFragment newInstance() {
        ExerciseFragment exerciseFragment = new ExerciseFragment();
        return exerciseFragment;
    }

    @Override
    protected void initViews() {
        mPageName="ExerciseFragment";
        initToolBar();
        view_line_1.bringToFront();
        IndeterminateProgressDrawable indeterminateProgressDrawable = new IndeterminateProgressDrawable(getActivity());
        indeterminateProgressDrawable.setTint(getActivity().getResources().getColor(R.color.colorAccent));
        progressBar.setProgressDrawable(indeterminateProgressDrawable);
        progressBar.setIndeterminateDrawable(indeterminateProgressDrawable);
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                //Loaddialog.getInstance().dissLoading();
                Gson gson=new Gson();
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String resultCode = jsonObject.getString("resultCode");
                    if("1".equals(resultCode)){
                        //成功获得活动列表
                        // JSONObject jsonObject = new JSONObject(result)
                        List<ActivityBean> activityList = gson.fromJson(jsonObject.getString("activity"), new TypeToken<ArrayList<ActivityBean>>() {
                        }.getType());
                        List<Activity_List> activity_List;
                        ActivityBean activityBean;
                        for(int i=0;i<activityList.size();i++){
                            activityBean=activityList.get(i);
                            activity_List=activityBean.getActivity_List();
                            allActivityList.add(new Activity_List(activityBean.getActivity_month(),"-1"));
                            allActivityList.addAll(activity_List);
                        }
                        //初始化列表
                        if(mcurrentPage==1){
                            if (activityList != null && activityList.size() + 1<5) {
                                pullRefreshLayout.setHasFooter(false);
                            }else{
                                pullRefreshLayout.setHasFooter(true);
                            }
                            exerciseAdpter.updateView(allActivityList);
                        }else{
                            //加载更多
                            if(activityList!=null&&activityList.size()+1<5){
                                pullRefreshLayout.setHasFooter(false);
                            }else{
                                pullRefreshLayout.setHasFooter(true);
                            }
                            footerView.stopLoad();
                            exerciseAdpter.updateView(allActivityList);
                        }
                    }else{
                        pullRefreshLayout.setHasFooter(false);
                        footerView.stopLoad();
                        if(allActivityList.size()==0){
                            no_policy.setVisibility(View.GONE);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        initReview();
        //注册广播
        receiver = new MessageHintReceiver();
        IntentFilter filter = new IntentFilter("CHEN.COM.MESSAGE_HINT_ACTION");
        getActivity().registerReceiver(receiver, filter);
    }

    @OnClick(R.id.relative_exercise_left)
    public void onClick() {
        startActivity(new Intent(getActivity(), MessageActivity.class));
    }

    public class MessageHintReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            int img_red = intent.getIntExtra("img_red", -1);
            if (img_red == 1) {
                messageExerciseImgbtn.setImageResource(R.mipmap.message_red);
            } else if (img_red == 0) {
                messageExerciseImgbtn.setImageResource(R.mipmap.new_message);
            }
        }
    }

    private void initToolBar() {
        //判断是否存在未读的消息
        MessageBeanDao messageBeanDao = MyApp.daoSession.getMessageBeanDao();
        Query query = messageBeanDao.queryBuilder().where(
                MessageBeanDao.Properties.CustomerId.eq(Common.customer_id), MessageBeanDao.Properties.IsRead.eq("N"))
                .build();
        List<MessageBean> messageList = (List<MessageBean>) query.list();
        if (messageList != null & messageList.size() > 0) {
            messageExerciseImgbtn.setImageResource(R.mipmap.message_red);
        }else{
            messageExerciseImgbtn.setImageResource(R.mipmap.new_message);
        }
    }

    private void initReview(){
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(layoutManager);

        allActivityList = new ArrayList<>();
        exerciseAdpter = new ExerciseAdpter(allActivityList,getContext());
        mRecyclerView.setAdapter(exerciseAdpter);
        headerView.setOnRefreshListener(this);
        footerView.setOnLoadListener(this);

        exerciseAdpter.setOnItemClickListener(new ExerciseAdpter.ClickListener() {
            @Override
            public void onItemClick(int position, View v) {
                Activity_List activity_list = allActivityList.get(position);
                Intent intent=new Intent(getActivity(), WebViewActivity.class);
                intent.putExtra("title","活动详情");
                intent.putExtra("url",activity_list.getActivity_url());
                //intent.putExtra("url","http://waptest.prlife.com.cn:9001/rcms/app/appweb/index.html?plat=2#productdetail/0090_main");
                startActivity(intent);
              /* new FinestWebView.Builder(getContext())
                        .theme(R.style.FinestWebViewTheme)
                        .gradientDivider(false)
//                        .injectJavaScript("JavaScriptObject")
                        .show(activity_list.getActivity_url());*/
            }
        });
        getActivitiesData(mcurrentPage);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (recyclerViewSubscriber != null && recyclerViewSubscriber.isUnsubscribed()) {
            recyclerViewSubscriber.unsubscribe();
        }
        if (receiver != null) {
            getActivity().unregisterReceiver(receiver);
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.frament_exercise_recyclerview;
    }


    private void getActivitiesData(int mcurrentPage) {
        if (!OkHttpUtils.isNetworkAvailable(getActivity())) {
            if (headerView != null) {
                headerView.stopRefresh();
            }
            pullRefreshLayout.setHasFooter(false);
            Toast.makeText(getActivity(), "暂时没有可用的网络", Toast.LENGTH_SHORT).show();
            return;
        }
        if (mcurrentPage == 1) {
            allActivityList.clear();
        }
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        HashMap<String, Object> map3 = new HashMap<>();

        map2.put("currentPage", mcurrentPage+"");
        map2.put("pageSize","5");
        map2.put("queryAll","false");
        map3.put("pageParams",map2);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map3);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        recyclerViewSubscriber = new RecyclerViewSubscriber(subscriberOnNextListener, getActivity(), headerView, footerView, progressBar);
        OkHttpObservable.getInstance().getData(recyclerViewSubscriber, RequestURL.GetAppActivityListUrl + RequestURL.CreatRequestUrl(mapjson));
    }

    @Override
    public void onLoad(BaseFooterView baseFooterView) {
        mcurrentPage=mcurrentPage+1;
        getActivitiesData(mcurrentPage);
    }

    @Override
    public void onRefresh(BaseHeaderView baseHeaderView) {
        mcurrentPage = 1;
        getActivitiesData(mcurrentPage);
    }
}
