package chen.anew.com.zhujiang.activity.mine;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.Bind;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.adpter.OrderAdpter;
import chen.anew.com.zhujiang.base.BaseFragment;
import chen.anew.com.zhujiang.bean.OrderList;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.OkHttpUtils;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.pullrefresh.layout.BaseFooterView;
import chen.anew.com.zhujiang.pullrefresh.layout.BaseHeaderView;
import chen.anew.com.zhujiang.pullrefresh.layout.PullRefreshLayout;
import chen.anew.com.zhujiang.rxandroid.RecyclerViewSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import me.zhanghai.android.materialprogressbar.IndeterminateProgressDrawable;

/**
 * Created by thinkpad on 2016/7/10.
 */
public class OrderFragment extends BaseFragment  implements BaseHeaderView.OnRefreshListener, BaseFooterView.OnLoadListener{

    @Bind(R.id.recyclerview)
    RecyclerView mRecyclerView;
    @Bind(R.id.root)
    PullRefreshLayout pullRefreshLayout;
    @Bind(R.id.header)
    BaseHeaderView headerView;
    @Bind(R.id.footer)
    BaseFooterView footerView;
    @Bind(R.id.no_policy)
    ImageView no_policy;
    @Bind(R.id.progress_bar)
    ProgressBar progressBar;

    private String orderStatus;
    private RecyclerViewSubscriber recyclerViewSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private ArrayList<OrderList> orderLists;
    private int mcurrentPage = 1;
    private OrderAdpter orderAdpter;

    public static boolean nomore = false;
    public static boolean isorderSuccess=false;

    public static OrderFragment newInstance(Bundle args) {
        OrderFragment orderFragment = new OrderFragment();
        orderFragment.setArguments(args);
        return orderFragment;
    }

    @Override
    protected void initViews() {
        mPageName="OrderFragment";
        Bundle bundle = getArguments();
        orderStatus = bundle.getString("orderStatus");
        IndeterminateProgressDrawable indeterminateProgressDrawable = new IndeterminateProgressDrawable(getActivity());
        indeterminateProgressDrawable.setTint(getActivity().getResources().getColor(R.color.colorAccent));
        progressBar.setProgressDrawable(indeterminateProgressDrawable);
        progressBar.setIndeterminateDrawable(indeterminateProgressDrawable);
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg", "-result-" + result);
                Gson gson = new Gson();
                if (!TextUtils.isEmpty(result)) {
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        // String resultCode = jsonObject.getString("resultCode");
                        //成功获得活动列表
//                        JSONObject jsonObject = new JSONObject(result)
                        ArrayList<OrderList> nowOrderList = gson.fromJson(jsonObject.getString("orderList"), new TypeToken<ArrayList<OrderList>>() {
                        }.getType());
                        //初始化列表
                        orderLists.addAll(nowOrderList);
                        if (mcurrentPage == 1) {
                            if (nowOrderList != null && nowOrderList.size() + 1 <5) {
                                pullRefreshLayout.setHasFooter(false);
                            }else{
                                pullRefreshLayout.setHasFooter(true);
                            }
                            orderAdpter.updateView(orderLists);
                        } else {
                            //加载更多
                            if (nowOrderList != null && nowOrderList.size() + 1 < 5) {
                                pullRefreshLayout.setHasFooter(false);
                            } else {
                                pullRefreshLayout.setHasFooter(true);
                            }
                            footerView.stopLoad();
                            orderAdpter.updateView(orderLists);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    pullRefreshLayout.setHasFooter(false);
                    footerView.stopLoad();
                    if (orderLists.size()==0) {
                        no_policy.setVisibility(View.VISIBLE);
                    }
                }
            }

        };
        initReview();
    }
    @Override
    public void onResume() {
        super.onResume();
        if(isorderSuccess){
            mcurrentPage = 1;
            orderLists.clear();
            getOrderList(mcurrentPage);
        }
    }

    private void initReview() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(layoutManager);

        orderLists = new ArrayList<>();
        orderAdpter = new OrderAdpter(orderLists, getContext());
        mRecyclerView.setAdapter(orderAdpter);
        headerView.setOnRefreshListener(this);
        footerView.setOnLoadListener(this);
        orderAdpter.setOnItemClickListener(new OrderAdpter.ClickListener() {
            @Override
            public void onItemClick(int position, View v) {
                OrderList orderList = orderLists.get(position);
                Intent intent = new Intent(getActivity(), OrderItemActivity.class);
                intent.putExtra("orderNo", orderList.getOrderNo());
                intent.putExtra("orderStatus", orderList.getOrderStatus());
                startActivity(intent);
                MyLogUtil.i("click", "-activity_list-" + orderList.toString());
            }
        });
        getOrderList(mcurrentPage);
    }

    @Override
    protected int getContentViewId() {
        return R.layout.common_new_recyclerview;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (recyclerViewSubscriber != null && recyclerViewSubscriber.isUnsubscribed()) {
            recyclerViewSubscriber.unsubscribe();
        }
        isorderSuccess=false;
    }

    private void getOrderList(int currentPage) {
        if(!OkHttpUtils.isNetworkAvailable(getActivity())){
            if(headerView!=null){
                headerView.stopRefresh();
            }
            pullRefreshLayout.setHasFooter(false);
            Toast.makeText(getActivity(),"暂时没有可用的网络",Toast.LENGTH_SHORT).show();
            return;
        }
        if(currentPage==1){
            orderLists.clear();
        }
        Gson gson = new Gson();
//       -json-{"orderType":"32","platType":"3","requestObject":{"mobile":null,"password":"123456","user":"13888888888"}}
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        HashMap<String, Object> map3 = new HashMap<>();
        map2.put("queryAll", "false");
        map2.put("currentPage", "" + currentPage);
        map2.put("pageSize", "5");

        map3.put("customerId", Common.userInfo.getCustomerId());
        map3.put("orderStatus", orderStatus);
        map3.put("pageParams", map2);

        map.put("orderType", 32);
        map.put("platType", 3);
        map.put("requestObject", map3);

        String mapjson = gson.toJson(map);
        //Log.i("msg","-mapjson-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        recyclerViewSubscriber = new RecyclerViewSubscriber(subscriberOnNextListener, getActivity(),headerView,footerView,progressBar);
        OkHttpObservable.getInstance().getData(recyclerViewSubscriber, RequestURL.GetOrderListUrl + RequestURL.CreatRequestUrl(mapjson));

    }

    @Override
    public void onLoad(BaseFooterView baseFooterView) {
        mcurrentPage = mcurrentPage + 1;
        footerView.startLoad();
        getOrderList(mcurrentPage);
    }

    @Override
    public void onRefresh(BaseHeaderView baseHeaderView) {
        mcurrentPage = 1;
        getOrderList(mcurrentPage);
    }
}
