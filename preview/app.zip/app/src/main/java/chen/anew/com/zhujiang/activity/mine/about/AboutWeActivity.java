package chen.anew.com.zhujiang.activity.mine.about;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.support.v4.app.NotificationCompat;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.google.gson.Gson;

import java.io.File;
import java.text.DecimalFormat;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.bean.VersionBean;
import chen.anew.com.zhujiang.net.DownloadFile;
import chen.anew.com.zhujiang.net.DownloadFileUrlConnectionImpl;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.ViewUtils;
import chen.anew.com.zhujiang.widget.Loaddialog;

/**
 * Created by thinkpad on 2016/7/22.
 */
public class AboutWeActivity extends BaseAppActivity implements DownloadFile.Listener {

    @Bind(R.id.toolbar)
    Toolbar toolbar;

    @Bind(R.id.version_description_relative)
    RelativeLayout versionDescriptionRelative;

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;
    private DownloadFile downloadFile;
    //private MaterialDialog dialog;
    private int notifyId = 100;
    private NotificationManager mNotifyManager;
    private NotificationCompat.Builder mBuilder;


    @Override
    protected void initViews() {
        initToolBar();
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                if (!TextUtils.isEmpty(result)) {
                    Gson gson = new Gson();
                    VersionBean versionBean = gson.fromJson(result, VersionBean.class);
                    double flversion = Double.valueOf(ViewUtils.getVersion(AboutWeActivity.this));
                    if (flversion == Double.valueOf(versionBean.getVersion())) {
                        ViewUtils.showSnackbar(versionDescriptionRelative, "亲,已经是最新版本了",AboutWeActivity.this);
                    } else if (flversion < Double.valueOf(versionBean.getVersion())) {
                        //开始下载安装包
                        showCall(versionBean);
                    }else{
                        ViewUtils.showSnackbar(versionDescriptionRelative, "亲,已经是最新版本了",AboutWeActivity.this);
                    }
                }
            }

        };
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogSubscriber != null && dialogSubscriber.isUnsubscribed()) {
            dialogSubscriber.unsubscribe();
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_about;
    }

    @OnClick({R.id.version_description_relative, R.id.help_and_feedback_relative, R.id.to_score_relative, R.id.about_pearl_river_life_relative})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.version_description_relative:
                //版本说明   请求获得最新版本号
                getRemoteSendCode();
                break;
            case R.id.help_and_feedback_relative:
                startActivity(new Intent(AboutWeActivity.this, HelpAndFeedbackActivity.class));
                break;
            case R.id.to_score_relative:
                Uri uri = Uri.parse("market://details?id=" + getPackageName());
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                break;
            case R.id.about_pearl_river_life_relative:
                startActivity(new Intent(AboutWeActivity.this, AboutPearlRiverLifeActivity.class));
                break;
        }
    }

    private void getRemoteSendCode() {
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, AboutWeActivity.this);
        OkHttpObservable.getInstance().getNoParamData(dialogSubscriber, RequestURL.VersionUrl);
    }

    @Override
    public void onSuccess(String url, String destinationPath) {
        //成功下载安装包后安装
        //Loaddialog.getInstance().dissLoading();
     /*   if (dialog == null) {
            dialog.dismiss();
        }*/
        mNotifyManager.cancel(notifyId);//删除一个特定的通知ID对应的通知
        Intent intent = new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setAction(android.content.Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.fromFile(new File(destinationPath)),
                "application/vnd.android.package-archive");
        startActivity(intent);
    }

    @Override
    public void onFailure(Exception e) {
        Loaddialog.getInstance().dissLoading();
        ViewUtils.showSnackbar(versionDescriptionRelative, "" + e.getMessage(), AboutWeActivity.this);
    }

    @Override
    public void onProgressUpdate(int progress, int total) {
        if (progress!= total) {
            mBuilder.setProgress(total, progress, false);
            mBuilder.setContentText("下载进度："+getPercent(progress,total));
            mBuilder.setDefaults(Notification.DEFAULT_LIGHTS);
            mNotifyManager.notify(notifyId, mBuilder.build());
        }
       /* if (dialog == null) {
            showDiaolog(total);
        } else {
            if (dialog.getCurrentProgress() != dialog.getMaxProgress()) {
                dialog.setProgress(progress);
            } else {
                dialog.dismiss();
            }
        }*/
    }


    public String getPercent(int x,int y){
        String baifenbi="";//接受百分比的值
        double baiy=x*1.0;
        double baiz=y*1.0;
        double fen=baiy/baiz;
        //NumberFormat nf   =   NumberFormat.getPercentInstance();     注释掉的也是一种方法
        //nf.setMinimumFractionDigits( 2 );        保留到小数点后几位
        DecimalFormat df1 = new DecimalFormat("##.00%");    //##.00%   百分比格式，后面不足2位的用0补齐
        //baifenbi=nf.format(fen);
        baifenbi= df1.format(fen);
        if(".00%".equals(baifenbi)){baifenbi="0%";}
        if("100.00%".equals(baifenbi)){baifenbi="100%";}
        if(baifenbi.endsWith(".00%")){baifenbi=baifenbi.substring(0, baifenbi.length()-4)+"%";} //if去0
        return baifenbi;
    }

    private void showProgressNotification() {
        mNotifyManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        mBuilder = new NotificationCompat.Builder(AboutWeActivity.this);
        mBuilder.setContentTitle(getString(R.string.app_name))
                .setContentText("正在下载中...")
                .setContentIntent(getDefalutIntent(Notification.FLAG_AUTO_CANCEL)) //设置通知栏点击意图
                .setWhen(System.currentTimeMillis())
                .setPriority(Notification.PRIORITY_DEFAULT) //设置该通知优先级
                //.setAutoCancel(true)//设置这个标志当用户单击面板就可以让通知将自动取消
                .setOngoing(false)//ture，设置他为一个正在进行的通知。他们通常是用来表示一个后台任务,用户积极参与(如播放音乐)或以某种方式正在等待,因此占用设备(如一个文件下载,同步操作,主动网络连接)
                .setDefaults(Notification.DEFAULT_ALL)
                .setSmallIcon(R.mipmap.min_logo);//设置通知小ICON
        mNotifyManager.notify(notifyId, mBuilder.build());
    }

    private PendingIntent getDefalutIntent(int flags) {
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 1, new Intent(), flags);
        return pendingIntent;
    }


    private void showCall(final VersionBean versionBean) {
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.set_dialgo,
                (ViewGroup)findViewById(R.id.setdia_linear));
        final Button cacle_btn = (Button) layout.findViewById(R.id.cacle_btn);
        final Button setpaypass_btn = (Button) layout.findViewById(R.id.setpaypass_btn);
        final TextView content_tv = (TextView) layout.findViewById(R.id.content_tv);
        content_tv.setText(R.string.version_content);
        cacle_btn.setText(R.string.next_confirm);
        setpaypass_btn.setText(R.string.cancle);
        final MaterialDialog materialDialog = new MaterialDialog.Builder(this)
                .title(R.string.check_version)
                .customView(layout, true)
                .show();
        cacle_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                materialDialog.dismiss();
                //开始下载
                showProgressNotification();
                downloadFile = new DownloadFileUrlConnectionImpl(AboutWeActivity.this, new Handler(), AboutWeActivity.this);
                downloadFile.download(versionBean.getUrl(), new File(getExternalFilesDir("zhujiang"), "zhujiang_apk").getAbsolutePath());
            }
        });
        setpaypass_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //设置
                materialDialog.dismiss();
            }
        });
    }

   /* private void showDiaolog(int total) {
        dialog = new MaterialDialog.Builder(this)
                .title(R.string.progress_dialog)
                .content(R.string.please_wait)
                .progress(false, total, true)
                .show();
    }*/
}
