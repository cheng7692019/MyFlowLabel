package chen.anew.com.zhujiang.activity.product;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.google.gson.Gson;
import com.tencent.mm.sdk.openapi.BaseReq;
import com.tencent.mm.sdk.openapi.BaseResp;
import com.tencent.mm.sdk.openapi.ConstantsAPI;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.sdk.openapi.SendMessageToWX;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.tencent.mm.sdk.openapi.WXMediaMessage;
import com.tencent.mm.sdk.openapi.WXWebpageObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.web.JavaScriptObject;
import chen.anew.com.zhujiang.activity.web.NoScrollWebViewFragment;
import chen.anew.com.zhujiang.activity.web.WebViewFragment;
import chen.anew.com.zhujiang.adpter.FragmentAdapter;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.bean.SecurityProduct;
import chen.anew.com.zhujiang.bean.ShareList;
import chen.anew.com.zhujiang.net.OkHttpObservable;
import chen.anew.com.zhujiang.net.RequestURL;
import chen.anew.com.zhujiang.rxandroid.DialogSubscriber;
import chen.anew.com.zhujiang.rxandroid.SubscriberOnNextListener;
import chen.anew.com.zhujiang.utils.ImageTool;
import chen.anew.com.zhujiang.utils.MobclickAgentUtil;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.utils.VerifyUtil;

/**
 * Created by thinkpad on 2016/7/25.
 */
public class SecurityDetailsActivity extends BaseAppActivity implements IWXAPIEventHandler {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.top_fragment)
    FrameLayout topFragment;
    @Bind(R.id.double_scroll_top_view)
    ScrollView doubleScrollTopView;
    @Bind(R.id.tabs)
    TabLayout tabs;
    @Bind(R.id.double_scroll_bottom_view)
    ViewPager viewPager;

    private List<String> titles;
    private List<Fragment> fragments;

    private String urlPath = RequestURL.ESERVICE_9001+"/rcms/app/appweb/index.html?#productdetail/";

    public JavaScriptObject jso;
    private String status, itemCode;

//    private String environment = "http://eservicewapuat.prlife.com.cn:9001";
    private String path = "/rcms/app/appweb/index.html?plat=2";
    private String paremt = "#accidentInsurance/accident";

    private DialogSubscriber dialogSubscriber;
    private SubscriberOnNextListener<String> subscriberOnNextListener;

    private IWXAPI api;
    //wxa90e2b215715e812
    private static final String APP_ID = "wxa90e2b215715e812";
    private ShareList shareList;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.product_detail));
        initToolBar();
        //关闭activity DurationTrack
        MobclickAgentUtil.closeActivityDurationTrack(this);
        // Bundle bundle = getIntent().getExtras();
        status = getIntent().getStringExtra("status");
        itemCode = getIntent().getStringExtra("itemCode");

        jso = new JavaScriptObject(this);
        jso.itemCode = itemCode;
        jso.status = status;
        //String status = productList.getStatus();
        Bundle webbundle = new Bundle();
        webbundle.putString("url", RequestURL.ESERVICE_9001 + path + "&itemCode=" + itemCode + "&status=" + status+paremt);
        changeFragment(R.id.top_fragment, NoScrollWebViewFragment.newInstance(webbundle));
        /*if("05".equals(status)|"06".equals(status)){
            //已下架或售罄
            changeFragment(R.id.top_fragment,OffLoadingProItemTopHalf.newInstance(bundle));
        }else{
            changeFragment(R.id.top_fragment,ProductItemTopHalf.newInstance(bundle));
        }*/
        titles = new ArrayList<>();
        fragments = new ArrayList<>();
        titles.add(getString(R.string.product_detail));
        titles.add(getString(R.string.important_inform));
        titles.add(getString(R.string.information_disclosure));

        for (int i = 0; i < titles.size(); i++) {
            tabs.addTab(tabs.newTab().setText(titles.get(i)));
        }

        //微信初始化
        api = WXAPIFactory.createWXAPI(this, APP_ID, true);
        // 将该app注册到微信
        api.registerApp(APP_ID);
        //获取产品详情
        subscriberOnNextListener = new SubscriberOnNextListener<String>() {
            @Override
            public void onNext(String result) {
                MyLogUtil.i("msg","-result-"+result);
                Gson gson=new Gson();
                try {
                    JSONObject jsonObject=new JSONObject(result);
                    String resultMessage=jsonObject.getString("resultMessage");
                    String resultCode=jsonObject.getString("resultCode");
                    if("0".equals(resultCode)){
                        Toast.makeText(SecurityDetailsActivity.this,resultMessage,Toast.LENGTH_SHORT).show();
                    }else  if("1".equals(resultCode)){
                        SecurityProduct securityProduct=gson.fromJson(jsonObject.getString("productInfo"),SecurityProduct.class);
                        List<ShareList> shareLists = securityProduct.getShareList();
                        if(shareLists!=null&&shareLists.size()>0){
                            shareList=shareLists.get(0);
                        }
                        initViewpage(securityProduct.getProductCode());
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        getProductItem();
    }

    private void initViewpage(String productCode){
        Bundle mainbundle = new Bundle();
        //mainbundle.putString("url", urlPath + productCode + "_main");
        StringBuffer stringBuffer=new StringBuffer(urlPath);
        stringBuffer.append(productCode).append("_main");
        if(stringBuffer.toString().contains("?")){
            stringBuffer.insert(stringBuffer.toString().indexOf("?")+1,"plat=2");
        }
        mainbundle.putString("url", stringBuffer.toString());
        MyLogUtil.i("msg","-mainbundle-"+urlPath + productCode + "_main");
        MyLogUtil.i("msg","-stringBuffer-"+stringBuffer.toString());
        Bundle noticebundle = new Bundle();
        noticebundle.putString("url", urlPath + productCode+ "_notice");
        Bundle infobundle = new Bundle();
        infobundle.putString("url", urlPath + productCode + "_info");
        if ("05".equals(status) | "06".equals(status)) {
            //已下架或售罄
            Bundle bundle_bottom = new Bundle();
            bundle_bottom.putString("status", status);
          /*  fragments.add(OffLoadingProItemBottomHalf.newInstance(bundle_bottom));
            fragments.add(OffLoadingProItemBottomHalf.newInstance(bundle_bottom));
            fragments.add(OffLoadingProItemBottomHalf.newInstance(bundle_bottom));*/
            fragments.add(WebViewFragment.newInstance(mainbundle));
            fragments.add(WebViewFragment.newInstance(noticebundle));
            fragments.add(WebViewFragment.newInstance(infobundle));
        } else {
            fragments.add(WebViewFragment.newInstance(mainbundle));
            fragments.add(WebViewFragment.newInstance(noticebundle));
            fragments.add(WebViewFragment.newInstance(infobundle));
        }

        FragmentAdapter mFragmentAdapteradapter =
                new FragmentAdapter(getSupportFragmentManager(), fragments, titles);
        //给ViewPager设置适配器
        viewPager.setAdapter(mFragmentAdapteradapter);
        //2.MODE_FIXED模式
        tabs.setTabMode(TabLayout.MODE_FIXED);
        //将TabLayout和ViewPager关联起来。
        tabs.setupWithViewPager(viewPager);
        //给TabLayout设置适配器
        tabs.setTabsFromPagerAdapter(mFragmentAdapteradapter);
    }

    private void changeFragment(int id, Fragment targetFragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(id, targetFragment, "fragment")
                .setTransitionStyle(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                .commit();
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @OnClick(R.id.share_iv)
    public void onClick() {
        //显示微信分享对话框
        showShare();
    }

    //显示分享对话框
    private void showShare() {
        LayoutInflater inflater = this.getLayoutInflater();
        View layout = inflater.inflate(R.layout.share_dialgo,
                (ViewGroup) this.findViewById(R.id.share_linear));
        final ImageView weixinhaoyou_btn = (ImageView) layout.findViewById(R.id.weixinhaoyou_btn);
        final ImageView weixinfreind_btn = (ImageView) layout.findViewById(R.id.weixinfreind_btn);
        final Button cacle_btn = (Button) layout.findViewById(R.id.cacle_btn);
        final MaterialDialog materialDialog = new MaterialDialog.Builder(this)
                .title(R.string.share_to)
                .customView(layout, true)
                .show();
        weixinhaoyou_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //微信好友
                materialDialog.dismiss();
                if(shareList==null){
                    Toast.makeText(SecurityDetailsActivity.this,"该产品不允许分享",Toast.LENGTH_SHORT).show();
                }else{
                    if(VerifyUtil.isWXAppInstalledAndSupported(SecurityDetailsActivity.this,api)){
                        sendWeixinPYQ(false);
                    }else{
                        Toast.makeText(SecurityDetailsActivity.this,"未安装微信不能分享",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        weixinfreind_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //微信朋友圈
                materialDialog.dismiss();
                if(shareList==null){
                    Toast.makeText(SecurityDetailsActivity.this,"该产品不允许分享",Toast.LENGTH_SHORT).show();
                }else {
                    if (VerifyUtil.isWXAppInstalledAndSupported(SecurityDetailsActivity.this, api)) {
                        sendWeixinPYQ(true);
                    }else{
                        Toast.makeText(SecurityDetailsActivity.this,"未安装微信不能分享",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        cacle_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                materialDialog.dismiss();
            }
        });
    }

    private void sendWeixinPYQ(boolean isTimeLine) {
        WXWebpageObject webpage = new WXWebpageObject();
        webpage.webpageUrl = shareList.getDataUrl();
        WXMediaMessage msg = new WXMediaMessage(webpage);
        msg.title = shareList.getTitle();
        msg.description = shareList.getShareDesc();
        //Bitmap thumb = BitmapFactory.decodeResource(getResources(), R.mipmap.logo_32);
        // msg.thumbData = Util.bmpToByteArray(thumb, true);
        Bitmap thumb = ImageTool.drawableToBitmap(ContextCompat.getDrawable(this,R.mipmap.min_logo));
        try {
            msg.thumbData=ImageTool.compressImage(thumb);
        } catch (IOException e) {
            e.printStackTrace();
        }
        SendMessageToWX.Req req = new SendMessageToWX.Req();
        req.transaction = buildTransaction("webpage");
        req.message = msg;
        if (isTimeLine) {
            req.scene = SendMessageToWX.Req.WXSceneTimeline;
        } else {
            req.scene = SendMessageToWX.Req.WXSceneSession;
        }
        api.sendReq(req);
    }

    private String buildTransaction(final String type) {
        return (type == null) ? String.valueOf(System.currentTimeMillis()) : type + System.currentTimeMillis();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(dialogSubscriber!=null&&dialogSubscriber.isUnsubscribed()){
            dialogSubscriber.unsubscribe();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        api.handleIntent(intent, this);
    }

    @Override
    public void onReq(BaseReq baseReq) {
        switch (baseReq.getType()) {
            case ConstantsAPI.COMMAND_GETMESSAGE_FROM_WX:
//                goToShowMsg((ShowMessageFromWX.Req) baseReq);
                break;
            case ConstantsAPI.COMMAND_SHOWMESSAGE_FROM_WX:
//                goToShowMsg((ShowMessageFromWX.Req) baseReq);
                break;
            default:
                break;
        }
    }

    @Override
    public void onResp(BaseResp baseResp) {
        int result = 0;
        switch (baseResp.errCode) {
            case BaseResp.ErrCode.ERR_OK:
                result = R.string.errcode_success;
                break;
            case BaseResp.ErrCode.ERR_USER_CANCEL:
                result = R.string.errcode_cancel;
                break;
            case BaseResp.ErrCode.ERR_AUTH_DENIED:
                result = R.string.errcode_deny;
                break;
            default:
                result = R.string.errcode_unknown;
                break;
        }
        Toast.makeText(this, getResources().getString(result), Toast.LENGTH_LONG).show();
    }


    private void getProductItem() {
        Gson gson = new Gson();
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();

        map2.put("itemCode", itemCode);

        map.put("orderType", "32");
        map.put("platType", "3");
        map.put("requestObject", map2);
        String mapjson = gson.toJson(map);
        MyLogUtil.i("msg","-ProductIntroduction-"+mapjson);
        //OkHttpUtils.getLogin(RequestURL.CreatRequestUrl(gson.toJson(map)));
        dialogSubscriber = new DialogSubscriber(subscriberOnNextListener, SecurityDetailsActivity.this);
        OkHttpObservable.getInstance().getData(dialogSubscriber, RequestURL.getProductIntroductionUrl + RequestURL.CreatRequestUrl(mapjson));
    }


    @Override
    protected int getContentViewId() {
        return R.layout.activity_product_item;
    }

}
