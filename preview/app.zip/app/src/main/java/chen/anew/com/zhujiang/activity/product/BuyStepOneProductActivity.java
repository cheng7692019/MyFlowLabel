package chen.anew.com.zhujiang.activity.product;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.anton46.stepsview.StepsView;
import com.bigkoo.pickerview.OptionsPickerView;
import com.bigkoo.pickerview.TimePickerView;
import com.umeng.analytics.MobclickAgent;

import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.bean.CityVo;
import chen.anew.com.zhujiang.bean.OccupationVo;
import chen.anew.com.zhujiang.bean.ProvinceVo;
import chen.anew.com.zhujiang.bean.SerializableMap;
import chen.anew.com.zhujiang.common.Common;
import chen.anew.com.zhujiang.greendao.ProductList;
import chen.anew.com.zhujiang.utils.MyLogUtil;
import chen.anew.com.zhujiang.utils.TxtReader;
import chen.anew.com.zhujiang.utils.VerifyUtil;

/**
 * Created by thinkpad on 2016/7/5.
 */
public class BuyStepOneProductActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.right_tv_title)
    TextView rightTvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.stepsView)
    StepsView stepsView;
    @Bind(R.id.policyholder_relative)
    RelativeLayout policyholderRelative;
    @Bind(R.id.username)
    EditText username;
    @Bind(R.id.identification_et)
    EditText identificationEt;       //identificationEt phoneEt emailCodeEt emailCodeEt
    @Bind(R.id.phone_et)
    EditText phoneEt;
    @Bind(R.id.email_code_et)
    EditText emailCodeEt;
    @Bind(R.id.post_code_et)
    EditText postCodeEt;
    @Bind(R.id.startime_btn)
    Button startimeBtn;
    @Bind(R.id.endtime_btn)
    Button endtimeBtn;
    @Bind(R.id.ischangqi_rb)
    RadioButton ischangqiRb;
    @Bind(R.id.selectprovince_btn)
    Button selectprovinceBtn;
    @Bind(R.id.areadetail_et)
    EditText areadetailEt;
    @Bind(R.id.industrychoice_btn)
    Button industrychoiceBtn;
    @Bind(R.id.annualincome_et)
    EditText annualincomeEt;
    @Bind(R.id.next_btn)
    Button nextBtn;
    @Bind(R.id.policyholdergone_linear)
    LinearLayout policyholdergoneLinear;
    @Bind(R.id.rotate_img)
    ImageView rotateImg;
    //保障购买流程用到的
    @Bind(R.id.effectivedate_cardview)
    CardView effectivedate_cardview;
    @Bind(R.id.effectivedate_linear)
    LinearLayout effectivedateLinear;
    @Bind(R.id.effectivedate_relative)
    RelativeLayout effectivedateRelative;
    @Bind(R.id.rotateone_img)
    ImageView rotateoneImg;
    @Bind(R.id.effective_date_tv)
    TextView effectiveDateTv;
    @Bind(R.id.insurance_plan_tv)
    TextView insurancePlanTv;
    @Bind(R.id.sexname_tv)
    TextView sexnameTv;

    private final String[] labels = {"", "", ""};

    private ArrayList<ProvinceVo> provinceList;
    private ArrayList<CityVo> cityList;
    private ArrayList<OccupationVo> occupationList;

    private ArrayList<String> optionsItems;
    private ArrayList<String> options1Items;
    private ArrayList<ArrayList<String>> options2Items;

    // 需要获取的值
    private ProvinceVo currentProvinceVo = null;
    private CityVo currentCityVo = null;

    private String validType = "";
    //时间选择器
    private TimePickerView pvTime;
    private String starTime, endTime;
    private Date starDate;
    private int age;
    //身份证号码
    private String IdNo, sexname, total;
    //省市id、行业岗位id
    private String provinceId, cityId, addressProvince, addressCity, occupationName, occupationCode, occupationType;
    private ProductList product_list;

    private MessageReceiver receiver;
    //保障详情页
    String itemCode, productName, productCode, totalmoney, days, startDate, endDate;

    @Override
    protected void initViews() {
        Bundle bundle = getIntent().getExtras();
        product_list =getIntent().getParcelableExtra("product_list");
        itemCode = bundle.getString("itemCode");
        if (!TextUtils.isEmpty(itemCode)) {
            //productName,productCode,totalmoney,days,begindate,endDate;
            productName = bundle.getString("productName");
            productCode = bundle.getString("productCode");
            totalmoney = bundle.getString("totalmoney");
            days = bundle.getString("days");
            startDate = bundle.getString("startDate");
            endDate = bundle.getString("endDate");
            effectivedate_cardview.setVisibility(View.VISIBLE);
            effectiveDateTv.setText(startDate);
            insurancePlanTv.setText(days);
        } else {
            effectivedate_cardview.setVisibility(View.GONE);
        }
        total = bundle.getString("total");
        rightTvTitle.setText(getResources().getString(R.string.next_step));
        tvTitle.setText(getResources().getString(R.string.input_information));
        initToolBar();

        stepsView.setLabels(labels)
                .setBarColorIndicator(getResources().getColor(R.color.chang_white))
                .setProgressColorIndicator(getResources().getColor(R.color.colorAccent))
                .setLabelColorIndicator(getResources().getColor(R.color.white))
                .setCompletedPosition(0)
                .drawView();
        //监听身份证，设置性别
        identificationEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String identification = identificationEt.getText().toString();
                if (identification.length() == 18 | identification.length() == 15) {
                    sexname = VerifyUtil.getSex(identification);
                    sexnameTv.setText(sexname);
                    age = VerifyUtil.getAge(identification);
                    if (age > 45) {
                        validType = "2";
                        ischangqiRb.setChecked(true);
                    } else {
                        validType = "1";
                        ischangqiRb.setChecked(false);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        initLocalData();
        initPresonInfo();
        //注册广播
        receiver = new MessageReceiver();
        IntentFilter filter = new IntentFilter("CHEN.COM.BUYSTEPONEPRODUCTACTIVITY");
        this.registerReceiver(receiver, filter);
    }


    public class MessageReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean flag=intent.getBooleanExtra("is_finish",false);
            if(flag){
                if(!isFinishing()){
                    finish();
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (receiver != null) {
            this.unregisterReceiver(receiver);
        }
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_stepone_buyproduct;
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }


    private void initPresonInfo() {
        if (!TextUtils.isEmpty(Common.userInfo.getRealName())) {
            username.setText(Common.userInfo.getRealName());
            username.setEnabled(false);
        }
        if (!TextUtils.isEmpty(Common.userInfo.getIdNo())) {
            identificationEt.setText(Common.userInfo.getIdNo());
            identificationEt.setEnabled(false);
        }
        if (!TextUtils.isEmpty(Common.userInfo.getMobile())) {
            phoneEt.setText(Common.userInfo.getMobile());
        }

        if (!TextUtils.isEmpty(Common.userInfo.getZip())) {
            postCodeEt.setText(Common.userInfo.getZip());
        }
        if (!TextUtils.isEmpty(Common.userInfo.getEmail())) {
            emailCodeEt.setText(Common.userInfo.getEmail());
        }
        //开始结束日期
        starTime = Common.userInfo.getValidStartDate();
        if (!TextUtils.isEmpty(starTime)) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            try {
                starDate= format.parse(starTime);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            startimeBtn.setText(starTime);
        }
        endTime = Common.userInfo.getValidEndDate();
        if (!TextUtils.isEmpty(endTime)) {
            endtimeBtn.setText(endTime);
        }
        validType = Common.userInfo.getValidType();
        if ("1".equals(validType)) {
            //指定时间
            ischangqiRb.setChecked(false);
        } else if ("2".equals(validType)) {
            //长期
            ischangqiRb.setChecked(true);
        }
        String identification = Common.userInfo.getIdNo();
        if (!TextUtils.isEmpty(identification) && (identification.length() == 18 | identification.length() == 15)) {
            sexname = VerifyUtil.getSex(identification);
            sexnameTv.setText(sexname);
            age = VerifyUtil.getAge(identification);
            if (age > 45) {
                validType = "2";
                ischangqiRb.setChecked(true);
            } else {
                validType = "1";
                ischangqiRb.setChecked(false);
            }
        }
        if (!TextUtils.isEmpty(Common.userInfo.getAddress())) {
            areadetailEt.setText(Common.userInfo.getAddress());
        }
        if (!TextUtils.isEmpty(Common.userInfo.getAnnualSalary())) {
            annualincomeEt.setText(Common.userInfo.getAnnualSalary());
        }
        //初始化省份城市
        String provinceCode = Common.userInfo.getProvince();
        String cityCode = Common.userInfo.getCity();
        if (!TextUtils.isEmpty(provinceCode) && !TextUtils.isEmpty(cityCode)) {
            // 将name作为keyword获取省名称和省的编码
            for (ProvinceVo pv : provinceList) {
                if (pv.getProvincePostCode().equals(provinceCode)) {
                    currentProvinceVo = new ProvinceVo();
                    currentProvinceVo.setProvinceName(pv
                            .getProvinceName());
                    currentProvinceVo.setProvincePostCode(pv
                            .getProvincePostCode());
                }
            }
            // 将name作为keyword获取市名称和市邮政编码
            for (CityVo cv : cityList) {
                if (cv.getCityPostCode().equals(cityCode)) {
                    currentCityVo = new CityVo();
                    currentCityVo.setCityName(cv.getCityName());
                    currentCityVo.setCityPostCode(cv.getCityPostCode());
                    currentCityVo.setProvincePostCode(cv
                            .getProvincePostCode());
                }
            }
            provinceId = currentProvinceVo.getProvincePostCode();
            cityId = currentCityVo.getCityPostCode();
            //        addressProvince,addressCity,occupationName,occupationCode;
            addressProvince = currentProvinceVo.getProvinceName();
            addressCity = currentCityVo.getCityName();
            selectprovinceBtn.setText(currentProvinceVo.getProvinceName() + currentCityVo.getCityName());
        }
        //初始化职业
        occupationCode = Common.userInfo.getOccupationCode();
        if (!TextUtils.isEmpty(occupationCode)) {
            OccupationVo occupationVo = VerifyUtil.getOccupationByoccupationCode(occupationList, occupationCode);
            if (occupationVo != null) {
                occupationCode = occupationVo.getOccupationCode();
                occupationType = occupationVo.getOccupationType();
                occupationName = occupationVo.getOccupationName();
                industrychoiceBtn.setText(occupationVo.getOccupationName());
                industrychoiceBtn.setEnabled(false);
            }
        }

    }

    private void initLocalData() {
        // 将本地res中raw文件夹中的txt转化为输入流
        provinceList = new ArrayList<ProvinceVo>();
        cityList = new ArrayList<CityVo>();
        occupationList = new ArrayList<OccupationVo>();
        optionsItems = new ArrayList<String>();
        options1Items = new ArrayList<String>();
        options2Items = new ArrayList<ArrayList<String>>();
        //选项选择器

        InputStream inputStream = getResources()
                .openRawResource(R.raw.cityinfo);
        TxtReader.getProvinceListAndCityList(inputStream, provinceList,
                cityList);

        InputStream inputStream2 = getResources().openRawResource(
                R.raw.new_occupation);
        TxtReader.getOccupationList(inputStream2,
                occupationList);
    }

    @OnClick({R.id.effectivedate_relative, R.id.policyholder_relative, R.id.startime_btn, R.id.endtime_btn, R.id.ischangqi_rb, R.id.selectprovince_btn, R.id.industrychoice_btn, R.id.right_tv_title})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.effectivedate_relative:
                int intoneVisibilit = effectivedateLinear.getVisibility();
                if (intoneVisibilit == 0) {
                    Animation animation = AnimationUtils.loadAnimation(this, R.anim.rotate_in);
                    animation.setFillAfter(true);
                    rotateoneImg.startAnimation(animation);
                    effectivedateLinear.setVisibility(View.GONE);
                } else {
                    Animation animation = AnimationUtils.loadAnimation(this, R.anim.rotate_out);
                    animation.setFillAfter(true);
                    rotateoneImg.startAnimation(animation);
                    effectivedateLinear.setVisibility(View.VISIBLE);
                }
                break;
            case R.id.policyholder_relative:
                int intVisibilit = policyholdergoneLinear.getVisibility();
                if (intVisibilit == 0) {
                    Animation animation = AnimationUtils.loadAnimation(this, R.anim.rotate_in);
                    animation.setFillAfter(true);
                    rotateImg.startAnimation(animation);
                    policyholdergoneLinear.setVisibility(View.GONE);
                } else {
                    Animation animation = AnimationUtils.loadAnimation(this, R.anim.rotate_out);
                    animation.setFillAfter(true);
                    rotateImg.startAnimation(animation);
                    policyholdergoneLinear.setVisibility(View.VISIBLE);
                }
                break;
            case R.id.startime_btn:
                //开始时间
                if ("2".equals(validType)) {
                    //长期
                    Toast.makeText(BuyStepOneProductActivity.this, "长期不用选证件有限期", Toast.LENGTH_SHORT).show();
                } else if ("1".equals(validType)) {
                    //定期
                    initStartimeBtn();
                } else {
                    //还没初始化
                    IdNo = identificationEt.getText().toString();
                    if (TextUtils.isEmpty(IdNo)) {
                        Toast.makeText(BuyStepOneProductActivity.this, "请先填写个人信息", Toast.LENGTH_SHORT).show();
                    } else {
                        if (ischangqiRb.isChecked()) {
                            Toast.makeText(BuyStepOneProductActivity.this, "长期不用选证件有限期", Toast.LENGTH_SHORT).show();
                        } else {
                            initStartimeBtn();
                        }
                    }
                }
                break;
            case R.id.endtime_btn:
                //结束时间
                if ("2".equals(validType)) {
                    //长期
                    Toast.makeText(BuyStepOneProductActivity.this, "长期不用选证件有限期", Toast.LENGTH_SHORT).show();
                } else if ("1".equals(validType)) {
                    //定期
                    initEndtimeBtn();
                } else {
                    //还没初始化
                    IdNo = identificationEt.getText().toString();
                    if (TextUtils.isEmpty(IdNo)) {
                        Toast.makeText(BuyStepOneProductActivity.this, "请先填写个人信息", Toast.LENGTH_SHORT).show();
                    } else {
                        if (ischangqiRb.isChecked()) {
                            Toast.makeText(BuyStepOneProductActivity.this, "长期不用选证件有限期", Toast.LENGTH_SHORT).show();
                        } else {
                            initEndtimeBtn();
                        }
                    }
                }
                break;
            case R.id.ischangqi_rb:
                //长期radio
                String identification = identificationEt.getText().toString();
                if (TextUtils.isEmpty(identification)) {
                    Toast.makeText(BuyStepOneProductActivity.this, "请先填写身份证消息", Toast.LENGTH_SHORT).show();
                } else {
                    if (age > 45) {
                        ischangqiRb.setChecked(true);
                        Toast.makeText(BuyStepOneProductActivity.this, "根据身份证已自动判断", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(BuyStepOneProductActivity.this, "未超过45岁，不能选择长期", Toast.LENGTH_SHORT).show();
                        ischangqiRb.setChecked(false);
                    }
                }
                break;
            case R.id.selectprovince_btn:
                //省市选择  初始化
                options1Items.clear();
                options2Items.clear();
                OptionsPickerView pvOptions = new OptionsPickerView(BuyStepOneProductActivity.this);
                for (int i = 0; i < provinceList.size(); i++) {
                    ProvinceVo provinceVo = provinceList.get(i);
                    options1Items.add(provinceVo.getProvinceName());
                    options2Items.add(VerifyUtil.getCityListByProviceCode(cityList, provinceVo.getProvincePostCode()));
                }
                //三级联动效果
                pvOptions.setPicker(options1Items, options2Items, true);
                pvOptions.setCyclic(false, false, false);
                //设置默认选中的三级项目
                //监听确定选择按钮
                pvOptions.setSelectOptions(1, 1);
                pvOptions.setCancelable(true);
                pvOptions.show();
                pvOptions.setOnoptionsSelectListener(new OptionsPickerView.OnOptionsSelectListener() {
                    @Override
                    public void onOptionsSelect(int options1, int option2, int options3) {
                        //返回的分别是三个级别的选中位置
                        String tx = options1Items.get(options1)
                                + options2Items.get(options1).get(option2);
                        provinceId = VerifyUtil.getProviceCodeByProviceName(provinceList, options1Items.get(options1));
                        cityId = VerifyUtil.getcityCodeBycityName(cityList, options2Items.get(options1).get(option2));
                        //        addressProvince,addressCity,occupationName,occupationCode;
                        addressProvince = options1Items.get(options1);
                        addressCity = options2Items.get(options1).get(option2);
                        selectprovinceBtn.setText(tx);
                    }
                });
                break;
            case R.id.industrychoice_btn:
                //岗位选择
                optionsItems.clear();
                OptionsPickerView pvOptions2 = new OptionsPickerView(BuyStepOneProductActivity.this);
                //省市选择  初始化
                for (int i = 0; i < occupationList.size(); i++) {
                    OccupationVo occupationVo = occupationList.get(i);
                    optionsItems.add(occupationVo.getOccupationName());
                }
                //三级联动效果
                pvOptions2.setPicker(optionsItems);
                pvOptions2.setCyclic(false);
                //设置默认选中的三级项目
                //监听确定选择按钮
                pvOptions2.setSelectOptions(1, 0);
                pvOptions2.setCancelable(true);
                pvOptions2.show();
                pvOptions2.setOnoptionsSelectListener(new OptionsPickerView.OnOptionsSelectListener() {
                    @Override
                    public void onOptionsSelect(int options1, int option2, int options3) {
                        //返回的分别是三个级别的选中位置
                        occupationName = optionsItems.get(options1);
                        //  provinceId,cityId,industryId,occupationId;
                        OccupationVo occupationVo = VerifyUtil.getOccupationByoccupationName(occupationList, occupationName);
                        //        addressProvince,addressCity,occupationName,occupationCode;
                        occupationCode = occupationVo.getOccupationCode();
                        occupationType = occupationVo.getOccupationType();
                        industrychoiceBtn.setText(occupationName);
                    }
                });
                break;
            case R.id.right_tv_title:
                //检查格式
                checkFormatToIntent();
                break;
        }
    }

    private void initEndtimeBtn() {
        if (TextUtils.isEmpty(starTime)) {
            Toast.makeText(BuyStepOneProductActivity.this, "请先选开始时间", Toast.LENGTH_SHORT).show();
        } else {
            pvTime = new TimePickerView(BuyStepOneProductActivity.this, TimePickerView.Type.YEAR_MONTH_DAY);
            pvTime.setCancelable(true);
            pvTime.show();
            pvTime.setOnTimeSelectListener(new TimePickerView.OnTimeSelectListener() {
                @Override
                public void onTimeSelect(Date date) {
                    Date currentDate=new Date();
                    if (date.compareTo(starDate) < 0) {
                        Toast.makeText(BuyStepOneProductActivity.this, "结束时间不得小于开始时间", Toast.LENGTH_SHORT).show();
                    }else if (date.compareTo(currentDate) < 0) {
                            Toast.makeText(BuyStepOneProductActivity.this, "结束时间不得小于当前时间", Toast.LENGTH_SHORT).show();
                    } else {
                        endTime = getTime(date);
                        endtimeBtn.setText(endTime);
                        //Toast.makeText(BasicInformationActivity.this, "-time-" + endTime, Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    private void initStartimeBtn() {
        pvTime = new TimePickerView(BuyStepOneProductActivity.this, TimePickerView.Type.YEAR_MONTH_DAY);
        pvTime.setCancelable(true);
        pvTime.show();
        pvTime.setOnTimeSelectListener(new TimePickerView.OnTimeSelectListener() {
            @Override
            public void onTimeSelect(Date date) {
                starDate = date;
                starTime = getTime(starDate);
                startimeBtn.setText(starTime);
                //Toast.makeText(BasicInformationActivity.this, "-time-" + starTime, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private static String getTime(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        return format.format(date);
    }

    private void checkFormatToIntent() {
        String realname = username.getText().toString();
        String identification = identificationEt.getText().toString();
        String phone = phoneEt.getText().toString();
        String email = emailCodeEt.getText().toString();
        boolean flag = ischangqiRb.isChecked();
        String areadetail = areadetailEt.getText().toString();
        String annualincome = annualincomeEt.getText().toString();
        String postCode = postCodeEt.getText().toString();
        // 中文表达式
        Pattern chinesePattern = Pattern
                .compile("^[\\u4E00-\\u9FA5\\uF900-\\uFA2D]+$");
        // 身份证正则表达式
        Pattern idPattern = Pattern.compile("^(\\d{14}|\\d{17})(\\d|[xX])$");
        //邮箱正则表达式
        Pattern emailPattern = Pattern.compile("^\\s*\\w+(?:\\.{0,1}[\\w-]+)*@[a-zA-Z0-9]+(?:[-.][a-zA-Z0-9]+)*\\.[a-zA-Z]+\\s*$");
        // 匹配器
        Matcher matcher = chinesePattern.matcher(realname);
        Matcher emailMatcher = emailPattern.matcher(email);
        Matcher identificationmatcher = idPattern.matcher(identification);
        if (!matcher.matches()) {
            Toast.makeText(BuyStepOneProductActivity.this, "请输入中文姓名", Toast.LENGTH_SHORT).show();
        } else if (!VerifyUtil.VerificationPhone(phone)) {
            //手机号码
            Toast.makeText(BuyStepOneProductActivity.this, "手机号码格式不对", Toast.LENGTH_SHORT).show();
        } else if (!identificationmatcher.matches()) {
            Toast.makeText(BuyStepOneProductActivity.this, "身份证号码格式不对", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(email)) {
            Toast.makeText(BuyStepOneProductActivity.this, " 电子邮箱不能为空", Toast.LENGTH_SHORT).show();
        } else if (!TextUtils.isEmpty(email)&&!emailMatcher.matches()) {
            Toast.makeText(BuyStepOneProductActivity.this, "电子邮箱格式不对", Toast.LENGTH_SHORT).show();
        } else if (postCode.length() < 6) {
            Toast.makeText(BuyStepOneProductActivity.this, "邮政编码格式不对", Toast.LENGTH_SHORT).show();
        } else if (!flag && (TextUtils.isEmpty(starTime) | TextUtils.isEmpty(endTime))) {
            //长期
            Toast.makeText(BuyStepOneProductActivity.this, "证件有限期不得为空", Toast.LENGTH_SHORT).show();
        } else if (VerifyUtil.getWordCount(areadetail) < 6) {
            //详细地址长度不得小于6
            Toast.makeText(BuyStepOneProductActivity.this, "详细地址不得少于6个汉字", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(provinceId) | TextUtils.isEmpty(cityId)) {
            Toast.makeText(BuyStepOneProductActivity.this, "请选择地区", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(occupationCode)) {
            Toast.makeText(BuyStepOneProductActivity.this, "请选择职业", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(annualincome)) {
            Toast.makeText(BuyStepOneProductActivity.this, "请填写年收入", Toast.LENGTH_SHORT).show();
      /*  } else if (annualincome.length()>6) {
            Toast.makeText(BuyStepOneProductActivity.this, "年收入长度小于6位", Toast.LENGTH_SHORT).show();*/
        } else {
            //格式通过跳传
            Intent intent = new Intent(BuyStepOneProductActivity.this, BuyStepTwoProductActivity.class);
            Bundle bundle = new Bundle();
            HashMap<String, String> map = new HashMap<>();
            //
            map.put("name", realname);
            map.put("idNo", identification);
            if ("1".equals(validType)) {
//                validStartDate
                map.put("validStartDate", starTime);
                map.put("validEndDate", endTime);
            }
            if ("2".equals(validType)) {
                map.put("validStartDate", "");
                map.put("validEndDate", "");
            }
            map.put("validType", validType);
            map.put("mobile", phone);
            MyLogUtil.i("msg", "-validType-" + validType);
            map.put("email", email);
            map.put("sexname", sexname);
            map.put("salary", annualincome);
            map.put("birthday", VerifyUtil.getBir(identification));
            map.put("addressProvince", addressProvince);
            map.put("addressProvinceCode", provinceId);
            map.put("addressCity", addressCity);
            map.put("addressCityCode", cityId);

            map.put("addressDetail", areadetail);
            map.put("zip", postCode);
            map.put("occupationName", occupationName);
            map.put("occupationType", "100");
            map.put("occupationCode", occupationCode);
            map.put("total", total);

            SerializableMap serializableMap = new SerializableMap(map);
            bundle.putSerializable("map", serializableMap);
            HashMap<String, String> map_you = new HashMap<>();
            if (product_list != null) {
                bundle.putParcelable("product_list", product_list);

                map_you.put("product_type",product_list.getProductCode());
                map_you.put("mobile", Common.userInfo.getMobile());
                map_you.put("quantity", total);
            }

            if (!TextUtils.isEmpty(itemCode)) {
                // productName,productCode,totalmoney,days,begindate,endDate;
                bundle.putString("itemCode", itemCode);
                bundle.putString("productName", productName);
                bundle.putString("productCode", productCode);
                bundle.putString("totalmoney", totalmoney);
                bundle.putString("days", days);
                bundle.putString("startDate", startDate);
                bundle.putString("endDate", endDate);

                map_you.put("product_type",productCode);
                map_you.put("days",days);
                map_you.put("mobile", Common.userInfo.getMobile());
                map_you.put("quantity", totalmoney);

            }
            MobclickAgent.onEvent(BuyStepOneProductActivity.this, "purchase_02", map_you);
            intent.putExtras(bundle);
            startActivity(intent);
        }
    }
}
