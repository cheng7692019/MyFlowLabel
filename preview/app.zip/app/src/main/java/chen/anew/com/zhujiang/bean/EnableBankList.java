package chen.anew.com.zhujiang.bean;

import java.io.Serializable;
import java.util.List;

/**
 * Created by thinkpad on 2016/7/8.
 */
public class EnableBankList implements Serializable {
    private List<PayModeList> payModeList;

    private String bestPayInfo;

    private String payMode;

    public void setPayModeList(List<PayModeList> payModeList) {
        this.payModeList = payModeList;
    }

    public List<PayModeList> getPayModeList() {
        return this.payModeList;
    }

    public void setBestPayInfo(String bestPayInfo) {
        this.bestPayInfo = bestPayInfo;
    }

    public String getBestPayInfo() {
        return this.bestPayInfo;
    }

    public void setPayMode(String payMode) {
        this.payMode = payMode;
    }

    public String getPayMode() {
        return this.payMode;
    }

}
