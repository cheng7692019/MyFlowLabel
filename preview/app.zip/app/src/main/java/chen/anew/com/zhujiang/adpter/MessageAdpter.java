package chen.anew.com.zhujiang.adpter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.activity.web.WebViewActivity;
import chen.anew.com.zhujiang.greendao.MessageBean;

/**
 * Created by thinkpad on 2016/6/30.
 */
public class MessageAdpter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public List<MessageBean> datas = null;
    public Context context;

    public MessageAdpter(List<MessageBean> datas, Context context) {
        this.context = context;
        this.datas = datas;
    }

   /* private ClickListener clickListener;

    public interface ClickListener {
        void onItemClick(int position, View v);
    }

    public void setOnItemClickListener(ClickListener clickListener) {
        this.clickListener = clickListener;
    }*/


    public void updateView(List<MessageBean> datas) {
        this.datas = datas;
        this.notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.message_item, viewGroup, false);
        return new ViewHolder(view);
    }


    //将数据与界面进行绑定的操作
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        final MessageBean messageBean = datas.get(position);
        final ViewHolder viewHolder = (ViewHolder) holder;
        viewHolder.date_tv.setText(messageBean.getSendTime());
        viewHolder.title_tv.setText(messageBean.getTitle());
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date = null;
        try {
            date = sdf.parse(messageBean.getSendTime());
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        viewHolder.day_tv.setText(date.getMonth()+1+"月"+date.getDate()+"日");
        viewHolder.content_tv.setText(messageBean.getContent());
        if(TextUtils.isEmpty(messageBean.getUrl())){
            viewHolder.checknow_rl.setVisibility(View.GONE);
        }else{
            viewHolder.checknow_rl.setVisibility(View.VISIBLE);
            viewHolder.checknow_rl.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // TODO Auto-generated method stub
                    Intent intent = new Intent(context,WebViewActivity.class);
                    intent.putExtra("url", messageBean.getUrl());
                    intent.putExtra("title", "消息详情");
                    context.startActivity(intent);
                }
            });
        }
    }

    //获取数据的数量
    @Override
    public int getItemCount() {
        return datas.size();
    }


    //自定义的ViewHolder，持有每个Item的的所有界面元素
    static class ViewHolder extends RecyclerView.ViewHolder{
        public TextView date_tv, title_tv, day_tv,content_tv;
        public RelativeLayout checknow_rl;

        public ViewHolder(View view) {
            super(view);
            date_tv = (TextView) view.findViewById(R.id.date_tv);
            title_tv = (TextView) view.findViewById(R.id.title_tv);
            day_tv = (TextView) view.findViewById(R.id.day_tv);
            content_tv = (TextView) view.findViewById(R.id.content_tv);
            checknow_rl= (RelativeLayout) view.findViewById(R.id.checknow_rl);
        }

//        @Override
//        public void onClick(View view) {
//            clickListener.onItemClick(getAdapterPosition(), view);
//        }

    }
}

