package chen.anew.com.zhujiang.activity.mine.setup;

import android.content.Intent;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;

/**
 * Created by thinkpad on 2016/7/19.
 */
public class AlreadySetPayPasswordActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;

    @Override
    protected void initViews() {
        tvTitle.setText(getResources().getString(R.string.pay_password));
        initToolBar();
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_alreadysetpaypassword;
    }


    @OnClick({R.id.modify_paypassword_relative, R.id.forget_paypassword_relative})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.modify_paypassword_relative:
                startActivity(new Intent(AlreadySetPayPasswordActivity.this,ModifyPayPasswordActivity.class));
                break;
            case R.id.forget_paypassword_relative:
                startActivity(new Intent(AlreadySetPayPasswordActivity.this,ForgetPayPsdSendPhoneStepOneActivity.class));
                break;
        }
    }
}
