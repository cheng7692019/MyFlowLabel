package chen.anew.com.zhujiang.activity.mine.setup;

import android.content.Intent;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.Bind;
import butterknife.OnClick;
import chen.anew.com.zhujiang.R;
import chen.anew.com.zhujiang.base.BaseAppActivity;
import chen.anew.com.zhujiang.widget.PasswordInputView;

/**
 * Created by thinkpad on 2016/6/30.
 */
public class SetPayPasswordActivity extends BaseAppActivity {

    @Bind(R.id.tv_title)
    TextView tvTitle;
    @Bind(R.id.right_tv_title)
    TextView rightTvTitle;
    @Bind(R.id.toolbar)
    Toolbar toolbar;
    @Bind(R.id.passwordInputView)
    PasswordInputView passwordInputView;

    @Override
    protected void initViews() {
//        setpay_title
        tvTitle.setText(getResources().getString(R.string.setpay_title));
        rightTvTitle.setText(getResources().getString(R.string.next_step));
        initToolBar();
    }

    @Override
    protected int getContentViewId() {
        return R.layout.activity_paypassword;
    }

    private void initToolBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(" ");
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    @OnClick(R.id.right_tv_title)
    public void onClick() {
        String password = passwordInputView.getText().toString();
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(SetPayPasswordActivity.this, "支付密码不能为空", Toast.LENGTH_SHORT).show();
        } else {
            Intent intent = new Intent(SetPayPasswordActivity.this, SetPayNextPasswordActivity.class);
            intent.putExtra("paypassword", password);
            startActivity(intent);
            finish();
        }

    }
}
